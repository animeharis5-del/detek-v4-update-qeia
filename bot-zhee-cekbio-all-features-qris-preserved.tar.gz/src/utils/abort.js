const { setTimeout: delayPromise } = require("node:timers/promises");

function createOperationSignal(parentSignal, timeoutMs, label = "operation") {
  const controller = new AbortController();

  const abortFromParent = () => {
    controller.abort(
      parentSignal?.reason || new DOMException("Operasi dibatalkan.", "AbortError"),
    );
  };

  if (parentSignal?.aborted) abortFromParent();
  else parentSignal?.addEventListener("abort", abortFromParent, { once: true });

  const timeout = setTimeout(() => {
    controller.abort(
      new DOMException(`${label} melewati ${timeoutMs}ms.`, "TimeoutError"),
    );
  }, timeoutMs);

  return {
    signal: controller.signal,
    dispose() {
      clearTimeout(timeout);
      parentSignal?.removeEventListener("abort", abortFromParent);
    },
  };
}

async function abortableDelay(ms, signal) {
  if (ms <= 0) return;
  await delayPromise(ms, undefined, { signal });
}

module.exports = {
  abortableDelay,
  createOperationSignal,
};
