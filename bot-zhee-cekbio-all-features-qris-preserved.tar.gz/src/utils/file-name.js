const path = require("node:path");

const DEFAULT_FILE_NAME_MAX_LENGTH = 120;
const DEFAULT_FILE_STEM_MAX_LENGTH = 80;

function normalizeUntrustedFileName(value) {
  return String(value ?? "")
    .normalize("NFKC")
    .replace(/\0/g, "")
    .replace(/\\/g, "/")
    .trim();
}

function clampPositiveInteger(value, fallback) {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

function sanitizeFileName(
  value,
  { fallback = "numbers.txt", maxLength = DEFAULT_FILE_NAME_MAX_LENGTH } = {},
) {
  const safeFallback = String(fallback || "numbers.txt").replace(/[^A-Za-z0-9._-]+/g, "_");
  const rawBaseName = path.posix.basename(normalizeUntrustedFileName(value));
  let safeName = rawBaseName
    .replace(/[^A-Za-z0-9._-]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^\.+/g, "")
    .replace(/\.+$/g, "");

  if (!safeName || safeName === "." || safeName === "..") {
    safeName = safeFallback || "numbers.txt";
  }

  const limit = clampPositiveInteger(maxLength, DEFAULT_FILE_NAME_MAX_LENGTH);
  if (safeName.length <= limit) return safeName;

  const extension = path.extname(safeName).slice(0, Math.min(16, limit - 1));
  const rawStem = path.basename(safeName, path.extname(safeName));
  const stemLimit = Math.max(1, limit - extension.length);
  const stem = rawStem.slice(0, stemLimit) || "file";
  return `${stem}${extension}`.slice(0, limit);
}

function sanitizeFileStem(
  value,
  { fallback = "numbers", maxLength = DEFAULT_FILE_STEM_MAX_LENGTH } = {},
) {
  return sanitizeFileName(value, {
    fallback,
    maxLength: clampPositiveInteger(maxLength, DEFAULT_FILE_STEM_MAX_LENGTH),
  });
}

function describeTelegramTextFile(value) {
  const originalFileName = path.posix.basename(normalizeUntrustedFileName(value)) || "numbers.txt";
  const safeFileName = sanitizeFileName(originalFileName, { fallback: "numbers.txt" });
  const extension = path.extname(safeFileName).toLowerCase();
  const rawStem = path.basename(safeFileName, path.extname(safeFileName));
  return {
    originalFileName,
    safeFileName,
    safeStem: sanitizeFileStem(rawStem, { fallback: "numbers" }),
    extension,
  };
}

module.exports = {
  DEFAULT_FILE_NAME_MAX_LENGTH,
  DEFAULT_FILE_STEM_MAX_LENGTH,
  describeTelegramTextFile,
  sanitizeFileName,
  sanitizeFileStem,
};
