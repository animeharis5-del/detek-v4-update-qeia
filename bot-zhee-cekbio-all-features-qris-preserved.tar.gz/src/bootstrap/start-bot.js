const { startBot } = require("../app");

module.exports = { startBot };
