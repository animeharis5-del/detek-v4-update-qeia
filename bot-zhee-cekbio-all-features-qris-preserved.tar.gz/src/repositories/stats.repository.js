const path = require("node:path");
const { readJsonFile, updateJsonFileAtomic } = require("./json.repository");

const DB_PATH = path.join(process.cwd(), "bot_stats.json");

function defaultStats() {
  return { users: [], totalNumbersChecked: 0, successfulChecks: 0 };
}

function sanitizeUserIds(list) {
  if (!Array.isArray(list)) return [];
  return [...new Set(list.map(Number).filter((id) => Number.isSafeInteger(id) && id > 0))];
}

function sanitizeCounter(value) {
  const numeric = Number(value);
  return Number.isFinite(numeric) && numeric >= 0 ? Math.floor(numeric) : 0;
}

function buildStats(raw = {}) {
  return {
    users: sanitizeUserIds(raw.users),
    totalNumbersChecked: sanitizeCounter(raw.totalNumbersChecked),
    successfulChecks: sanitizeCounter(raw.successfulChecks),
  };
}

let currentStats = defaultStats();
let pendingWrite = Promise.resolve();

async function initializeStats() {
  try {
    currentStats = buildStats(await readJsonFile(DB_PATH, defaultStats));
  } catch (error) {
    console.error("Gagal membaca bot_stats.json:", error.message);
    if (error.backupPath) console.error("Backup file korup bot_stats.json:", error.backupPath);
    currentStats = defaultStats();
  }
  return structuredClone(currentStats);
}

function queuePersist(mutator) {
  pendingWrite = pendingWrite
    .catch(() => {})
    .then(async () => {
      currentStats = buildStats(
        await updateJsonFileAtomic(DB_PATH, defaultStats, (raw) => mutator(buildStats(raw))),
      );
      return currentStats;
    });
  pendingWrite.catch((error) => console.error("Gagal menyimpan bot_stats.json:", error.message));
  return pendingWrite;
}

function trackUser(userId) {
  const id = Number(userId);
  if (!Number.isSafeInteger(id) || id <= 0) {
    return { stats: structuredClone(currentStats), isNew: false };
  }

  const isNew = !currentStats.users.includes(id);
  if (isNew) currentStats = { ...currentStats, users: [...currentStats.users, id] };

  if (isNew) {
    queuePersist((stats) =>
      stats.users.includes(id) ? stats : { ...stats, users: [...stats.users, id] },
    );
  }

  return { stats: structuredClone(currentStats), isNew };
}

function recordCheckCounters({ total, failed = 0 }) {
  const checked = Math.max(0, Math.floor(Number(total) || 0));
  const failures = Math.min(checked, Math.max(0, Math.floor(Number(failed) || 0)));
  const successful = checked - failures;

  currentStats = {
    ...currentStats,
    totalNumbersChecked: currentStats.totalNumbersChecked + checked,
    successfulChecks: currentStats.successfulChecks + successful,
  };

  queuePersist((stats) => ({
    ...stats,
    totalNumbersChecked: stats.totalNumbersChecked + checked,
    successfulChecks: stats.successfulChecks + successful,
  }));

  return structuredClone(currentStats);
}

function recordCheckResults(results) {
  const list = Array.isArray(results) ? results : [];
  return recordCheckCounters({
    total: list.length,
    failed: list.filter((item) => item?.error || item?.exists === null).length,
  });
}

function getSummary() {
  const ratio = currentStats.totalNumbersChecked
    ? (currentStats.successfulChecks / currentStats.totalNumbersChecked) * 100
    : 0;
  return {
    totalUsers: currentStats.users.length,
    totalNumbersChecked: currentStats.totalNumbersChecked,
    successfulChecks: currentStats.successfulChecks,
    successRatio: ratio,
  };
}

function getUserIds() {
  return [...currentStats.users];
}

async function flushStats() {
  await pendingWrite;
}

module.exports = {
  initializeStats,
  trackUser,
  recordCheckCounters,
  recordCheckResults,
  getSummary,
  getUserIds,
  flushStats,
};
