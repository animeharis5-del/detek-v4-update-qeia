const path = require("node:path");
const { readJsonFile, updateJsonFileAtomic } = require("./json.repository");

const DB_PATH = path.join(process.cwd(), "emoji_mappings.json");

function defaultStore() {
  return { mappings: {} };
}

function normalizeEmojiKey(value) {
  return String(value ?? "")
    .trim()
    .replace(/\uFE0F/g, "");
}

function sanitizeCustomEmojiId(value) {
  const id = String(value ?? "").trim();
  return /^\d{5,40}$/.test(id) ? id : null;
}

function sanitizeMapping(key, value) {
  const normalizedKey = normalizeEmojiKey(key);
  const customEmojiId = sanitizeCustomEmojiId(value?.customEmojiId);
  if (!normalizedKey || !customEmojiId) return null;
  return {
    emoji: String(value?.emoji || key || "").trim() || normalizedKey,
    customEmojiId,
    customAlt: String(value?.customAlt || "").trim(),
    isAnimated: value?.isAnimated === true,
    isVideo: value?.isVideo === true,
    updatedAt: String(value?.updatedAt || ""),
  };
}

function buildStore(raw = {}) {
  const source = raw && typeof raw.mappings === "object" && !Array.isArray(raw.mappings)
    ? raw.mappings
    : {};
  const mappings = {};
  for (const [key, value] of Object.entries(source)) {
    const normalizedKey = normalizeEmojiKey(key);
    const mapping = sanitizeMapping(key, value);
    if (!normalizedKey || !mapping) continue;
    mappings[normalizedKey] = mapping;
  }
  return { mappings };
}

let currentStore = defaultStore();
let pendingWrite = Promise.resolve();

async function initializeEmojiMappings() {
  try {
    currentStore = buildStore(await readJsonFile(DB_PATH, defaultStore));
  } catch (error) {
    console.error("Gagal membaca emoji_mappings.json:", error.message);
    if (error.backupPath) {
      console.error("Backup file korup emoji_mappings.json:", error.backupPath);
    }
    currentStore = defaultStore();
  }
  return structuredClone(currentStore);
}

function getMapping(emoji) {
  const key = normalizeEmojiKey(emoji);
  if (!key) return null;
  const value = currentStore.mappings[key];
  return value ? structuredClone(value) : null;
}

function getAllMappings() {
  return structuredClone(currentStore.mappings);
}

function setMapping(emoji, mapping) {
  const key = normalizeEmojiKey(emoji);
  const clean = sanitizeMapping(emoji, mapping);
  if (!key || !clean) throw new TypeError("Mapping emoji tidak valid.");

  currentStore = {
    ...currentStore,
    mappings: {
      ...currentStore.mappings,
      [key]: clean,
    },
  };

  pendingWrite = pendingWrite
    .catch(() => {})
    .then(async () => {
      await updateJsonFileAtomic(DB_PATH, defaultStore, (raw) => {
        const store = buildStore(raw);
        return {
          ...store,
          mappings: {
            ...store.mappings,
            [key]: clean,
          },
        };
      });
      return currentStore;
    });

  pendingWrite.catch((error) =>
    console.error("Gagal menyimpan emoji_mappings.json:", error.message),
  );
  return pendingWrite;
}

async function flushEmojiMappings() {
  await pendingWrite;
}

module.exports = {
  initializeEmojiMappings,
  getMapping,
  getAllMappings,
  setMapping,
  flushEmojiMappings,
  normalizeEmojiKey,
};
