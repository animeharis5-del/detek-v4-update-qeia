const fsp = require("node:fs/promises");
const path = require("node:path");
const { chmodBestEffort } = require("../services/file-permissions.service");

const fileQueues = new Map();

function resolveFallback(fallback) {
  return typeof fallback === "function" ? fallback() : fallback;
}

function enrichJsonError(error, filePath) {
  const next = new Error(`JSON tidak valid di ${filePath}: ${error.message}`, {
    cause: error,
  });
  next.code = "ERR_INVALID_JSON_FILE";
  return next;
}

function enqueueFileOperation(filePath, operation) {
  const key = path.resolve(filePath);
  const previous = fileQueues.get(key) || Promise.resolve();
  const current = previous.catch(() => {}).then(operation);
  fileQueues.set(key, current);
  const cleanup = () => {
    if (fileQueues.get(key) === current) fileQueues.delete(key);
  };
  current.then(cleanup, cleanup);
  return current;
}

async function ensurePrivateDirectory(dirPath) {
  await fsp.mkdir(dirPath, { recursive: true, mode: 0o700 });
  await chmodBestEffort(dirPath, 0o700);
}

async function backupCorruptFile(filePath) {
  const backupPath = `${filePath}.corrupt-${Date.now()}`;
  try {
    await fsp.copyFile(filePath, backupPath);
    await chmodBestEffort(backupPath, 0o600);
    return backupPath;
  } catch {
    return null;
  }
}

async function readJsonFileUnlocked(filePath, fallback) {
  let raw;
  try {
    raw = await fsp.readFile(filePath, "utf8");
  } catch (error) {
    if (error.code === "ENOENT") return resolveFallback(fallback);
    throw error;
  }

  if (!raw.trim()) return resolveFallback(fallback);

  try {
    return JSON.parse(raw);
  } catch (error) {
    const backupPath = await backupCorruptFile(filePath);
    const enriched = enrichJsonError(error, filePath);
    if (backupPath) enriched.backupPath = backupPath;
    throw enriched;
  }
}

async function fsyncDirectoryBestEffort(dirPath) {
  let handle;
  try {
    handle = await fsp.open(dirPath, "r");
    await handle.sync();
  } catch {
    // Tidak semua filesystem mendukung fsync direktori.
  } finally {
    await handle?.close().catch(() => {});
  }
}

async function writeJsonFileAtomicUnlocked(filePath, data) {
  const dirPath = path.dirname(filePath);
  await ensurePrivateDirectory(dirPath);

  const tmpPath = path.join(
    dirPath,
    `.${path.basename(filePath)}.${process.pid}.${Date.now()}.${Math.random()
      .toString(36)
      .slice(2)}.tmp`,
  );

  let handle;
  try {
    handle = await fsp.open(tmpPath, "wx", 0o600);
    await handle.writeFile(JSON.stringify(data, null, 2), "utf8");
    await handle.sync();
    await handle.close();
    handle = null;

    await fsp.rename(tmpPath, filePath);
    await chmodBestEffort(filePath, 0o600);
    await fsyncDirectoryBestEffort(dirPath);
    return data;
  } catch (error) {
    await handle?.close().catch(() => {});
    await fsp.rm(tmpPath, { force: true }).catch(() => {});
    throw error;
  }
}

async function readJsonFile(filePath, fallback) {
  return enqueueFileOperation(filePath, () => readJsonFileUnlocked(filePath, fallback));
}

async function writeJsonFileAtomic(filePath, data) {
  return enqueueFileOperation(filePath, () => writeJsonFileAtomicUnlocked(filePath, data));
}

async function updateJsonFileAtomic(filePath, fallback, updater) {
  if (typeof updater !== "function") {
    throw new TypeError("updateJsonFileAtomic membutuhkan fungsi updater.");
  }

  return enqueueFileOperation(filePath, async () => {
    const current = await readJsonFileUnlocked(filePath, fallback);
    const updated = await updater(current);
    const next = updated === undefined ? current : updated;

    if (JSON.stringify(current) !== JSON.stringify(next)) {
      await writeJsonFileAtomicUnlocked(filePath, next);
    }
    return next;
  });
}

module.exports = {
  ensurePrivateDirectory,
  readJsonFile,
  writeJsonFileAtomic,
  updateJsonFileAtomic,
};
