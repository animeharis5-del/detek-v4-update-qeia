const path = require("node:path");
const { readJsonFile, updateJsonFileAtomic } = require("./json.repository");

const DB_PATH = path.join(process.cwd(), "user_preferences.json");

function defaultPreferences() {
  return { users: {} };
}

function sanitizeUserId(value) {
  const numeric = Number(value);
  return Number.isSafeInteger(numeric) && numeric > 0 ? String(numeric) : null;
}

function sanitizeCheckSpeed(value) {
  const numeric = Number.parseInt(String(value ?? ""), 10);
  return Number.isSafeInteger(numeric) && numeric > 0 ? numeric : null;
}

function buildPreferences(raw = {}) {
  const source = raw && typeof raw.users === "object" && !Array.isArray(raw.users)
    ? raw.users
    : {};
  const users = {};

  for (const [rawUserId, value] of Object.entries(source)) {
    const userId = sanitizeUserId(rawUserId);
    const checkSpeed = sanitizeCheckSpeed(value?.checkSpeed);
    if (!userId || !checkSpeed) continue;
    users[userId] = { checkSpeed };
  }

  return { users };
}

let currentPreferences = defaultPreferences();
let pendingWrite = Promise.resolve();

async function initializeUserPreferences() {
  try {
    currentPreferences = buildPreferences(
      await readJsonFile(DB_PATH, defaultPreferences),
    );
  } catch (error) {
    console.error("Gagal membaca user_preferences.json:", error.message);
    if (error.backupPath) {
      console.error(
        "Backup file korup user_preferences.json:",
        error.backupPath,
      );
    }
    currentPreferences = defaultPreferences();
  }
  return structuredClone(currentPreferences);
}

function getCheckSpeed(userId, fallback = 100) {
  const key = sanitizeUserId(userId);
  const fallbackSpeed = sanitizeCheckSpeed(fallback) || 100;
  if (!key) return fallbackSpeed;
  return sanitizeCheckSpeed(currentPreferences.users[key]?.checkSpeed) || fallbackSpeed;
}

function setCheckSpeed(userId, speed) {
  const key = sanitizeUserId(userId);
  const checkSpeed = sanitizeCheckSpeed(speed);
  if (!key) throw new TypeError("userId tidak valid untuk preferensi user.");
  if (!checkSpeed) throw new TypeError("Kecepatan cek tidak valid.");

  currentPreferences = {
    ...currentPreferences,
    users: {
      ...currentPreferences.users,
      [key]: { checkSpeed },
    },
  };

  pendingWrite = pendingWrite
    .catch(() => {})
    .then(async () => {
      await updateJsonFileAtomic(
        DB_PATH,
        defaultPreferences,
        (raw) => {
          const current = buildPreferences(raw);
          return {
            ...current,
            users: {
              ...current.users,
              [key]: { checkSpeed },
            },
          };
        },
      );
      return currentPreferences;
    });

  pendingWrite.catch((error) =>
    console.error("Gagal menyimpan user_preferences.json:", error.message),
  );
  return pendingWrite;
}

async function flushUserPreferences() {
  await pendingWrite;
}

module.exports = {
  initializeUserPreferences,
  getCheckSpeed,
  setCheckSpeed,
  flushUserPreferences,
};
