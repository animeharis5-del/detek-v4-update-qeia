const { Telegraf, Markup, Input } = require("telegraf");
const fs = require("fs");
const path = require("path");
const QRCode = require("qrcode");
const http = require("node:http");
const wallet = require("./services/wallet.service");
const pricing = require("./services/pricing.service");
const { createBuatQrisClient, verifyWebhookSignature } = require("./services/buatqris.service");
const config = require("../config");
const { readJsonFile, writeJsonFileAtomic } = require("../json_store");
const {
  normalizeInputNumber,
  parseNumbersFromMessage,
} = require("../checkbio_utils");
const {
  stopAllWA,
  stopWA,
  reloadWA,
  forceResetWA,
  setAutoDisconnectNotifier,
  setTerminalDisconnectNotifier,
  subscribeSessionConnectivity,
  subscribeSenderConnectivity,
  subscribeSessionReady,
  getSessionConnectivityState,
  requestNewSenderPairingCode,
  setQrNotifier,
  startNewQrPairingSession,
  isConnected,
  getSenderSnapshot,
  getSenderSnapshots,
  getSenderSnapshotById,
  getSenderConnectivityState,
  ensureSenderConnectedSession,
  markSenderReady,
  isSenderReady,
  cancelSenderPairing,
  disconnectSender: disconnectSenderSession,
  disconnectAllSenders: disconnectAllSenderSessions,
  getKnownSenderIds,
  isSessionReady,
  hasAuthSession,
  ensureConnectedSession,
  cekBioEnhanced,
  cekBioEnhancedForSender,
  isRetryableWaCheckError,
} = require("../wa");
const stats = require("../stats");
const userPreferences = require("./repositories/user-preferences.repository");
const emojiMappings = require("./repositories/emoji-mappings.repository");
const {
  applyMappingsToTelegramText,
  extractEmojiMappingCommand,
  getUiEmojiRows,
  removeButtonCustomEmoji,
} = require("./services/ui-emoji.service");
const { createCheckJobQueue } = require("./queue/check-job.queue");
const { abortableDelay } = require("./utils/abort");
const { describeTelegramTextFile } = require("./utils/file-name");
const {
  areTelegramMessageContentsEqual,
  createTelegramRetryService,
  editOrResendTelegramPanel,
} = require("./services/telegram.service");
const {
  deleteTrackedProgressPanel,
  setTrackedProgressPanel,
  updateTrackedProgressPanel,
} = require("./services/check-progress-panel.service");
const {
  createAwaitPairingState,
  deletePairingPromptMessage,
} = require("./services/pairing-prompt.service");
const {
  NumberLimitError,
  downloadTelegramFileToTemp,
  normalizeNumberFile,
} = require("./services/checkbio.service");
const { createCheckState } = require("./services/check-state.service");
const { createSenderPool } = require("./services/sender-pool.service");
const { createSenderCheckRouter } = require("./services/sender-check-router.service");
const { createAndDeliverReportPair } = require("./services/report-pair.service");
const { buildResultCaption } = require("./presentation/report-ui");
const {
  assertReadableFile,
  ensureTempDirWritable,
} = require("./services/temp-dir.service");
const {
  WaSessionDisconnectedError,
  runResumableChecks,
} = require("./services/resumable-check.service");
const {
  beginPausedCheckSendConfirmation,
  cancelPausedCheckSendConfirmation,
  finalizePausedCheckJob,
  getPausedCheckJob,
  getResumeStatus,
} = require("./services/paused-check-actions.service");
const {
  armPausedReconnectWait,
  clearPausedReconnectWait,
} = require("./services/paused-reconnect-resume.service");
const {
  ACCENTS,
  CARD_SEPARATOR,
  THIN_LINE,
  boxPanel,
  boxPanelFramed,
  buildActiveJobCard,
  buildFriendlyIssueCard,
  buildForceJoinFailedCard,
  buildForceJoinWelcomeCard,
  buildHelpCard,
  buildMainMenuCard,
  buildPausedCheckCard,
  buildPausedCheckSendConfirmationCard,
  buildResumeNeedsConnectionCard,
  buildSummaryCard,
  buildTelegramDownloadFailedCard,
  buildWaConnectionCard,
  buildWaConnectedCard,
  buildWaDisconnectedCard,
  buildWaPairingCard,
  buildWaStatusCard,
  buildSenderManagerCard,
  buildSenderMethodCard,
  buildSenderPairingPromptCard,
  buildSenderPairingCodeCard,
  buildSenderQrWaitCard,
  buildSenderQrCaption,
  buildSenderConnectedNotice,
  buildSenderDisconnectMenuCard,
  buildSenderDisconnectedNotice,
  buildSenderUnexpectedDisconnectNotice,
  buildAllSendersDisconnectedNotice,
  buildSenderPairingCancelledCard,
  formatStatNumber,
  warningPanel,
} = require("./presentation/cards");
const { createKeyboardPresentation } = require("./presentation/keyboards");
const { registerCheckBioController } = require("./controllers/checkbio.controller");
const { registerStartController } = require("./controllers/start.controller");
const { registerWhatsAppController } = require("./controllers/whatsapp.controller");
const { registerOwnerController } = require("./controllers/owner.controller");
const { registerCallbackController } = require("./controllers/callback.controller");
const { registerTextController } = require("./controllers/text.controller");
const { registerHelpController } = require("./controllers/help.controller");
if (!config.BOT_TOKEN.includes(":")) {
  throw new Error("BOT_TOKEN belum diisi (cek config.js)");
}

const senderPool = createSenderPool({
  getSenderSnapshots,
  getSenderConnectivityState,
  maxActivePerSender: 1,
});

const senderCheckRouter = createSenderCheckRouter({
  senderPool,
  checkWithSender: cekBioEnhancedForSender,
});

const bot = new Telegraf(config.BOT_TOKEN);
const qris = config.BUATQRIS_ACCOUNT_ID && config.BUATQRIS_SECRET_TOKEN
  ? createBuatQrisClient({ baseUrl: config.BUATQRIS_BASE_URL, accountId: config.BUATQRIS_ACCOUNT_ID, secretToken: config.BUATQRIS_SECRET_TOKEN })
  : null;
const userStates = new Map();
const knownUsers = new Set();
const activePairingPanels = new Map();
const waConnectJobs = new Map();
const telegramMessageSnapshots = new Map();
const groupInteractivePanelOwners = new Map();
let pairingPanelSequence = 0;
let shutdownInProgress = false;

const BANNER_CACHE_PATH = path.join(process.cwd(), "banner_cache.json");
// ─── FORCE JOIN MULTI-TARGET (5 target) ───────────────────────────────────
// Ambil dari config.FORCE_JOIN_TARGETS; title & url di-resolve saat startup
const RAW_FORCE_JOIN_TARGETS = (
  Array.isArray(config.FORCE_JOIN_TARGETS) ? config.FORCE_JOIN_TARGETS : []
).filter((t) => Boolean(String(t?.chat || "").trim()));
const FORCE_JOIN_FOLDER_URL = String(config.FORCE_JOIN_FOLDER_URL || "").trim();

// Semua grup/supergroup boleh memakai bot. Akses tetap dikunci per-user
// melalui private onboarding + Force Join. ALLOWED_GROUP_CHATS dipertahankan
// di config hanya untuk kompatibilitas deployment lama dan tidak menjadi whitelist.

// Cache resolved titles (di-fetch saat startup)
const _resolvedForceJoinTargets = [];
let cachedBannerFileId = null;
let maintenanceMode = false;

// Fungsi deriveTelegramJoinUrl: membuat link join Telegram dari username atau URL target force join.
function deriveTelegramJoinUrl(chatRef) {
  const value = String(chatRef || "").trim();
  if (!value) return "";
  if (/^https?:\/\//i.test(value)) return value;
  if (/^@/.test(value)) return `https://t.me/${value.slice(1)}`;
  if (/^[A-Za-z0-9_]+$/.test(value)) return `https://t.me/${value}`;
  return "";
}

// ========== MAINTENANCE MODE ==========
const MAINTENANCE_PATH = path.join(process.cwd(), "maintenance.json");

// Fungsi isMaintenanceMode: membaca status maintenance dari cache RAM.
function isMaintenanceMode() {
  return maintenanceMode;
}

// Fungsi setMaintenanceMode: mengubah cache lalu menyimpan secara async/atomic.
async function setMaintenanceMode(enabled) {
  maintenanceMode = enabled === true;
  await writeJsonFileAtomic(MAINTENANCE_PATH, {
    maintenance: maintenanceMode,
    enabled: maintenanceMode,
    updatedAt: new Date().toISOString(),
  });
  return maintenanceMode;
}

// ========================================

const CALLBACKS = {
  WA_MENU: "BTN_WA_MENU",
  PAIR: "BTN_PAIR",
  PAIR_CODE: "BTN_PAIR_CODE",
  PAIR_QR: "BTN_PAIR_QR",
  FORMAT_SIMPLE: "BTN_FORMAT_SIMPLE",
  FORMAT_DETAIL: "BTN_FORMAT_DETAIL",
  CHECK_SPEED_MENU: "BTN_CHECK_SPEED_MENU",
  CHECK_SPEED_BACK: "BTN_CHECK_SPEED_BACK",
  CHECK_SPEED_PREFIX: "SPD:",
  STATUS: "BTN_STATUS",
  RELOAD: "BTN_RELOAD",
  DISCONNECT_MENU: "BTN_DISCONNECT_MENU",
  DISCONNECT_CURRENT: "BTN_DISCONNECT_CURRENT",
  DISCONNECT_SENDER_PREFIX: "DS:",
  DISCONNECT_ALL: "BTN_DISCONNECT_ALL",
  MENU: "BTN_MENU",
  CLOSE_WA_MENU: "BTN_CLOSE_WA_MENU",
  CANCEL_STATE: "BTN_CANCEL_STATE",
  ABORT_CHECK: "BTN_ABORT_CHECK",
  SEND_PARTIAL_CHECK: "BTN_SEND_PARTIAL_CHECK",
  CONFIRM_SEND_PARTIAL_CHECK: "BTN_CONFIRM_SEND_PARTIAL_CHECK",
  CANCEL_SEND_PARTIAL_CHECK: "BTN_CANCEL_SEND_PARTIAL_CHECK",
  RESUME_CHECK: "BTN_RESUME_CHECK",
  JOIN_VERIFY: "BTN_JOIN_VERIFY",
  OWN_MAINTENANCE: "BTN_OWN_MAINTENANCE",
  OWN_BROADCAST: "BTN_OWN_BROADCAST",
  BALANCE: "BTN_BALANCE",
  TOPUP: "BTN_TOPUP",
  HISTORY: "BTN_HISTORY",
};

const keyboardPresentation = createKeyboardPresentation(Markup);

// Batas input user:
// /cekbio dibatasi 300 nomor karena command Telegram punya batas panjang karakter.
// /cekbiotxt dibatasi 1.000.000 nomor/file sebagai batas maksimum.
const DIRECT_CHECK_MAX_NUMBERS = 300;
const TXT_CHECK_MAX_NUMBERS = 1_000_000;
const BROADCAST_MAX_TEXT_LENGTH = 4000;
const BROADCAST_DELAY_MS = 120;

// Kecepatan cek dapat dipilih user dan disimpan sebagai preferensi per-user.
// Default awal 100 task per Sender sampai user memilih nilai lain.
const STABLE_CHECK_DELAY_MS = Number.isInteger(config.CHECK_DELAY_MS)
  ? config.CHECK_DELAY_MS
  : 250;
const STABLE_PROFILE_FETCH_DELAY_MS = Number.isInteger(config.PROFILE_FETCH_DELAY_MS)
  ? config.PROFILE_FETCH_DELAY_MS
  : 750;
const STABLE_MAX_CONCURRENCY = Number.isInteger(config.MAX_CONCURRENCY)
  ? config.MAX_CONCURRENCY
  : 3;
const CHECK_SPEED_OPTIONS = Object.freeze([5, 25, 50, 100, 200, 500, 1000]);
const DEFAULT_CHECK_SPEED = 100;
function normalizeCheckSpeed(value, fallback = DEFAULT_CHECK_SPEED) {
  const numeric = Number.parseInt(String(value ?? fallback), 10);
  return CHECK_SPEED_OPTIONS.includes(numeric) ? numeric : fallback;
}
function getUserDefaultCheckSpeed(userId) {
  return normalizeCheckSpeed(
    userPreferences.getCheckSpeed(userId, DEFAULT_CHECK_SPEED),
  );
}
const runtime = Object.freeze({
  CHECK_DELAY_MS: Math.min(
    10000,
    Math.max(100, STABLE_CHECK_DELAY_MS, STABLE_PROFILE_FETCH_DELAY_MS),
  ),
  MAX_CONCURRENCY: Math.min(4, Math.max(1, STABLE_MAX_CONCURRENCY)),
  // Multi-Sender tidak lagi tercekik cap legacy 3/4 worker. Scheduler tetap
  // bounded, tetapi dapat memakai lebih banyak Sender sehat secara paralel.
  MULTI_SENDER_MAX_CONCURRENCY: Math.min(
    64,
    Math.max(1, Number(config.MAX_MULTI_SENDER_CONCURRENCY) || 12),
  ),
});
const checkJobQueue = createCheckJobQueue({ timeoutMs: config.CHECK_JOB_TIMEOUT_MS });

// Fungsi isOwner: mengecek apakah Telegram user termasuk owner bot.
function isOwner(id) {
  return Array.isArray(config.OWNERS) && config.OWNERS.includes(id);
}

// Fungsi formatLogExtra: merapikan data tambahan untuk log sistem.
function formatLogExtra(extra) {
  return Object.entries(extra)
    .filter(([, v]) => v !== undefined && v !== null && v !== "")
    .map(([k, v]) => `${k}=${String(v)}`)
    .join(" | ");
}
// Fungsi logApp: mencatat aktivitas bot ke console dengan format konsisten.
function logApp(level, ctxOrUserId, scope, stage, message, extra = {}) {
  const userId =
    typeof ctxOrUserId === "object"
      ? (ctxOrUserId?.from?.id ?? ctxOrUserId?.userId ?? "-")
      : (ctxOrUserId ?? "-");
  const prefix = `[${level}][TG ${userId}][${scope}][${stage}]`;
  const details = formatLogExtra(extra);
  const line = details
    ? `${prefix} ${message} | ${details}`
    : `${prefix} ${message}`;
  if (level === "ERROR") console.error(line);
  else if (level === "WARN") console.warn(line);
  else console.log(line);
}
// Fungsi logIgnoredError: mencatat error kecil tanpa menghentikan bot.
function logIgnoredError(scope, stage, error, extra = {}) {
  logApp("WARN", "SYSTEM", scope, stage, "non-critical error ditangkap", {
    ...extra,
    error: error?.message || String(error || "unknown error"),
  });
}
// Fungsi getWaConnectJobKey: menjalankan bagian get wa connect job key pada bot.
function getWaConnectJobKey(userId, type) {
  return `${String(userId)}:${String(type || "connect")}`;
}
// Fungsi startWaConnectJob: menjalankan bagian start wa connect job pada bot.
function startWaConnectJob(userId, type, task) {
  const key = getWaConnectJobKey(userId, type);
  if (waConnectJobs.has(key)) return false;
  const job = Promise.resolve()
    .then(task)
    .catch((error) => {
      logApp(
        "ERROR",
        userId,
        "WA_CONNECT",
        "ASYNC_FAIL",
        "proses koneksi WA background gagal",
        { type, error: error?.message || String(error) },
      );
    })
    .finally(() => waConnectJobs.delete(key));
  waConnectJobs.set(key, job);
  return true;
}
// Fungsi getTelegramPanelMetaFromResult: menjalankan bagian get telegram panel meta from result pada bot.
function getTelegramPanelMetaFromResult(ctx, renderResult) {
  if (renderResult?.chat?.id && renderResult?.message_id)
    return {
      chatId: renderResult.chat.id,
      messageId: renderResult.message_id,
      text: renderResult.text ?? renderResult.caption ?? "",
      replyMarkup: renderResult.reply_markup ?? null,
    };
  if (ctx?.chat?.id && renderResult?.message_id)
    return {
      chatId: ctx.chat.id,
      messageId: renderResult.message_id,
      text: renderResult.text ?? renderResult.caption ?? "",
      replyMarkup: renderResult.reply_markup ?? null,
    };
  if (
    ctx?.callbackQuery?.message?.chat?.id &&
    ctx?.callbackQuery?.message?.message_id
  )
    return {
      chatId: ctx.callbackQuery.message.chat.id,
      messageId: ctx.callbackQuery.message.message_id,
      text:
        ctx.callbackQuery.message.text ??
        ctx.callbackQuery.message.caption ??
        "",
      replyMarkup: ctx.callbackQuery.message.reply_markup ?? null,
    };
  return null;
}
// Fungsi extractTelegramErrorCode: menjalankan bagian extract telegram error code pada bot.
function extractTelegramErrorCode(error) {
  return (
    error?.response?.error_code ?? error?.code ?? error?.statusCode ?? null
  );
}
// Fungsi isTelegramConflictError: menjalankan bagian is telegram conflict error pada bot.
function isTelegramConflictError(error) {
  const code = extractTelegramErrorCode(error);
  const desc =
    error?.response?.description ||
    error?.description ||
    error?.message ||
    String(error);
  return code === 409 || /terminated by other getUpdates request/i.test(desc);
}
// Fungsi shutdownBot: menjalankan bagian shutdown bot pada bot.
async function shutdownBot(reason, exitCode = 1) {
  if (shutdownInProgress) return;
  shutdownInProgress = true;
  try {
    bot.stop(reason);
  } catch (err) {
    logIgnoredError("INDEX", "THROW_IGNORED", err);
  }
  // Tahap 10: tunggu runner pengecekan benar-benar melepas lock/lease/temp
  // sebelum socket WA dihentikan, agar shutdown tidak membuat pekerjaan yatim.
  await checkJobQueue.abortAllAndWait(
    new DOMException(`Bot shutdown: ${reason}`, "AbortError"),
  );
  try {
    await stopAllWA();
  } catch (err) {
    logIgnoredError("INDEX", "THROW_IGNORED", err);
  }
  await Promise.allSettled([
    stats.flushStats(),
    userPreferences.flushUserPreferences(),
    emojiMappings.flushEmojiMappings(),
  ]);
  process.exitCode = exitCode;
  await new Promise((r) => setTimeout(r, 75));
  process.exit(exitCode);
}
setAutoDisconnectNotifier(async (userId, meta = {}) => {
  pauseActiveCheckForDisconnect(userId, {
    code: null,
    codeName: "scheduled_24h",
    reason: meta?.reason || "scheduled_24h",
  });
  const chatId = Number(userId);
  if (!Number.isInteger(chatId) || chatId <= 0) return;
  const text = meta?.result?.authDeleted
    ? buildWaDisconnectedCard("Sesi diputus otomatis setelah 24 jam.")
    : buildFriendlyIssueCard(
        "SESI BELUM BERSIH",
        "Pemutusan otomatis belum selesai.",
        "Buka menu Sender lalu periksa status.",
      );
  try {
    await sendMessageSafe(
      chatId,
      text,
      {},
      { maxAttempts: 3, timeoutMs: 30000 },
    );
  } catch (err) {
    logApp(
      "WARN",
      userId,
      "WA_AUTO",
      "NOTIFY_FAIL",
      "gagal kirim notifikasi auto disconnect",
      { error: err.message },
    );
  }
});
// Fungsi ensureUserWAConnected: menjalankan bagian ensure user waconnected pada bot.
async function ensureUserWAConnected(userId, timeoutMs = 10000) {
  if (isConnected(userId)) return true;
  if (!hasAuthSession(userId)) return false;
  return ensureConnectedSession(userId, timeoutMs);
}

// Siapkan seluruh Sender milik user untuk /cekbio maupun /cekbiotxt. Setiap
// Sender dihidupkan secara independen dan kegagalan satu Sender tidak
// menggagalkan Sender lain. Pool selalu di-scope oleh Telegram user id.
async function prepareUserSenderPoolForCheck(userId, timeoutMs = 8000) {
  const senderIds = getKnownSenderIds(userId);
  if (!senderIds.length) return senderPool.getSnapshot(userId);

  await Promise.allSettled(
    senderIds.map(async (senderId) => {
      const connected = await ensureSenderConnectedSession(
        userId,
        senderId,
        timeoutMs,
      );
      if (connected) {
        markSenderReady(userId, senderId, {
          source: "check_sender_pool_prepare",
        });
      }
      return connected;
    }),
  );

  return senderPool.getSnapshot(userId);
}

function isMultiSenderCheckType(type) {
  return ["cekbio", "cekbiotxt"].includes(String(type || ""));
}

function getUserSenderPoolConnectivityState(userId) {
  const snapshot = senderPool.getSnapshot(userId);
  if (snapshot.available > 0) return "ready";
  if (snapshot.busy > 0 || snapshot.reconnecting > 0) return "reconnecting";
  return "dead";
}

function isCheckJobSenderReady(job, userId = job?.waSessionUserId ?? job?.userId) {
  if (isMultiSenderCheckType(job?.type)) {
    return senderPool.getSnapshot(userId).available > 0;
  }
  return isSessionReady(userId);
}

async function promoteReconnectedSenderToReady(userId, event = {}) {
  const senderId = String(event?.senderId || "default");
  if (event?.connection !== "open") return false;
  try {
    const connected = await ensureSenderConnectedSession(userId, senderId, 2500);
    if (!connected) return false;
    return markSenderReady(userId, senderId, {
      source: "paused_check_reconnect_ready",
    });
  } catch (error) {
    logIgnoredError("CHECK", "SENDER_RECONNECT_READY_FAIL", error);
    return false;
  }
}

// ========== STATE EXPIRY ==========
const STATE_TTL_MS = 5 * 60 * 1000; // 5 menit

// Fungsi setUserState: menjalankan bagian set user state pada bot.
function setUserState(userId, state) {
  const key = String(userId);
  userStates.set(key, {
    ...state,
    createdAt: Date.now(),
  });
}

// Fungsi getUserState: menjalankan bagian get user state pada bot.
function getUserState(userId) {
  const key = String(userId);
  const state = userStates.get(key);
  if (!state) return null;
  if (state.createdAt && Date.now() - state.createdAt > STATE_TTL_MS) {
    userStates.delete(key);
    return null;
  }
  return state;
}

// Fungsi clearUserState: menjalankan bagian clear user state pada bot.
function clearUserState(userId) {
  userStates.delete(String(userId));
}
// =================================

// ========== UI PANEL LAYER ==========

// Fungsi clampNumber: membatasi angka progres.
function clampNumber(value, min, max) {
  const num = Number(value);
  if (!Number.isFinite(num)) return min;
  return Math.min(max, Math.max(min, num));
}

const UI_PROGRESS_STEPS = [
  0, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95,
  100,
];

const TELEGRAM_MESSAGE_SNAPSHOT_LIMIT = 2000;

function getTelegramMessageSnapshotKey(chatId, messageId, inlineMessageId) {
  if (inlineMessageId) return `inline:${String(inlineMessageId)}`;
  if (chatId == null || messageId == null) return "";
  return `chat:${String(chatId)}:${String(messageId)}`;
}

function rememberTelegramTextMessage({
  chatId,
  messageId,
  inlineMessageId,
  text,
  replyMarkup,
}) {
  const key = getTelegramMessageSnapshotKey(chatId, messageId, inlineMessageId);
  if (!key) return;
  telegramMessageSnapshots.delete(key);
  telegramMessageSnapshots.set(key, {
    text: String(text ?? ""),
    reply_markup: replyMarkup ?? null,
  });
  while (telegramMessageSnapshots.size > TELEGRAM_MESSAGE_SNAPSHOT_LIMIT) {
    telegramMessageSnapshots.delete(telegramMessageSnapshots.keys().next().value);
  }
}

function rememberTelegramApiTextResult(
  result,
  { chatId, messageId, inlineMessageId, text, replyMarkup },
) {
  rememberTelegramTextMessage({
    chatId: result?.chat?.id ?? chatId,
    messageId: result?.message_id ?? messageId,
    inlineMessageId,
    text: result?.text ?? result?.caption ?? text,
    replyMarkup: result?.reply_markup ?? replyMarkup ?? null,
  });
  return result;
}

function getKnownTelegramTextMessage(ctx, chatId, messageId, inlineMessageId) {
  const callbackMessage = ctx?.callbackQuery?.message;
  const callbackMatches =
    callbackMessage &&
    (inlineMessageId ||
      (String(callbackMessage.chat?.id) === String(chatId) &&
        String(callbackMessage.message_id) === String(messageId)));
  if (callbackMatches) return callbackMessage;

  const key = getTelegramMessageSnapshotKey(chatId, messageId, inlineMessageId);
  return key ? telegramMessageSnapshots.get(key) || null : null;
}

function shouldSkipTelegramTextEdit(
  ctx,
  chatId,
  messageId,
  inlineMessageId,
  text,
  options = {},
) {
  const currentMessage = getKnownTelegramTextMessage(
    ctx,
    chatId,
    messageId,
    inlineMessageId,
  );
  return areTelegramMessageContentsEqual(
    currentMessage,
    text,
    options.reply_markup,
    { parseMode: options.parse_mode },
  );
}

// Fungsi uxProgressBar: membuat progress bar 10 slot dengan blok setengah untuk 5%.
function uxProgressBar(done, total) {
  const safeTotal = Math.max(1, Number(total) || 1);
  const safeDone = clampNumber(done, 0, safeTotal);
  const ratio = safeDone / safeTotal;
  const percent = clampNumber(Math.round(ratio * 20) * 5, 0, 100);
  return uxProgressBarPercent(percent);
}

// Fungsi uxProgressBarPercent: membuat progress bar dari persentase langsung.
function uxProgressBarPercent(percent) {
  const pct = clampNumber(Math.round((Number(percent) || 0) / 5) * 5, 0, 100);
  if (pct <= 0) return `░░░░░░░░░░ 0%`;
  if (pct >= 100) return `██████████ 100%`;
  const full = Math.floor(pct / 10);
  const half = pct % 10 >= 5;
  const empty = Math.max(0, 10 - full - (half ? 1 : 0));
  return `${"█".repeat(full)}${half ? "▌" : ""}${"░".repeat(empty)} ${pct}%`;
}

// Fungsi animateProgressPanelByMeta: mengedit panel progres dari 0 sampai 100%.
async function animateProgressPanelByMeta(
  panelMeta,
  builder,
  keyboard,
  extra = {},
) {
  let meta = panelMeta;
  for (const percent of UI_PROGRESS_STEPS) {
    meta =
      (await editOrSendTextPanelByMeta(
        meta,
        builder(percent),
        keyboard,
        extra,
      ).catch((err) => {
        logIgnoredError("INDEX", "PROMISE_IGNORED", err);
        return meta;
      })) || meta;
    if (percent < 100) await sleep(650);
  }
  return meta;
}

// Fungsi uxPluralNomor: memformat jumlah nomor.
function uxPluralNomor(count) {
  return `${new Intl.NumberFormat("id-ID").format(Number(count) || 0)} nomor`;
}

// Fungsi buildPrepCard: membuat kartu persiapan pengecekan.
function buildPrepCard({
  mode = "Nomor",
  total = null,
  fileName = "",
  stage = "Proses dimulai",
}) {
  const lines = [
    `${ACCENTS.low} Mode: ${mode}`,
    total != null ? `${ACCENTS.total} Total: ${uxPluralNomor(total)}` : "",
    fileName ? `${ACCENTS.standard} File: ${fileName}` : "",
    `${ACCENTS.status} Progres: ${uxProgressBarPercent(0)}`,
    `${ACCENTS.low} ${stage}`,
  ];
  return boxPanel("CEKBIO PROSES", lines.filter(Boolean));
}

// Fungsi formatCompactEta: estimasi waktu tersisa untuk panel cek ringkas.
function formatCompactEta(done, total, startedAt, now = Date.now()) {
  const safeDone = Math.max(0, Number(done) || 0);
  const safeTotal = Math.max(1, Number(total) || 1);
  const start = Number(startedAt) || 0;
  if (!start || safeDone <= 0 || safeDone >= safeTotal) {
    return safeDone >= safeTotal ? "selesai" : "menghitung...";
  }
  const elapsedMs = Math.max(1, Number(now) - start);
  const ratePerMs = safeDone / elapsedMs;
  if (!Number.isFinite(ratePerMs) || ratePerMs <= 0) return "menghitung...";
  const remainingSeconds = Math.max(1, Math.ceil((safeTotal - safeDone) / ratePerMs / 1000));
  if (remainingSeconds < 60) return `~${remainingSeconds} dtk lagi`;
  const remainingMinutes = Math.ceil(remainingSeconds / 60);
  if (remainingMinutes < 60) return `~${remainingMinutes} mnt lagi`;
  const remainingHours = Math.ceil(remainingMinutes / 60);
  return `~${remainingHours} jam lagi`;
}

function compactProgressBar(done, total, width = 8) {
  const safeTotal = Math.max(1, Number(total) || 1);
  const safeDone = clampNumber(done, 0, safeTotal);
  const safeWidth = Math.max(4, Math.min(16, Number(width) || 8));
  const ratio = safeDone / safeTotal;
  const filled = clampNumber(Math.round(ratio * safeWidth), 0, safeWidth);
  return `${"█".repeat(filled)}${"░".repeat(safeWidth - filled)}`;
}

// Fungsi buildCheckProgressCard: panel cek ringkas seperti terminal, satu bubble saja.
function buildCheckProgressCard({
  done = 0,
  total = 1,
  senderCount = 0,
  batchSize = 1,
  startedAt = 0,
}) {
  const safeTotal = Math.max(1, Number(total) || 1);
  const safeDone = clampNumber(done, 0, safeTotal);
  const percent = clampNumber(Math.floor((safeDone / safeTotal) * 100), 0, 100);
  const senders = Math.max(0, Number(senderCount) || 0);
  const batch = Math.max(1, Number(batchSize) || 1);
  const eta = formatCompactEta(safeDone, safeTotal, startedAt);
  return [
    "🔎 Checking Business Profiles...",
    "┌────────────────────────",
    `├ ${compactProgressBar(safeDone, safeTotal)} ${percent}%`,
    `├ ${safeDone}/${safeTotal} · ${eta}`,
    `└ 📡 ${senders} sender · ⚡ ${batch}/batch`,
  ].join("\n");
}

// Fungsi buildReportDeliveryCard: membuat kartu persiapan laporan.
function buildReportDeliveryCard({
  mode = "Nomor",
  batchIndex = 0,
  batchTotal = 1,
  total = 0,
}) {
  return boxPanel("CEKBIO LAPORAN", [
    `${ACCENTS.low} Mode: ${mode}`,
    `${ACCENTS.total} Total: ${uxPluralNomor(total)}`,
    `${ACCENTS.status} Progres: ${uxProgressBarPercent(100)}`,
    `${ACCENTS.standard} Laporan lengkap dan ringkas sedang disiapkan.`,
  ]);
}

// Fungsi sendPolishAction: menjalankan bagian send polish action pada bot.
async function sendPolishAction(ctx, action = "typing", { signal } = {}) {
  if (!ctx?.chat?.id) return null;
  return telegramCallWithRetry(
    ctx,
    "sendChatAction",
    (attemptSignal) =>
      bot.telegram.callApi(
        "sendChatAction",
        { chat_id: ctx.chat.id, action },
        { signal: attemptSignal },
      ),
    { maxAttempts: 2, timeoutMs: 15000, signal },
  ).catch((err) => {
    logIgnoredError("INDEX", "PROMISE_NULL", err);
    return null;
  });
}
// =======================================

// ─── Resolve semua title & url dari ID saat startup ────────────────────────
// Fungsi resolveForceJoinTargets: menjalankan bagian resolve force join targets pada bot.
async function resolveForceJoinTargets() {
  _resolvedForceJoinTargets.length = 0;
  for (let i = 0; i < RAW_FORCE_JOIN_TARGETS.length; i++) {
    const raw = RAW_FORCE_JOIN_TARGETS[i];
    const chat = String(raw.chat || "").trim();
    if (!chat) continue;
    let title = String(raw.title || "").trim();
    let url = String(raw.url || "").trim() || deriveTelegramJoinUrl(chat);

    // Auto-fetch info dari Telegram
    try {
      const info = await bot.telegram.getChat(chat);
      if (!title) title = info.title || info.username || `Target ${i + 1}`;

      // Prioritas URL: username publik > invite_link yang sudah ada > export baru
      if (!url) {
        if (info.username) {
          url = `https://t.me/${info.username}`;
        } else if (info.invite_link) {
          url = info.invite_link;
        } else {
          // Channel/grup private — minta invite link baru (bot harus admin)
          try {
            const inviteLink = await bot.telegram.exportChatInviteLink(chat);
            if (inviteLink) url = inviteLink;
          } catch (inviteErr) {
            console.warn(
              `[WARN][FORCE_JOIN] gagal export invite link target ${i + 1} (${chat}): ${inviteErr.message}`,
            );
          }
        }
      }
    } catch (err) {
      console.warn(
        `[WARN][FORCE_JOIN] gagal getChat target ${i + 1} (${chat}): ${err.message}`,
      );
      if (!title) title = `Target ${i + 1}`;
    }

    _resolvedForceJoinTargets.push({
      key: `target_${i}`,
      index: i,
      chat,
      title,
      url,
    });
  }
  if (_resolvedForceJoinTargets.length > 0) {
    console.log(
      `[FORCE_JOIN] ${_resolvedForceJoinTargets.length} target berhasil dimuat:`,
      _resolvedForceJoinTargets
        .map((t) => `${t.title} → ${t.url || "(no url)"} (${t.chat})`)
        .join("\n  "),
    );
  }
}

// Fungsi getForceJoinTargets: menjalankan bagian get force join targets pada bot.
function getForceJoinTargets() {
  // Gunakan resolved jika sudah ada, fallback ke raw belum di-resolve
  if (_resolvedForceJoinTargets.length > 0) return _resolvedForceJoinTargets;
  return RAW_FORCE_JOIN_TARGETS.map((raw, i) => {
    const chat = String(raw.chat || "").trim();
    const title = String(raw.title || "").trim() || `Target ${i + 1}`;
    const url = String(raw.url || "").trim() || deriveTelegramJoinUrl(chat);
    return {
      key: `target_${i}`,
      index: i,
      chat,
      title,
      url,
    };
  });
}
// Fungsi isForceJoinEnabled: menjalankan bagian is force join enabled pada bot.
function isForceJoinEnabled() {
  return getForceJoinTargets().length > 0;
}

// Fungsi forceJoinKeyboard: menjalankan bagian force join keyboard pada bot.
function forceJoinKeyboard() {
  return keyboardPresentation.forceJoinKeyboard({
    targets: getForceJoinTargets(),
    callbacks: CALLBACKS,
    folderUrl: FORCE_JOIN_FOLDER_URL,
  });
}

// Fungsi forceJoinKeyboardWithStatus: menjalankan bagian force join keyboard with status pada bot.
function forceJoinKeyboardWithStatus(targetStatuses) {
  return keyboardPresentation.forceJoinKeyboard({
    targets: targetStatuses,
    callbacks: CALLBACKS,
    folderUrl: FORCE_JOIN_FOLDER_URL,
    withStatus: true,
  });
}

// Fungsi getForceJoinWelcomeText: menjalankan bagian get force join welcome text pada bot.
function getForceJoinWelcomeText() {
  return buildForceJoinWelcomeCard({
    folderMode: Boolean(FORCE_JOIN_FOLDER_URL),
    targetCount: getForceJoinTargets().length,
  });
}

// Fungsi getForceJoinFailedText: menjalankan bagian get force join failed text pada bot.
function getForceJoinFailedText(joinStatus) {
  return buildForceJoinFailedCard({
    folderMode: Boolean(FORCE_JOIN_FOLDER_URL),
    joinStatus,
  });
}

// Fungsi getForceJoinVerifiedText: menjalankan bagian get force join verified text pada bot.
function getForceJoinVerifiedText() {
  return boxPanel("AKSES TERBUKA", [
    "✅ Semua membership terverifikasi.",
    "🚀 Semua fitur siap digunakan.",
  ]);
}

// Fungsi getForceJoinUnavailableText: menjalankan bagian get force join unavailable text pada bot.
function getForceJoinUnavailableText(joinStatus) {
  const unavailable = joinStatus?.failedTargets || [];
  return warningPanel("VERIFIKASI BELUM TERSEDIA", [
    "Bot belum dapat memeriksa membership.",
    `❌ Target bermasalah: ${Math.max(1, unavailable.length)}`,
    "👉 Pastikan bot menjadi admin grup/channel.",
  ]);
}
// Force-join tidak boleh membuat setiap command terasa hang. Status yang sudah
// terverifikasi di-cache singkat dan semua target diperiksa paralel, bukan 6
// request getChatMember berurutan. Tombol Verifikasi tetap dapat memaksa refresh.
const FORCE_JOIN_SUCCESS_CACHE_MS = 60 * 1000;
const FORCE_JOIN_FAILURE_CACHE_MS = 8 * 1000;
const forceJoinStatusCache = new Map();
const forceJoinStatusInFlight = new Map();

async function verifyForceJoinTarget(userId, target) {
  try {
    const member = await telegramCallWithRetry(
      userId,
      `FORCE_JOIN_VERIFY_${target.key.toUpperCase()}`,
      (signal) =>
        bot.telegram.callApi(
          "getChatMember",
          { chat_id: target.chat, user_id: userId },
          { signal },
        ),
      { maxAttempts: 2, timeoutMs: 7000 },
    );
    const status = String(member?.status || "").toLowerCase();
    const joined = !["left", "kicked"].includes(status);
    return { ...target, joined, canVerify: true, status };
  } catch (error) {
    const errorCode = error?.response?.error_code;
    const isNetworkError =
      /ECONNRESET|ETIMEDOUT|EPIPE|ENETUNREACH|EAI_AGAIN|fetch failed|socket hang up|timeout/i.test(
        String(error?.code || error?.errno || error?.message || ""),
      );

    if (
      errorCode === 403 ||
      (error.message && error.message.includes("bot is not a member"))
    ) {
      return {
        ...target,
        joined: false,
        canVerify: false,
        error: "Bot tidak memiliki akses verifikasi ke target ini. Tambahkan bot sebagai admin.",
      };
    }

    if (isNetworkError) {
      // Gangguan Telegram sementara tidak boleh membekukan seluruh command.
      logApp(
        "WARN",
        userId,
        "FORCE_JOIN",
        `VERIFY_${target.key.toUpperCase()}`,
        "verifikasi dilewati karena network error sementara",
        { error: error.message },
      );
      return {
        ...target,
        joined: true,
        canVerify: false,
        error: error.message || String(error),
      };
    }

    console.error(
      `[ERROR][FORCE_JOIN][VERIFY][${target.key.toUpperCase()}]`,
      error.message,
    );
    return {
      ...target,
      joined: false,
      canVerify: false,
      error: error.message || String(error),
    };
  }
}

// Fungsi getForceJoinStatus: cache + single-flight agar burst command user yang
// sama tidak menembakkan verifikasi membership berkali-kali.
async function getForceJoinStatus(userId, { force = false } = {}) {
  if (!isForceJoinEnabled()) {
    return { enabled: false, joined: true, canVerify: false, targets: [] };
  }

  const cacheKey = String(userId);
  const now = Date.now();
  const cached = forceJoinStatusCache.get(cacheKey);
  if (!force && cached && cached.expiresAt > now) return cached.value;

  if (!force && forceJoinStatusInFlight.has(cacheKey)) {
    return forceJoinStatusInFlight.get(cacheKey);
  }

  const verifyPromise = (async () => {
    const targets = getForceJoinTargets();
    const targetStatuses = await Promise.all(
      targets.map((target) => verifyForceJoinTarget(userId, target)),
    );
    const missingTargets = targetStatuses.filter((target) => !target.joined);
    const failedTargets = targetStatuses.filter((target) => !target.canVerify);
    const value = {
      enabled: true,
      joined: missingTargets.length === 0,
      canVerify: failedTargets.length === 0,
      targets: targetStatuses,
      missingTargets,
      failedTargets,
    };
    const ttl = value.joined && value.canVerify
      ? FORCE_JOIN_SUCCESS_CACHE_MS
      : FORCE_JOIN_FAILURE_CACHE_MS;
    forceJoinStatusCache.set(cacheKey, { value, expiresAt: Date.now() + ttl });
    return value;
  })();

  forceJoinStatusInFlight.set(cacheKey, verifyPromise);
  try {
    return await verifyPromise;
  } finally {
    if (forceJoinStatusInFlight.get(cacheKey) === verifyPromise) {
      forceJoinStatusInFlight.delete(cacheKey);
    }
  }
}
// Fungsi showForceJoinGate: menjalankan bagian show force join gate pada bot.
async function showForceJoinGate(ctx, variant = "welcome", joinStatus = null) {
  const text =
    variant === "verified"
      ? getForceJoinVerifiedText()
      : variant === "failed"
        ? getForceJoinFailedText(joinStatus)
        : variant === "unavailable"
          ? getForceJoinUnavailableText(joinStatus)
          : getForceJoinWelcomeText();

  // Pakai keyboard dengan status ✅/❌ kalau ada joinStatus, fallback ke default
  const keyboard =
    joinStatus?.targets?.length > 0
      ? forceJoinKeyboardWithStatus(joinStatus.targets)
      : forceJoinKeyboard();

  return renderCleanTextPanel(ctx, text, keyboard);
}
// Lock pengecekan menggunakan ID sesi WA agar command private/grup tidak bertabrakan.
function getCheckLockKey(waSessionUserId) {
  return `wa-session:${String(waSessionUserId)}`;
}

function buildActiveJobMessage(activeJob) {
  if (activeJob?.status === "paused" && activeJob.pauseManifest) {
    return buildPausedCheckCard({
      checked: activeJob.pauseManifest.checkedCount,
      pending: activeJob.pauseManifest.pendingCount,
      total: activeJob.pauseManifest.total,
    });
  }
  return buildActiveJobCard(activeJob);
}

function activeJobKeyboard(activeJob) {
  return activeJob?.status === "paused"
    ? pausedCheckKeyboard()
    : activeCheckKeyboard();
}

function bindAbortToWaSession(waSessionUserId, signal) {
  if (!signal) return () => {};
  const abortSession = () => {
    void stopWA(waSessionUserId).catch((error) => {
      logApp("WARN", waSessionUserId, "CHECK", "ABORT_SESSION_FAIL", "gagal menghentikan sesi setelah abort", {
        error: error?.message || String(error),
      });
    });
  };
  if (signal.aborted) abortSession();
  else signal.addEventListener("abort", abortSession, { once: true });
  return () => signal.removeEventListener("abort", abortSession);
}

function waitForPausedJobAction(job, signal) {
  return new Promise((resolve, reject) => {
    const cleanup = () => {
      signal?.removeEventListener("abort", onAbort);
      if (job.resumePausedCheck === resume) job.resumePausedCheck = null;
      if (job.finalizePausedCheck === finalize) job.finalizePausedCheck = null;
    };
    const resume = () => {
      cleanup();
      resolve("resume");
    };
    const finalize = () => {
      cleanup();
      resolve("finalize");
    };
    const onAbort = () => {
      cleanup();
      reject(signal.reason || new DOMException("Job dibatalkan.", "AbortError"));
    };
    job.resumePausedCheck = resume;
    job.finalizePausedCheck = finalize;
    if (signal?.aborted) onAbort();
    else signal?.addEventListener("abort", onAbort, { once: true });
  });
}

async function renderPausedReconnectPanel(job, ctx = null) {
  if (!job?.pauseContext) return null;
  const renderCtx = ctx || job.pauseContext.ctx;
  if (!renderCtx) return null;
  return renderCheckLifecyclePanelSafe(
    renderCtx,
    job,
    buildResumeNeedsConnectionCard(),
    resumeNeedsConnectionKeyboard(),
    {
      signal: job.controller?.signal,
      logCode: "RECONNECT_PANEL_FAIL",
      fallbackPanel: ctx?.callbackQuery?.message || null,
    },
  );
}

function canClaimPausedResume(job) {
  if (
    !job ||
    job.status !== "paused" ||
    !job.pauseContext ||
    job.finalizationInProgress ||
    job.sendConfirmationPending ||
    job.resumeRequested ||
    job.reconnectResumeClaimed ||
    job.controller?.signal?.aborted
  ) {
    return false;
  }
  // Atomic single-flight claim: set before any UI update or runner wake-up.
  job.reconnectResumeClaimed = true;
  job.resumeRequested = true;
  return true;
}

async function continuePausedCheck(job, ctx = null, { claimed = false } = {}) {
  if (!job?.pauseContext || job.status !== "paused") return { status: "missing" };
  const userId = job.waSessionUserId ?? job.userId;
  if (!claimed && !canClaimPausedResume(job)) return { status: "busy" };

  clearPausedReconnectWait(job, { preserveClaim: claimed || job.reconnectResumeClaimed });
  if (isMultiSenderCheckType(job.type) && !isCheckJobSenderReady(job, userId)) {
    await prepareUserSenderPoolForCheck(userId, 2500).catch((error) =>
      logIgnoredError("CHECK", "RESUME_POOL_PREPARE_FAIL", error),
    );
  }
  if (!isCheckJobSenderReady(job, userId)) {
    job.resumeRequested = false;
    job.reconnectResumeClaimed = false;
    armPausedReconnectResume(job, ctx);
    return { status: "waiting" };
  }

  const { state, mode, fileName } = job.pauseContext;
  const total = state.total;
  const done = state.nextIndex;
  const safeChunkSize = Math.max(1, Number(config.CHUNK_SIZE) || 200);
  const batchTotal = Math.max(1, Math.ceil(total / safeChunkSize));
  const batchIndex = Math.min(
    batchTotal - 1,
    Math.floor(Math.max(0, done - 1) / safeChunkSize),
  );
  const renderCtx = ctx || job.pauseContext.ctx;

  const resumeSpeed = normalizeCheckSpeed(
    job.speedPerSender ?? job.pauseContext?.speedPerSender,
  );
  const resumeSenderSnapshot = senderCheckRouter.getSnapshot(userId, {
    maxActivePerSender: resumeSpeed,
  });
  const resumeSenderCount = resumeSenderSnapshot.ready + resumeSenderSnapshot.busy;
  const resumeBatchSize = senderCheckRouter.getConcurrency(
    userId,
    runtime.MULTI_SENDER_MAX_CONCURRENCY,
    {
      maxActivePerSender: resumeSpeed,
      totalLimit: Math.max(1, total - done),
    },
  );
  await renderCheckLifecyclePanelSafe(
    renderCtx,
    job,
    buildCheckProgressCard({
      done,
      total,
      senderCount: resumeSenderCount,
      batchSize: resumeBatchSize,
      startedAt: job.checkStartedAt || Date.now(),
    }),
    activeCheckKeyboard(),
    {
      signal: job.controller?.signal,
      logCode: "AUTO_RESUME_PANEL_FAIL",
      fallbackPanel: ctx?.callbackQuery?.message || null,
    },
  );

  // A second application-ready check closes the race between the WA
  // TERSAMBUNG notification and waking the paused runner.
  if (!isCheckJobSenderReady(job, userId)) {
    job.resumeRequested = false;
    job.reconnectResumeClaimed = false;
    armPausedReconnectResume(job, renderCtx);
    return { status: "waiting" };
  }

  const resume = job.resumePausedCheck;
  if (typeof resume !== "function") {
    job.resumeRequested = false;
    job.reconnectResumeClaimed = false;
    return { status: "missing" };
  }
  resume();
  return { status: "resumed" };
}

function armPausedReconnectResume(job, ctx = null) {
  if (!job?.pauseContext) return false;
  const userId = job.waSessionUserId ?? job.userId;
  const multiSender = isMultiSenderCheckType(job.type);

  const subscribeConnectivity = multiSender
    ? (ownerId, listener) =>
        subscribeSenderConnectivity(ownerId, (event) => {
          if (event?.connection === "open") {
            void promoteReconnectedSenderToReady(ownerId, event);
          }
          return listener(event);
        })
    : subscribeSessionConnectivity;
  const subscribeReady = multiSender
    ? subscribeSenderConnectivity
    : subscribeSessionReady;
  const getConnectivityState = multiSender
    ? getUserSenderPoolConnectivityState
    : getSessionConnectivityState;
  const isReady = multiSender
    ? (ownerId) => senderPool.getSnapshot(ownerId).available > 0
    : isSessionReady;

  return armPausedReconnectWait(job, {
    userId,
    subscribeConnectivity,
    subscribeReady,
    getConnectivityState,
    isReady,
    claimResume: canClaimPausedResume,
    onReady: () => continuePausedCheck(job, ctx || job.pauseContext?.ctx, { claimed: true }),
    onDisconnected: () =>
      renderPausedReconnectPanel(job, ctx || job.pauseContext?.ctx).catch((error) =>
        logIgnoredError("CHECK", "RECONNECT_PANEL_FAIL", error),
      ),
    onError: (error) =>
      logIgnoredError("CHECK", "AUTO_RESUME_LISTENER_FAIL", error),
  });
}

function pauseActiveCheckForDisconnect(waSessionUserId, meta = {}) {
  const activeJob = checkJobQueue.get(getCheckLockKey(waSessionUserId));
  if (!activeJob || activeJob.status !== "running") return false;

  if (isMultiSenderCheckType(activeJob.type)) {
    const snapshot = senderPool.getSnapshot(waSessionUserId);
    // Satu Sender terminal tidak boleh menghentikan job selama Sender lain
    // milik user masih READY atau sedang BUSY mengerjakan task. Task pada
    // Sender yang jatuh akan dipindahkan oleh sender-check-router.
    if (snapshot.available > 0 || snapshot.busy > 0) {
      logApp(
        "WARN",
        waSessionUserId,
        "CHECK",
        "SENDER_TERMINAL_FAILOVER",
        "satu Sender jatuh; pengecekan tetap berjalan lewat Sender lain",
        {
          senderId: meta.senderId || "default",
          code: meta.code ?? "-",
          codeName: meta.codeName || "-",
          available: snapshot.available,
          busy: snapshot.busy,
        },
      );
      return false;
    }
  }

  const controller = activeJob.sessionDisconnectController;
  if (!controller || controller.signal.aborted) return false;
  logApp(
    "WARN",
    waSessionUserId,
    "CHECK",
    "WA_TERMINAL_DISCONNECT",
    isMultiSenderCheckType(activeJob.type)
      ? "semua Sender tidak tersedia; pengecekan akan dijeda"
      : "sesi WA jatuh permanen; pengecekan akan dijeda",
    {
      senderId: meta.senderId || "default",
      code: meta.code ?? "-",
      codeName: meta.codeName || "-",
      reason: meta.reason || "-",
    },
  );
  controller.abort(new WaSessionDisconnectedError(meta));
  return true;
}

setTerminalDisconnectNotifier(async (userId, meta = {}) => {
  // Failover/pause job tetap diproses lebih dulu. Notifikasi ini hanya untuk
  // disconnect terminal tak terduga; disconnect manual dari tombol memiliki
  // stopRequested=true sehingga tidak masuk notifier ini.
  pauseActiveCheckForDisconnect(userId, meta);

  const chatId = Number(userId);
  if (!Number.isInteger(chatId) || chatId <= 0) return;
  try {
    await sendMessageSafe(
      chatId,
      buildSenderUnexpectedDisconnectNotice(meta.number),
      {},
      { maxAttempts: 3, timeoutMs: 30000 },
    );
  } catch (error) {
    logApp(
      "WARN",
      userId,
      "SENDER",
      "TERMINAL_DISCONNECT_NOTIFY_FAIL",
      "gagal mengirim notifikasi Sender terputus",
      {
        senderId: meta.senderId || "default",
        error: error?.message || String(error),
      },
    );
  }
});

// Fungsi abortActiveCheck: membatalkan job milik sesi user lalu menunggu lock queue dilepas.
async function abortActiveCheck(ctx) {
  const userId = ctx.from.id;
  const lockKey = getCheckLockKey(userId);
  const activeJob = checkJobQueue.get(lockKey);

  if (!activeJob) {
    return renderTextPanel(
      ctx,
      boxPanel("TIDAK ADA PENGECEKAN", [
        `${ACCENTS.low} Tidak ada pengecekan aktif untuk sesi ini.`,
      ]),
      contextMainKeyboard(ctx, userId),
    );
  }

  activeJob.userAbortRequested = true;
  const result = await checkJobQueue.abortAndWait(
    lockKey,
    new DOMException("Pengecekan dibatalkan oleh pengguna.", "AbortError"),
  );

  if (!result.released) {
    return renderTextPanel(
      ctx,
      buildFriendlyIssueCard(
        "PEMBATALAN TERTAHAN",
        "Job sudah menerima sinyal batal, tetapi lock belum terlepas.",
        "Tunggu beberapa saat lalu buka menu kembali.",
      ),
      contextMainKeyboard(ctx, userId),
    );
  }

  return renderTextPanel(
    ctx,
    boxPanel("PENGECEKAN DIBATALKAN", [
      `${ACCENTS.success} Pengecekan dibatalkan.`,
      `${ACCENTS.status} Lock sesi telah dilepas.`,
    ]),
    contextMainKeyboard(ctx, userId),
  );
}

// Fungsi runCheckInBackground: menerima lock secara atomik dan selalu melepasnya lewat finally queue.
async function runCheckInBackground(ctx, type, waSessionUserId, runner) {
  const lockKey = getCheckLockKey(waSessionUserId);
  const activeJob = checkJobQueue.get(lockKey);
  if (activeJob) {
    return replySafe(
      ctx,
      buildActiveJobMessage(activeJob),
      activeJobKeyboard(activeJob),
    );
  }

  await sendPolishAction(ctx);
  const sessionDisconnectController = new AbortController();
  const started = checkJobQueue.start(
    lockKey,
    {
      id: `${type}-${ctx.from.id}-${Date.now()}`,
      type,
      userId: ctx.from.id,
      waSessionUserId,
      sessionDisconnectController,
    },
    async ({ signal, job }) => {
      // Lepaskan handler update Telegram lebih dulu; job berat mulai pada tick
      // berikutnya sehingga polling tidak ikut terseret oleh persiapan cek.
      await new Promise((resolve) => setImmediate(resolve));
      signal.throwIfAborted();
      const unbindAbort = bindAbortToWaSession(waSessionUserId, signal);
      try {
        return await runner({ signal, job });
      } finally {
        clearPausedReconnectWait(job);
        job.resumePausedCheck = null;
        job.finalizePausedCheck = null;
        if (signal.aborted) {
          await deleteCheckProgress(ctx, job).catch(() => {});
        }
        unbindAbort();
      }
    },
  );

  if (!started.accepted) {
    return replySafe(
      ctx,
      buildActiveJobMessage(started.activeJob),
      activeJobKeyboard(started.activeJob),
    );
  }

  started.promise.catch(async (error) => {
    const aborted = started.job.controller.signal.aborted;
    logApp(
      aborted ? "WARN" : "ERROR",
      ctx,
      "CHECK",
      aborted ? "JOB_ABORTED" : "JOB_FAIL",
      `${type} ${aborted ? "dihentikan" : "gagal"}`,
      { error: error?.message || String(error) },
    );
    if (aborted && started.job.userAbortRequested) return;
    await sendMessageSafe(
      ctx.chat.id,
      buildFriendlyIssueCard(
        aborted ? "PENGECEKAN DIHENTIKAN" : "SESI CHECK TERTAHAN",
        aborted
          ? "Proses melewati batas waktu atau dibatalkan."
          : "Permintaan belum bisa diselesaikan dengan mulus.",
        aborted
          ? "Sesi kerja telah dilepas. Jalankan ulang pengecekan bila diperlukan."
          : "Coba ulangi atau hubungi owner bila kejadian ini berulang.",
      ),
      contextMainKeyboard(ctx, ctx.from.id),
      { maxAttempts: 2, timeoutMs: 20000 },
    ).catch(() => {});
  }).finally(() => {
    logApp(
      "INFO",
      ctx,
      "CHECK",
      "JOB_RELEASED",
      `${type} selesai dan lock user dilepas`,
      { activeJobs: checkJobQueue.getActiveCount() },
    );
  });

  return true;
}

// Banner cache
// Runtime state dibaca satu kali saat startup agar middleware tidak melakukan I/O sinkron.
async function loadRuntimeState() {
  const [maintenance, banner] = await Promise.all([
    readJsonFile(MAINTENANCE_PATH, {}),
    readJsonFile(BANNER_CACHE_PATH, null),
  ]);
  maintenanceMode = maintenance?.maintenance === true || maintenance?.enabled === true;
  cachedBannerFileId = typeof banner?.file_id === "string" ? banner.file_id : null;
}

async function saveBannerCache(fileId) {
  cachedBannerFileId = fileId;
  await writeJsonFileAtomic(BANNER_CACHE_PATH, {
    file_id: fileId,
    savedAt: new Date().toISOString(),
  });
  console.log(`${ACCENTS.success} Banner file_id tersimpan:`, fileId);
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// Fungsi getTelegramErrorMessage: menjalankan bagian get telegram error message pada bot.
function getTelegramErrorChain(error, maxDepth = 6) {
  const chain = [];
  const seen = new Set();
  let current = error;
  while (current && chain.length < maxDepth && !seen.has(current)) {
    chain.push(current);
    seen.add(current);
    current = current.cause;
  }
  return chain;
}

function getTelegramErrorMessage(error) {
  return getTelegramErrorChain(error)
    .flatMap((item) => [
      item?.code,
      item?.errno,
      item?.type,
      item?.response?.error_code,
      item?.response?.description,
      item?.message,
    ])
    .filter(Boolean)
    .map(String)
    .filter((value, index, values) => values.indexOf(value) === index)
    .join(" | ");
}

const TELEGRAM_TEXT_SAFE_LIMIT = 3900;

function replyMarkupHasCustomEmoji(replyMarkup) {
  if (!replyMarkup || typeof replyMarkup !== "object") return false;
  const rows = replyMarkup.inline_keyboard || replyMarkup.keyboard || [];
  return rows.some((row) =>
    (row || []).some((button) => Boolean(button?.icon_custom_emoji_id)),
  );
}

function prepareUiTelegramText(text, options = {}) {
  const safeOptions = { ...(options || {}) };
  const skipEmoji = safeOptions.skip_ui_emoji === true;
  delete safeOptions.skip_ui_emoji;
  if (skipEmoji) {
    return { text: String(text ?? ""), options: safeOptions, customEmojiApplied: false };
  }
  const applied = applyMappingsToTelegramText(text, safeOptions);
  return {
    text: applied.text,
    options: applied.options,
    customEmojiApplied:
      applied.changed === true || replyMarkupHasCustomEmoji(applied.options?.reply_markup),
  };
}

function stripUiCustomEmojiHtml(text) {
  return String(text ?? "").replace(
    /<tg-emoji\b[^>]*>([\s\S]*?)<\/tg-emoji>/gi,
    "$1",
  );
}

function removeUiCustomEmojiFromOptions(options = {}) {
  const next = { ...(options || {}) };
  if (next.reply_markup) {
    next.reply_markup = removeButtonCustomEmoji(next.reply_markup);
  }
  return next;
}

function isCustomEmojiTelegramError(error) {
  const status = Number(error?.response?.error_code || error?.statusCode || error?.status || 0);
  if (status && status !== 400) return false;
  return /custom.?emoji|icon_custom_emoji|tg-emoji|emoji-id/i.test(
    getTelegramErrorMessage(error),
  );
}

// Fungsi clampTelegramText: menjalankan bagian clamp telegram text pada bot.
function clampTelegramText(text, limit = TELEGRAM_TEXT_SAFE_LIMIT) {
  const value = String(text ?? "");
  if (value.length <= limit) return value;
  const suffix =
    "\n\n…\nPanel diringkas agar tetap rapi. Buka halaman berikutnya atau ekspor dokumen untuk detail lengkap.";
  return value.slice(0, Math.max(0, limit - suffix.length)) + suffix;
}

// Fungsi isTelegramMessageTooLongError: menjalankan bagian is telegram message too long error pada bot.
function isTelegramMessageTooLongError(error) {
  const status = Number(error?.response?.error_code || error?.statusCode || 0);
  const text = getTelegramErrorMessage(error);
  return status === 400 && /MESSAGE_TOO_LONG|message is too long/i.test(text);
}

// Fungsi isTelegramMessageNotModifiedError: menjalankan bagian is telegram message not modified error pada bot.
function isTelegramMessageNotModifiedError(error) {
  const status = Number(error?.response?.error_code || error?.statusCode || 0);
  const text = getTelegramErrorMessage(error);
  return status === 400 && /message is not modified/i.test(text);
}

// Fungsi isTelegramBlockedByUserError: menjalankan bagian is telegram blocked by user error pada bot.
function isTelegramBlockedByUserError(error) {
  const status = Number(error?.response?.error_code || error?.statusCode || 0);
  const text = getTelegramErrorMessage(error);
  return (
    status === 403 &&
    /bot was blocked by the user|user is deactivated|forbidden/i.test(text)
  );
}

// Fungsi isIgnorableTelegramError: menjalankan bagian is ignorable telegram error pada bot.
function isIgnorableTelegramError(error) {
  return (
    isTelegramMessageNotModifiedError(error) ||
    isTelegramBlockedByUserError(error)
  );
}

// Fungsi editMessageTextSafe: edit pesan Telegram dengan request abortable.
async function editMessageTextSafe(
  ctx,
  chatId,
  messageId,
  inlineMessageId,
  text,
  options = {},
  retryOptions = {},
) {
  const prepared = prepareUiTelegramText(text, options);
  const safeText = clampTelegramText(prepared.text);
  const safeOptions = prepared.options;
  if (
    shouldSkipTelegramTextEdit(
      ctx,
      chatId,
      messageId,
      inlineMessageId,
      safeText,
      safeOptions,
    )
  ) {
    return null;
  }
  const send = (content, label, sendOptions = safeOptions) =>
    telegramCallWithRetry(
      ctx || chatId,
      label,
      (signal) =>
        ctx.telegram.callApi(
          "editMessageText",
          {
            ...(inlineMessageId
              ? { inline_message_id: inlineMessageId }
              : { chat_id: chatId, message_id: messageId }),
            text: content,
            ...sendOptions,
          },
          { signal },
        ),
      {
        maxAttempts: retryOptions.maxAttempts || 5,
        timeoutMs: retryOptions.timeoutMs || 60000,
        signal: retryOptions.signal,
      },
    );
  try {
    const result = await send(safeText, "editMessageText");
    return rememberTelegramApiTextResult(result, {
      chatId,
      messageId,
      inlineMessageId,
      text: safeText,
      replyMarkup: safeOptions.reply_markup,
    });
  } catch (error) {
    if (isTelegramMessageNotModifiedError(error)) return null;
    if (isTelegramBlockedByUserError(error)) return null;
    if (prepared.customEmojiApplied && isCustomEmojiTelegramError(error)) {
      const fallbackText = stripUiCustomEmojiHtml(safeText);
      const fallbackOptions = removeUiCustomEmojiFromOptions(safeOptions);
      const result = await send(
        fallbackText,
        "editMessageTextEmojiFallback",
        fallbackOptions,
      );
      return rememberTelegramApiTextResult(result, {
        chatId,
        messageId,
        inlineMessageId,
        text: fallbackText,
        replyMarkup: fallbackOptions.reply_markup,
      });
    }
    if (isTelegramMessageTooLongError(error)) {
      const trimmedText = clampTelegramText(prepared.text, 3300);
      return send(trimmedText, "editMessageTextTrimmed")
        .then((result) =>
          rememberTelegramApiTextResult(result, {
            chatId,
            messageId,
            inlineMessageId,
            text: trimmedText,
            replyMarkup: safeOptions.reply_markup,
          }),
        )
        .catch((err) => {
          logIgnoredError("INDEX", "PROMISE_NULL", err);
          return null;
        });
    }
    throw error;
  }
}

async function ctxEditMessageTextSafe(ctx, text, options = {}) {
  const message = ctx.callbackQuery?.message;
  if (!message) return null;
  return editMessageTextSafe(
    ctx,
    message.chat.id,
    message.message_id,
    ctx.callbackQuery?.inline_message_id,
    text,
    options,
  );
}

async function replySafe(ctx, text, options = undefined, retryOptions = {}) {
  const prepared = prepareUiTelegramText(text, options || {});
  const safeOptions = prepared.options;
  const send = (content, label, sendOptions = safeOptions) =>
    telegramCallWithRetry(
      ctx,
      label,
      (signal) =>
        ctx.telegram.callApi(
          "sendMessage",
          { chat_id: ctx.chat.id, text: content, ...sendOptions },
          { signal },
        ),
      {
        maxAttempts: retryOptions.maxAttempts || 5,
        timeoutMs: retryOptions.timeoutMs || 60000,
        signal: retryOptions.signal,
      },
    );
  try {
    const safeText = clampTelegramText(prepared.text);
    const result = await send(safeText, "reply");
    return rememberTelegramApiTextResult(result, {
      chatId: ctx.chat.id,
      text: safeText,
      replyMarkup: safeOptions.reply_markup,
    });
  } catch (error) {
    if (isTelegramBlockedByUserError(error)) return null;
    if (prepared.customEmojiApplied && isCustomEmojiTelegramError(error)) {
      const fallbackText = stripUiCustomEmojiHtml(clampTelegramText(prepared.text));
      const fallbackOptions = removeUiCustomEmojiFromOptions(safeOptions);
      const result = await send(fallbackText, "replyEmojiFallback", fallbackOptions);
      return rememberTelegramApiTextResult(result, {
        chatId: ctx.chat.id,
        text: fallbackText,
        replyMarkup: fallbackOptions.reply_markup,
      });
    }
    if (isTelegramMessageTooLongError(error)) {
      const trimmedText = clampTelegramText(prepared.text, 3300);
      return send(trimmedText, "replyTrimmed")
        .then((result) =>
          rememberTelegramApiTextResult(result, {
            chatId: ctx.chat.id,
            text: trimmedText,
            replyMarkup: safeOptions.reply_markup,
          }),
        )
        .catch((err) => {
          logIgnoredError("INDEX", "PROMISE_NULL", err);
          return null;
        });
    }
    throw error;
  }
}

// Fungsi isRetryableTelegramError: menjalankan bagian is retryable telegram error pada bot.
function isRetryableTelegramError(error) {
  const chain = getTelegramErrorChain(error);
  const codes = chain
    .flatMap((item) => [item?.code, item?.errno])
    .filter(Boolean)
    .map((value) => String(value).toUpperCase());
  const statuses = chain
    .flatMap((item) => [
      item?.response?.error_code,
      item?.statusCode,
      item?.status,
    ])
    .map(Number)
    .filter(Number.isFinite);
  const text = getTelegramErrorMessage(error);
  if (statuses.some((status) => [408, 425, 429, 500, 502, 503, 504].includes(status))) {
    return true;
  }
  if (
    codes.some((code) =>
      [
        "ECONNRESET",
        "ETIMEDOUT",
        "EPIPE",
        "ENETUNREACH",
        "EHOSTUNREACH",
        "EAI_AGAIN",
        "ECONNREFUSED",
        "UND_ERR_CONNECT_TIMEOUT",
        "UND_ERR_HEADERS_TIMEOUT",
        "UND_ERR_BODY_TIMEOUT",
        "UND_ERR_SOCKET",
      ].includes(code),
    )
  ) {
    return true;
  }
  return /(connect timeout|socket hang up|network timeout|fetch failed|aborted|terminated|timeout|temporarily unavailable|too many requests|connection reset|other side closed)/i.test(
    text,
  );
}

// Fungsi getTelegramRetryDelayMs: menjalankan bagian get telegram retry delay ms pada bot.
function getTelegramRetryDelayMs(error, attempt) {
  const retryAfter = Number(error?.response?.parameters?.retry_after || 0);
  if (Number.isFinite(retryAfter) && retryAfter > 0) {
    return Math.min(retryAfter * 1000 + 500, 30000);
  }
  const base = Math.min(1000 * 2 ** (attempt - 1), 10000);
  const jitter = Math.floor(Math.random() * 350);
  return base + jitter;
}

// Telegram retry service meneruskan AbortSignal ke callApi sehingga timeout membatalkan request asli.
const telegramCallWithRetry = createTelegramRetryService({
  isIgnorableError: isIgnorableTelegramError,
  isRetryableError: isRetryableTelegramError,
  getErrorMessage: getTelegramErrorMessage,
  getRetryDelayMs: getTelegramRetryDelayMs,
  onIgnored(ctxOrUserId, label, error) {
    if (isTelegramMessageNotModifiedError(error)) return;
    logApp("WARN", ctxOrUserId, "TELEGRAM", "API_IGNORED", `${label} diabaikan`, {
      error: getTelegramErrorMessage(error),
    });
  },
  onRetry(ctxOrUserId, label, error, attempt, delayMs) {
    logApp("WARN", ctxOrUserId, "TELEGRAM", "API_RETRY", `${label} retry`, {
      attempt,
      nextAttempt: attempt + 1,
      delayMs,
      error: getTelegramErrorMessage(error),
    });
  },
  onFailure(ctxOrUserId, label, error, attempt) {
    logApp("ERROR", ctxOrUserId, "TELEGRAM", "API_FAIL", `${label} gagal`, {
      attempt,
      error: getTelegramErrorMessage(error),
    });
  },
});

// Fungsi replyWithDocumentSafe: upload file lokal sebagai stream baru pada setiap retry.
async function replyWithDocumentSafe(ctx, filePath, { signal, caption } = {}) {
  const resolvedPath = path.resolve(String(filePath || ""));
  const filename = path.basename(resolvedPath);
  const prepared = caption == null
    ? { text: null, options: {}, customEmojiApplied: false }
    : prepareUiTelegramText(caption, {});

  const sendOnce = async ({ label = "sendDocument", useFallback = false } = {}) => {
    const options = useFallback
      ? removeUiCustomEmojiFromOptions(prepared.options)
      : prepared.options;
    const preparedCaption = caption == null
      ? null
      : useFallback
        ? stripUiCustomEmojiHtml(prepared.text)
        : prepared.text;
    return telegramCallWithRetry(
      ctx,
      label,
      async (attemptSignal) => {
        await assertReadableFile(resolvedPath);
        const payload = {
          chat_id: ctx.chat.id,
          document: Input.fromLocalFile(resolvedPath, filename),
          ...options,
        };
        if (preparedCaption) payload.caption = preparedCaption;
        return ctx.telegram.callApi("sendDocument", payload, {
          signal: attemptSignal,
        });
      },
      { maxAttempts: 5, timeoutMs: 180000, signal },
    );
  };

  try {
    await assertReadableFile(resolvedPath);
    try {
      return await sendOnce();
    } catch (error) {
      if (!prepared.customEmojiApplied || !isCustomEmojiTelegramError(error)) throw error;
      return await sendOnce({ label: "sendDocumentEmojiFallback", useFallback: true });
    }
  } catch (error) {
    logApp(
      "ERROR",
      ctx,
      "TELEGRAM",
      "SEND_DOCUMENT_FILE_FAIL",
      "gagal membaca atau mengirim file laporan",
      {
        path: resolvedPath,
        code: error?.code || error?.cause?.code || "-",
        error: getTelegramErrorMessage(error),
      },
    );
    throw error;
  }
}

// Fungsi replyWithPhotoSafe: request Telegram abortable.
async function replyWithPhotoSafe(ctx, photo, options = {}, retryOptions = {}) {
  const caption = Object.prototype.hasOwnProperty.call(options || {}, "caption")
    ? options.caption
    : null;
  const baseOptions = { ...(options || {}) };
  delete baseOptions.caption;
  const prepared = caption == null
    ? { text: null, options: baseOptions, customEmojiApplied: replyMarkupHasCustomEmoji(baseOptions.reply_markup) }
    : prepareUiTelegramText(caption, baseOptions);
  const sendOptions = {
    ...prepared.options,
    ...(caption == null ? {} : { caption: prepared.text }),
  };

  try {
    return await telegramCallWithRetry(
      ctx,
      "sendPhoto",
      (signal) =>
        ctx.telegram.callApi(
          "sendPhoto",
          { chat_id: ctx.chat.id, photo, ...sendOptions },
          { signal },
        ),
      {
        maxAttempts: retryOptions.maxAttempts || 5,
        timeoutMs: retryOptions.timeoutMs || 120000,
        signal: retryOptions.signal,
      },
    );
  } catch (error) {
    if (!prepared.customEmojiApplied || !isCustomEmojiTelegramError(error)) throw error;
    const fallbackOptions = removeUiCustomEmojiFromOptions(sendOptions);
    if (fallbackOptions.caption) fallbackOptions.caption = stripUiCustomEmojiHtml(fallbackOptions.caption);
    return telegramCallWithRetry(
      ctx,
      "sendPhotoEmojiFallback",
      (signal) =>
        ctx.telegram.callApi(
          "sendPhoto",
          { chat_id: ctx.chat.id, photo, ...fallbackOptions },
          { signal },
        ),
      {
        maxAttempts: retryOptions.maxAttempts || 3,
        timeoutMs: retryOptions.timeoutMs || 120000,
        signal: retryOptions.signal,
      },
    );
  }
}

async function sendMessageSafe(chatId, text, options = {}, retryOptions = {}) {
  const prepared = prepareUiTelegramText(text, options);
  const safeText = clampTelegramText(prepared.text);
  const safeOptions = prepared.options;
  const send = (content, sendOptions, label) => telegramCallWithRetry(
    chatId,
    label,
    (signal) =>
      bot.telegram.callApi(
        "sendMessage",
        { chat_id: chatId, text: content, ...sendOptions },
        { signal },
      ),
    {
      maxAttempts: retryOptions.maxAttempts || 6,
      timeoutMs: retryOptions.timeoutMs || 60000,
      signal: retryOptions.signal,
    },
  );

  let result;
  try {
    result = await send(safeText, safeOptions, "sendMessage");
  } catch (error) {
    if (!prepared.customEmojiApplied || !isCustomEmojiTelegramError(error)) throw error;
    const fallbackText = stripUiCustomEmojiHtml(safeText);
    const fallbackOptions = removeUiCustomEmojiFromOptions(safeOptions);
    result = await send(fallbackText, fallbackOptions, "sendMessageEmojiFallback");
    return rememberTelegramApiTextResult(result, {
      chatId,
      text: fallbackText,
      replyMarkup: fallbackOptions.reply_markup,
    });
  }
  return rememberTelegramApiTextResult(result, {
    chatId,
    text: safeText,
    replyMarkup: safeOptions.reply_markup,
  });
}

async function editMessageTextByMetaSafe(panelMeta, text, options = {}, retryOptions = {}) {
  const prepared = prepareUiTelegramText(text, options);
  const safeText = clampTelegramText(prepared.text);
  const safeOptions = prepared.options;
  const hasPanelSnapshot =
    panelMeta &&
    (Object.prototype.hasOwnProperty.call(panelMeta, "text") ||
      Object.prototype.hasOwnProperty.call(panelMeta, "replyMarkup"));
  const knownMessage =
    getKnownTelegramTextMessage(
      null,
      panelMeta?.chatId,
      panelMeta?.messageId,
      undefined,
    ) ||
    (hasPanelSnapshot
      ? { text: panelMeta.text ?? "", reply_markup: panelMeta.replyMarkup ?? null }
      : null);
  if (
    areTelegramMessageContentsEqual(
      knownMessage,
      safeText,
      safeOptions.reply_markup,
      { parseMode: safeOptions.parse_mode },
    )
  ) {
    return null;
  }

  const send = (content, sendOptions, label) => telegramCallWithRetry(
    panelMeta?.chatId,
    label,
    (signal) =>
      bot.telegram.callApi(
        "editMessageText",
        {
          chat_id: panelMeta.chatId,
          message_id: panelMeta.messageId,
          text: content,
          ...sendOptions,
        },
        { signal },
      ),
    {
      maxAttempts: retryOptions.maxAttempts || 5,
      timeoutMs: retryOptions.timeoutMs || 60000,
      signal: retryOptions.signal,
    },
  );

  let result;
  try {
    result = await send(safeText, safeOptions, "editMessageText");
  } catch (error) {
    if (!prepared.customEmojiApplied || !isCustomEmojiTelegramError(error)) throw error;
    const fallbackText = stripUiCustomEmojiHtml(safeText);
    const fallbackOptions = removeUiCustomEmojiFromOptions(safeOptions);
    result = await send(fallbackText, fallbackOptions, "editMessageTextEmojiFallback");
    return rememberTelegramApiTextResult(result, {
      chatId: panelMeta?.chatId,
      messageId: panelMeta?.messageId,
      text: fallbackText,
      replyMarkup: fallbackOptions.reply_markup,
    });
  }
  return rememberTelegramApiTextResult(result, {
    chatId: panelMeta?.chatId,
    messageId: panelMeta?.messageId,
    text: safeText,
    replyMarkup: safeOptions.reply_markup,
  });
}

async function runSafeWaCheck(checker, userId, number, { signal } = {}) {
  const maxAttempts = 2;
  let lastError;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      signal?.throwIfAborted();
      return await checker(userId, number, { signal });
    } catch (error) {
      if (signal?.aborted) throw signal.reason || error;
      if (error?.code === "NO_READY_SENDER") throw error;
      lastError = error;
      const canRetry =
        isRetryableWaCheckError(error) && attempt < maxAttempts && !signal?.aborted;
      if (!canRetry) break;
      logApp("WARN", userId, "CHECK", "RETRY", "cek bio mengalami error transien", {
        number,
        attempt,
        error: error?.message || String(error),
      });
      await abortableDelay(600 * attempt, signal);
    }
  }
  return {
    number,
    exists: null,
    status: "failed",
    error: lastError?.message || String(lastError),
  };
}

// Flow legacy tetap tersedia sebagai compatibility fallback untuk state lama
// yang tidak memiliki metadata multi-Sender.
async function cekSafe(userId, number, { signal } = {}) {
  return runSafeWaCheck(
    (ownerId, targetNumber, options) =>
      cekBioEnhanced(ownerId, targetNumber, options),
    userId,
    number,
    { signal },
  );
}

// /cekbio dan /cekbiotxt mengambil lease dari Sender Pool user yang
// menjalankan command. Router tidak pernah melihat pool user lain.
async function cekSafeWithSenderPool(
  userId,
  number,
  { signal, checkType = "check", speedPerSender = DEFAULT_CHECK_SPEED } = {},
) {
  const selectedSpeed = normalizeCheckSpeed(speedPerSender);
  return runSafeWaCheck(
    (ownerId, targetNumber, options) =>
      senderCheckRouter.check(ownerId, targetNumber, {
        ...options,
        type: checkType,
        maxActivePerSender: selectedSpeed,
      }),
    userId,
    number,
    { signal },
  );
}

async function getTelegramFileUrl(ctx, fileId, { signal } = {}) {
  try {
    const file = await telegramCallWithRetry(
      ctx,
      "getFile",
      (attemptSignal) =>
        ctx.telegram.callApi("getFile", { file_id: fileId }, { signal: attemptSignal }),
      {
        maxAttempts: config.DOWNLOAD_RETRY_ATTEMPTS,
        timeoutMs: config.DOWNLOAD_TIMEOUT_MS,
        signal,
      },
    );
    if (!file?.file_path) throw new Error("Telegram tidak mengembalikan file_path.");
    return `https://api.telegram.org/file/bot${config.BOT_TOKEN}/${file.file_path}`;
  } catch (error) {
    if (signal?.aborted) throw signal.reason || error;
    const wrapped = new Error(
      `Gagal mengambil link file Telegram: ${getTelegramErrorMessage(error) || "alasan tidak diketahui"}`,
      { cause: error },
    );
    wrapped.name = "TelegramFileAccessError";
    wrapped.code = "TELEGRAM_FILE_ACCESS_FAILED";
    throw wrapped;
  }
}

// Daftar command resmi milik bot ini.
// Kalau ada slash-command di luar daftar ini, bot wajib diam total agar tidak mengganggu bot lain.
const OWN_BOT_COMMANDS = new Set([
  "start",
  "cekbio",
  "cekbiotxt",
  "help",
  "senderku",
  "broadcast",
  "stats",
  "emoji",
  "listemoji",
]);

// Fungsi extractSlashCommandInfo: mengambil command dari text/caption Telegram, termasuk bentuk /command@BotUsername.
function extractSlashCommandInfo(value) {
  const text = String(value || "").trim();
  const match = text.match(/^\/([A-Za-z0-9_]+)(?:@([A-Za-z0-9_]+))?(?=\s|$)/);
  if (!match) return null;
  return {
    command: String(match[1] || "").toLowerCase(),
    mention: match[2] ? String(match[2]).toLowerCase() : "",
  };
}

// Fungsi getUpdateSlashCommandInfo: mencari slash-command pada pesan text atau caption file.
function getUpdateSlashCommandInfo(ctx) {
  return (
    extractSlashCommandInfo(ctx.message?.text) ||
    extractSlashCommandInfo(ctx.message?.caption) ||
    null
  );
}

// Fungsi getBotUsername: mengambil username bot agar command @mention ke bot lain bisa diabaikan.
function getBotUsername(ctx) {
  return String(ctx?.botInfo?.username || bot?.botInfo?.username || "")
    .replace(/^@/, "")
    .toLowerCase();
}

// Fungsi isOwnBotSlashCommand: memastikan bot hanya mengenali command miliknya sendiri.
function isOwnBotSlashCommand(ctx) {
  const info = getUpdateSlashCommandInfo(ctx);
  if (!info) return false;
  const botUsername = getBotUsername(ctx);

  // Command yang ditujukan ke bot lain harus diabaikan, walaupun namanya sama.
  if (info.mention && botUsername && info.mention !== botUsername) return false;

  return OWN_BOT_COMMANDS.has(info.command);
}

// Fungsi shouldIgnoreForeignSlashCommand: true jika pesan adalah /command yang bukan milik bot ini.
function shouldIgnoreForeignSlashCommand(ctx) {
  const info = getUpdateSlashCommandInfo(ctx);
  if (!info) return false;
  return !isOwnBotSlashCommand(ctx);
}

// Fungsi isGroupChat: mengecek apakah update berasal dari grup/supergroup Telegram.
function isGroupChat(ctx) {
  const ct = ctx?.chat?.type;
  return ct === "group" || ct === "supergroup";
}

// Fungsi normalizeChatId: merapikan chat ID untuk perbandingan state/panel grup.
function normalizeChatId(value) {
  return String(value ?? "").trim();
}

// Fungsi getGroupUpdateDisposition: menentukan apakah update grup boleh diproses atau diabaikan.
function getGroupUpdateDisposition(ctx) {
  if (!isGroupChat(ctx)) return "allow";

  // Callback query hanya dapat berasal dari inline keyboard bot ini. Semua
  // callback diizinkan masuk ke middleware berikutnya; ownership panel tetap
  // diverifikasi terpisah agar user tidak mengoperasikan panel user lain.
  if (ctx.callbackQuery) return "allow";
  if (isOwnBotSlashCommand(ctx) || isCekbioTxtCaption(ctx)) return "allow";

  // Pairing Code di grup membutuhkan satu balasan teks. Hanya balasan milik
  // user dengan state pairing pada chat yang sama yang boleh diteruskan.
  const state = ctx.from?.id ? getUserState(ctx.from.id) : null;
  const pairingChatId = state?.promptMessage?.chatId ?? state?.chatId;
  if (
    ctx.message?.text &&
    state?.type === "await_pairing" &&
    normalizeChatId(pairingChatId) === normalizeChatId(ctx.chat?.id)
  ) {
    return "allow";
  }

  // Pesan biasa/command bot lain di grup tidak dijawab.
  return "ignore";
}
// Fungsi isStartCommand: mengecek command /start milik bot ini.
function isStartCommand(ctx) {
  const info = getUpdateSlashCommandInfo(ctx);
  return Boolean(info && info.command === "start" && isOwnBotSlashCommand(ctx));
}

// Fungsi isCekbioCommand: mengecek command /cekbio milik bot ini.
function isCekbioCommand(ctx) {
  const info = getUpdateSlashCommandInfo(ctx);
  return Boolean(
    info && info.command === "cekbio" && isOwnBotSlashCommand(ctx),
  );
}

// Fungsi isCekbioTxtCommand: mengecek command /cekbiotxt milik bot ini dari text.
function isCekbioTxtCommand(ctx) {
  const info = extractSlashCommandInfo(ctx.message?.text);
  return Boolean(
    info && info.command === "cekbiotxt" && isOwnBotSlashCommand(ctx),
  );
}

// Fungsi isHelpCommand: mengecek command /help milik bot ini.
function isHelpCommand(ctx) {
  const info = getUpdateSlashCommandInfo(ctx);
  return Boolean(info && info.command === "help" && isOwnBotSlashCommand(ctx));
}

// Fungsi isSenderkuCommand: mengecek command /senderku milik bot ini.
function isSenderkuCommand(ctx) {
  const info = getUpdateSlashCommandInfo(ctx);
  return Boolean(info && info.command === "senderku" && isOwnBotSlashCommand(ctx));
}

// Fungsi isCekbioTxtCaption: mengecek caption /cekbiotxt milik bot ini pada file TXT.
function isCekbioTxtCaption(ctx) {
  const info = extractSlashCommandInfo(ctx.message?.caption);
  return Boolean(
    ctx.message?.document &&
    info &&
    info.command === "cekbiotxt" &&
    isOwnBotSlashCommand(ctx),
  );
}

// Fungsi isRecognizedGroupCommand: menjalankan bagian is recognized group command pada bot.
function isRecognizedGroupCommand(ctx) {
  return (
    isStartCommand(ctx) ||
    isCekbioCommand(ctx) ||
    isCekbioTxtCommand(ctx) ||
    isCekbioTxtCaption(ctx) ||
    isHelpCommand(ctx) ||
    isSenderkuCommand(ctx)
  );
}

// Fungsi botPrivateUrl: menjalankan bagian bot private url pada bot.
function botPrivateUrl(ctx) {
  const username = ctx?.botInfo?.username || bot?.botInfo?.username || "";
  return username ? `https://t.me/${username}` : "";
}

// Fungsi privateOpenKeyboard: menjalankan bagian private open keyboard pada bot.
function privateOpenKeyboard(ctx) {
  return keyboardPresentation.privateKeyboard(botPrivateUrl(ctx));
}

// Fungsi groupHelperKeyboard: menjalankan bagian group helper keyboard pada bot.
function groupHelperKeyboard(ctx) {
  return keyboardPresentation.groupHelperKeyboard({
    targetUrl: botPrivateUrl(ctx),
    callbacks: CALLBACKS,
  });
}

// Fungsi isKnownTelegramUser: mengecek apakah user grup sudah pernah dikenali lewat chat privat atau data bot.
function isKnownTelegramUser(userId) {
  const id = Number(userId);
  if (!Number.isInteger(id) || id <= 0) return false;
  if (isOwner(id)) return true;
  if (knownUsers.has(id)) return true;
  return stats.getUserIds().includes(id);
}

// Fungsi getUserKnownStatusText: membuat teks ringkas status user yang dikenali di grup.
function getUserKnownStatusText(ctx, user, joinStatus = null) {
  const senderList = getSenderUiList(user.id);
  const activeSenderCount = senderList.filter((sender) => sender?.connected === true).length;
  const reconnectingSenderCount = senderList.filter(
    (sender) => sender?.connectivityState === "reconnecting",
  ).length;
  let waStatus = "Belum terhubung";
  if (activeSenderCount > 0) waStatus = `${activeSenderCount} aktif`;
  else if (reconnectingSenderCount > 0) waStatus = `${reconnectingSenderCount} reconnect`;
  else if (senderList.length > 0) waStatus = "Sesi tersimpan";

  let accessStatus = "Siap dipakai";
  if (joinStatus?.enabled) {
    accessStatus = joinStatus.joined ? "Force join lengkap" : "Force join belum lengkap";
  }

  return boxPanel("USER DIKENALI", [
    `👤 <b>${escapeHtml(getDisplayName(user))}</b>`,
    `🔐 Akses  : ${escapeHtml(accessStatus)}`,
    `📡 Sender : ${escapeHtml(waStatus)}`,
    `🔎 /cekbio · maks. ${DIRECT_CHECK_MAX_NUMBERS} nomor`,
    `📄 /cekbiotxt · file TXT`,
  ]);
}

// Fungsi getUserUnknownText: membuat teks ringkas user tidak dikenali di grup.
function getUserUnknownText() {
  return warningPanel("USER TIDAK DIKENALI", [
    "Akun belum terdaftar di bot.",
    "👉 Buka chat privat lalu tekan /start.",
  ]);
}

// Fungsi replyUserUnknownInGroup: membalas command grup ketika user belum dikenali bot.
async function replyUserUnknownInGroup(ctx) {
  return replySafe(ctx, getUserUnknownText(), {
    parse_mode: "HTML",
    ...privateOpenKeyboard(ctx),
  });
}

function getGroupPrivateAccessText() {
  return warningPanel("AKSES BELUM AKTIF", [
    "Syarat grup/channel belum lengkap.",
    "🔒 Lengkapi Force Join melalui chat privat bot terlebih dahulu.",
  ]);
}

async function replyGroupPrivateAccessRequired(ctx) {
  return replySafe(ctx, getGroupPrivateAccessText(), {
    parse_mode: "HTML",
    ...privateOpenKeyboard(ctx),
  });
}

const GROUP_PANEL_OWNER_TTL_MS = 2 * 60 * 60 * 1000;
function getGroupPanelOwnerKey(chatId, messageId) {
  if (chatId == null || !messageId) return "";
  return `${String(chatId)}:${String(messageId)}`;
}

function rememberGroupPanelOwner(userId, chatId, messageId) {
  const numericUserId = Number(userId);
  const key = getGroupPanelOwnerKey(chatId, messageId);
  if (!key || !Number.isSafeInteger(numericUserId) || numericUserId <= 0) return;
  const now = Date.now();
  groupInteractivePanelOwners.set(key, { userId: numericUserId, createdAt: now });
  if (groupInteractivePanelOwners.size > 5000) {
    for (const [entryKey, entry] of groupInteractivePanelOwners) {
      if (now - Number(entry?.createdAt || 0) > GROUP_PANEL_OWNER_TTL_MS) {
        groupInteractivePanelOwners.delete(entryKey);
      }
      if (groupInteractivePanelOwners.size <= 4000) break;
    }
  }
}

function rememberGroupPanelOwnerFromResult(ctx, result) {
  if (!isGroupChat(ctx) || !result?.message_id) return result;
  rememberGroupPanelOwner(ctx.from?.id, result.chat?.id ?? ctx.chat?.id, result.message_id);
  return result;
}

function getGroupPanelOwner(ctx) {
  if (!isGroupChat(ctx) || !ctx.callbackQuery?.message?.message_id) return null;
  const key = getGroupPanelOwnerKey(ctx.chat?.id, ctx.callbackQuery.message.message_id);
  const entry = groupInteractivePanelOwners.get(key);
  if (!entry) return null;
  if (Date.now() - Number(entry.createdAt || 0) > GROUP_PANEL_OWNER_TTL_MS) {
    groupInteractivePanelOwners.delete(key);
    return null;
  }
  return Number(entry.userId) || null;
}

// Watchdog update Telegram: tidak mengubah flow, hanya memberi log jika satu
// update tertahan terlalu lama sehingga gejala "bot diam" mudah dilacak.
bot.use(async (ctx, next) => {
  const startedAt = Date.now();
  const command = extractSlashCommandInfo(ctx.message?.text || ctx.message?.caption || "")?.command ||
    ctx.callbackQuery?.data || ctx.updateType || "update";
  const timer = setTimeout(() => {
    logApp(
      "WARN",
      ctx,
      "TELEGRAM",
      "UPDATE_SLOW",
      "pemrosesan update Telegram lebih dari 5 detik",
      { command, elapsedMs: Date.now() - startedAt },
    );
  }, 5000);
  timer.unref?.();
  try {
    return await next();
  } finally {
    clearTimeout(timer);
  }
});

// Middleware filter command asing:
// /command yang bukan milik CEKBIO tidak dibalas apa pun, baik di privat maupun grup.
// Ini mencegah CEKBIO ikut menjawab /otp, /menu, atau command milik bot lain.
bot.use(async (ctx, next) => {
  if (shouldIgnoreForeignSlashCommand(ctx)) return;
  return next();
});

// Semua grup/supergroup boleh memakai bot. ALLOWED_GROUP_CHATS tidak lagi
// menjadi whitelist pemakaian; akses ditentukan per-user lewat private onboarding
// + Force Join. Inline panel di grup dikunci ke user yang membuat panel tersebut.
bot.use(async (ctx, next) => {
  if (!isGroupChat(ctx) || !ctx.callbackQuery) return next();
  const ownerId = getGroupPanelOwner(ctx);
  if (!ownerId || ownerId === Number(ctx.from?.id) || isOwner(ctx.from?.id)) {
    return next();
  }
  await ctx
    .answerCbQuery("Panel ini milik user lain.", { show_alert: false })
    .catch((err) => logIgnoredError("INDEX", "PROMISE_IGNORED", err));
  return;
});

bot.use(async (ctx, next) => {
  if (isMaintenanceMode() && !isOwner(ctx.from?.id)) {
    if (isGroupChat(ctx)) return;
    const text = warningPanel("MAINTENANCE", [
      "🛠️ Bot sedang diperbarui.",
      "⏳ Coba kembali beberapa saat lagi.",
    ]);
    if (ctx.callbackQuery) {
      await ctx
        .answerCbQuery("Studio sedang dirapikan.")
        .catch((err) => logIgnoredError("INDEX", "PROMISE_IGNORED", err));
      await replySafe(ctx, text);
      return;
    }
    if (ctx.message) {
      await replySafe(ctx, text);
      return;
    }
    return;
  }
  return next();
});

bot.use(async (ctx, next) => {
  if (!isGroupChat(ctx)) return next();
  const disposition = getGroupUpdateDisposition(ctx);
  if (disposition === "ignore") return;

  const userId = ctx.from?.id;
  if (!userId || isOwner(userId)) return next();
  if (!isKnownTelegramUser(userId)) {
    if (ctx.callbackQuery) {
      await ctx
        .answerCbQuery("Buka chat privat bot dulu.")
        .catch((err) => logIgnoredError("INDEX", "PROMISE_IGNORED", err));
    }
    return replyUserUnknownInGroup(ctx);
  }
  return next();
});

bot.use(async (ctx, next) => {
  const userId = ctx.from?.id;
  if (!userId || isOwner(userId) || !isForceJoinEnabled()) {
    return next();
  }

  // /start di grup hanya untuk cek user dikenali/tidak dikenali.
  // Force join tetap diberlakukan untuk /cekbio dan /cekbiotxt.
  if (isGroupChat(ctx) && isStartCommand(ctx)) {
    return next();
  }

  if (ctx.callbackQuery?.data === CALLBACKS.ABORT_CHECK) {
    return next();
  }
  const joinStatus = await getForceJoinStatus(userId);
  if (joinStatus.canVerify && joinStatus.joined) return next();

  // Grup hanya menjadi tempat penggunaan. Onboarding/Force Join tetap dilakukan
  // di private chat agar satu user punya akses yang konsisten di semua grup.
  if (isGroupChat(ctx)) {
    if (ctx.callbackQuery) {
      await ctx
        .answerCbQuery("Lengkapi akses di chat privat dulu.")
        .catch((err) => logIgnoredError("INDEX", "PROMISE_IGNORED", err));
    }
    return replyGroupPrivateAccessRequired(ctx);
  }

  if (ctx.callbackQuery?.data === CALLBACKS.JOIN_VERIFY) {
    return next();
  }
  if (ctx.callbackQuery) {
    await ctx
      .answerCbQuery("Akses masih terkunci.")
      .catch((err) => logIgnoredError("INDEX", "PROMISE_IGNORED", err));
  }
  return showForceJoinGate(
    ctx,
    joinStatus.canVerify ? "welcome" : "unavailable",
    joinStatus,
  );
});

bot.use(async (ctx, next) => {
  if (!isGroupChat(ctx)) return next();
  const disposition = getGroupUpdateDisposition(ctx);
  if (disposition === "allow") return next();
  return;
});

// Fungsi registerTelegramCommands: menjalankan bagian register telegram commands pada bot.
async function registerTelegramCommands() {
  const privateCommands = [
    {
      command: "start",
      description: `${ACCENTS.status} Menu dan status`,
    },
    {
      command: "senderku",
      description: `≡ Kelola sender`,
    },
    {
      command: "cekbio",
      description: `${ACCENTS.success} Cek nomor langsung`,
    },
    {
      command: "cekbiotxt",
      description: `${ACCENTS.standard} Cek file TXT`,
    },
    {
      command: "help",
      description: `${ACCENTS.low} Panduan penggunaan`,
    },
    { command: "saldo", description: "💰 Cek saldo token" },
    { command: "topup", description: "💳 Top Up QRIS" },
    { command: "paket", description: "📦 Paket token" },
  ];
  const groupCommands = [...privateCommands];
  const ownerCommands = [
    ...privateCommands,
    {
      command: "broadcast",
      description: `${ACCENTS.broadcast} Broadcast owner`,
    },
    {
      command: "stats",
      description: `${ACCENTS.status} Statistik bot`,
    },
    {
      command: "emoji",
      description: `✨ Ubah emoji UI ke premium`,
    },
    {
      command: "listemoji",
      description: `📋 Daftar emoji UI`,
    },
  ];

  await bot.telegram.setMyCommands(privateCommands);
  await bot.telegram.setMyCommands(privateCommands, {
    scope: { type: "all_private_chats" },
  });
  await bot.telegram.setMyCommands(groupCommands, {
    scope: { type: "all_group_chats" },
  });
  if (Array.isArray(config.OWNERS) && config.OWNERS.length) {
    for (const ownerId of config.OWNERS) {
      try {
        await bot.telegram.setMyCommands(ownerCommands, {
          scope: { type: "chat", chat_id: ownerId },
        });
      } catch (err) {
        logIgnoredError("INDEX", "THROW_IGNORED", err);
      }
    }
  }
  await bot.telegram.setChatMenuButton({ menu_button: { type: "commands" } });
  console.log("Telegram commands registered");
}

function money(n) { return new Intl.NumberFormat("id-ID").format(Number(n) || 0); }
function tokenFmt(n) { return String(Math.round((Number(n) || 0) * 100) / 100); }
function html(s) { return String(s ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function packageKeyboard(packages) {
  return Markup.inlineKeyboard((packages || []).slice(0, 50).map((p) => [Markup.button.callback(`🪙 ${p.tokens} token · Rp${money(p.price)}`, `BUY_${p.tokens}`)]));
}
async function replyBalance(ctx) {
  const w = await wallet.getUserWallet(ctx.from.id);
  return ctx.reply(`💰 <b>SALDO TOKEN</b>\n\n🪙 Saldo: <b>${tokenFmt(w.balance)}</b> token\n📥 Dibeli: ${tokenFmt(w.totalPurchased)} token\n📤 Terpakai: ${tokenFmt(w.totalUsed)} token`, { parse_mode: "HTML", ...mainKeyboard(ctx.from.id) });
}
async function topup(ctx, amountRaw) {
  if (!qris) return ctx.reply("❌ QRIS belum dikonfigurasi. Isi BUATQRIS_ACCOUNT_ID dan BUATQRIS_SECRET_TOKEN di .env.");
  const packages = await pricing.getPackages();
  const token = Number(amountRaw);
  const pkg = packages.find((p) => Number(p.tokens) === token);
  if (!pkg) return ctx.reply(`💳 <b>Pilih Paket Token</b>\n\n${html(packages.map((p,i)=>`${i+1}. ${money(p.tokens)} token — Rp${money(p.price)}`).join("\\n"))}`, {parse_mode:"HTML", ...packageKeyboard(packages)});
  try {
    const response = await qris.createQris(pkg.price, `CekBio topup user ${ctx.from.id} ${pkg.tokens} token`);
    const data = response?.data || response;
    if (!data?.transaction_id || !data?.qr_url) throw new Error("Respons QRIS tidak lengkap.");
    await wallet.recordQrisTransaction(data.transaction_id, { userId:String(ctx.from.id), firstName:String(ctx.from.first_name||""), username:String(ctx.from.username||""), amount:pkg.price, tokensExpected:pkg.tokens, totalAmount:data.total_amount });
    return ctx.replyWithPhoto(data.qr_url, { caption:`💳 <b>TOPUP CEKBIO</b>\n\n🪙 Token: <b>${money(pkg.tokens)}</b>\n💵 Harga: <b>Rp${money(pkg.price)}</b>\n💳 Total bayar: <b>Rp${money(data.total_amount || pkg.price)}</b>\n🧾 ID: <code>${html(data.transaction_id)}</code>\n⏳ Expired: ${html(data.expired_at || "-")}\n\nSaldo otomatis masuk setelah pembayaran terkonfirmasi.`, parse_mode:"HTML" });
  } catch (e) { return ctx.reply(`❌ Gagal membuat QRIS: ${html(e.message)}`, {parse_mode:"HTML"}); }
}
function startQrisWebhookServer() {
  if (!qris || !config.BUATQRIS_SIGNING_SECRET) return null;
  const server=http.createServer((req,res)=>{
    if(req.method==='GET' && req.url==='/health'){res.writeHead(200,{'content-type':'text/plain'});return res.end('OK');}
    if(req.method!=='POST' || req.url!=='/qris/webhook'){res.writeHead(404);return res.end('Not found');}
    const chunks=[]; req.on('data',c=>chunks.push(c)); req.on('end',async()=>{
      const raw=Buffer.concat(chunks);
      if(!verifyWebhookSignature(raw,req.headers['x-buatqris-signature'],config.BUATQRIS_SIGNING_SECRET)){res.writeHead(401);return res.end('Unauthorized');}
      try { const data=JSON.parse(raw.toString('utf8')); if(String(data.event||'')==='payment.success' && data.transaction_id){ const result=await wallet.completeQrisTransaction(data.transaction_id,data); if(result?.userId && !result.duplicate) await bot.telegram.sendMessage(Number(result.userId),`✅ <b>TOPUP BERHASIL</b>\n\n🪙 +${tokenFmt(result.tokens)} token\n💰 Saldo: ${tokenFmt(result.balance)} token\n🧾 ID: <code>${html(data.transaction_id)}</code>`,{parse_mode:'HTML'}).catch(()=>{}); } res.writeHead(200);res.end('OK'); }
      catch(e){res.writeHead(500);res.end('ERR');}
    });
  });
  server.listen(config.WEBHOOK_PORT,config.WEBHOOK_HOST,()=>console.log(`[QRIS] webhook listening ${config.WEBHOOK_HOST}:${config.WEBHOOK_PORT}`));
  return server;
}
async function pollQrisPayments() {
  if (!qris) return;
  const pending = await wallet.listPendingQrisTransactions(20);
  for (const trx of pending) {
    try { const response=await qris.checkStatus(trx.transactionId); const status=String(response?.data?.status||'').toLowerCase(); if(status==='success'){ const result=await wallet.completeQrisTransaction(trx.transactionId,response.data); if(result?.userId&&!result.duplicate) await bot.telegram.sendMessage(Number(result.userId),`✅ <b>TOPUP BERHASIL</b>\n\n🪙 +${tokenFmt(result.tokens)} token\n💰 Saldo: ${tokenFmt(result.balance)} token\n🧾 ID: <code>${html(trx.transactionId)}</code>`,{parse_mode:'HTML'}).catch(()=>{}); } else if(['expired','failed'].includes(status)) await wallet.markQrisTransactionStatus(trx.transactionId,status,{providerStatus:status}); }
    catch(e){ console.warn(`[QRIS] status ${trx.transactionId} gagal: ${e.message}`); }
    await new Promise(r=>setTimeout(r,300));
  }
}

// Fungsi mainKeyboard: menjalankan bagian main keyboard pada bot.
function mainKeyboard(userId) {
  const base = keyboardPresentation.mainKeyboard({
    isOwner: isOwner(userId),
    maintenanceEnabled: isMaintenanceMode(),
    callbacks: CALLBACKS,
  });
  const rows = base?.reply_markup?.inline_keyboard || [];
  rows.splice(0, 0, [Markup.button.callback("💰 Saldo", CALLBACKS.BALANCE), Markup.button.callback("💳 Top Up", CALLBACKS.TOPUP)]);
  rows.push([Markup.button.callback("🧾 Riwayat", CALLBACKS.HISTORY)]);
  return Markup.inlineKeyboard(rows);
}

// Fungsi contextMainKeyboard: menjalankan bagian context main keyboard pada bot.
function contextMainKeyboard(ctx, userId) {
  return isGroupChat(ctx) ? {} : mainKeyboard(userId);
}

// Fungsi activeCheckKeyboard: menampilkan tombol pembatalan untuk job pengecekan aktif.
function activeCheckKeyboard() {
  return keyboardPresentation.activeCheckKeyboard({ callbacks: CALLBACKS });
}

function pausedCheckKeyboard() {
  return keyboardPresentation.pausedCheckKeyboard({ callbacks: CALLBACKS });
}

function pausedCheckConfirmationKeyboard() {
  return keyboardPresentation.pausedCheckConfirmationKeyboard({ callbacks: CALLBACKS });
}

function resumeNeedsConnectionKeyboard() {
  return keyboardPresentation.resumeNeedsConnectionKeyboard({ callbacks: CALLBACKS });
}

function getSenderUiSnapshot(userId, senderId = null) {
  try {
    if (senderId) return getSenderSnapshotById(userId, senderId);
    return getSenderSnapshot(userId);
  } catch (_) {
    return { senderId: senderId || "default", connected: false, number: "", connectedAt: null };
  }
}

function getSenderUiList(userId) {
  try {
    return senderPool.getSnapshot(userId).senders.filter(
      (sender) => sender && (sender.connected || sender.registered),
    );
  } catch (_) {
    const snapshot = getSenderUiSnapshot(userId);
    return snapshot.connected || snapshot.number ? [snapshot] : [];
  }
}

function getConnectedSenderUiList(userId) {
  return getSenderUiList(userId).filter((sender) => sender?.connected === true);
}

// Keyboard Senderku membaca seluruh sender yang masih tersimpan milik user,
// termasuk sender offline agar user tetap dapat menghapus sesi bermasalah.
function waMenuKeyboard(userId = null) {
  const connected = userId ? getSenderUiList(userId).length > 0 : false;
  return keyboardPresentation.waMenuKeyboard({
    callbacks: CALLBACKS,
    connected,
  });
}

function connectedSenderKeyboard() {
  return keyboardPresentation.connectedSenderKeyboard({ callbacks: CALLBACKS });
}

function disconnectSenderKeyboard(userId) {
  return keyboardPresentation.disconnectSenderKeyboard({
    callbacks: CALLBACKS,
    senders: getSenderUiList(userId),
  });
}

// Fungsi cancelStateKeyboard: menjalankan bagian cancel state keyboard pada bot.
function cancelStateKeyboard() {
  return keyboardPresentation.cancelKeyboard({ callbacks: CALLBACKS });
}
// Fungsi menuOnlyKeyboard: menjalankan bagian menu only keyboard pada bot.
function menuOnlyKeyboard() {
  return keyboardPresentation.menuOnlyKeyboard({ callbacks: CALLBACKS });
}
// Fungsi clearActivePairingPanel: menjalankan bagian clear active pairing panel pada bot.
function clearActivePairingPanel(userId, token = null) {
  const key = String(userId);
  const cur = activePairingPanels.get(key);
  if (!cur) return;
  if (token && cur.token !== token) return;
  activePairingPanels.delete(key);
}
// Fungsi getPanelMessageMeta: menjalankan bagian get panel message meta pada bot.
function getPanelMessageMeta(ctx, renderResult) {
  if (ctx.callbackQuery?.message?.photo?.length && ctx.chat?.id)
    return {
      chatId: ctx.chat.id,
      messageId: ctx.callbackQuery.message.message_id,
      text: ctx.callbackQuery.message.caption ?? "",
      replyMarkup: ctx.callbackQuery.message.reply_markup ?? null,
    };
  if (renderResult?.message_id && ctx.chat?.id)
    return {
      chatId: ctx.chat.id,
      messageId: renderResult.message_id,
      text: renderResult.text ?? renderResult.caption ?? "",
      replyMarkup: renderResult.reply_markup ?? null,
    };
  return null;
}
// Fungsi watchPairingPanelUntilConnected: menjalankan bagian watch pairing panel until connected pada bot.
async function watchPairingPanelUntilConnected(userId, token, senderId = "default") {
  try {
    const connected = await ensureSenderConnectedSession(userId, senderId, 120000);
    if (!connected) return;
    const panel = activePairingPanels.get(String(userId));
    if (!panel || panel.token !== token || panel.senderId !== senderId) return;
    clearActivePairingPanel(userId, token);
    clearUserState(userId);
    await bot.telegram
      .deleteMessage(panel.chatId, panel.messageId)
      .catch((err) => logIgnoredError("INDEX", "PROMISE_IGNORED", err));
    const snapshot = getSenderUiSnapshot(userId, senderId);
    const connectedPanel = await sendMessageSafe(
      panel.chatId,
      buildSenderConnectedNotice({
        number: snapshot.number,
        activeCount: getConnectedSenderUiList(userId).length,
      }),
      {
        reply_markup: connectedSenderKeyboard().reply_markup,
      },
      { maxAttempts: 3, timeoutMs: 30000 },
    );
    if (connectedPanel?.message_id) {
      rememberGroupPanelOwner(userId, connectedPanel.chat?.id ?? panel.chatId, connectedPanel.message_id);
    }
    markSenderReady(userId, senderId, {
      source: "pairing_connected_card",
      messageId: connectedPanel?.message_id || null,
    });
  } catch (error) {
    logApp(
      "ERROR",
      userId,
      "WA_PAIR",
      "WATCH_FAIL",
      "watcher pairing gagal memantau koneksi",
      { senderId, error: error.message },
    );
  }
}
// Melacak panel pairing bersama senderId yang sedang dibuat.
function trackActivePairingPanelFromMeta(userId, panelMeta, senderId = "default") {
  if (!userId || !panelMeta?.chatId || !panelMeta?.messageId) return;
  clearActivePairingPanel(userId);
  const token = `pair_${Date.now()}_${++pairingPanelSequence}`;
  activePairingPanels.set(String(userId), {
    token,
    senderId,
    chatId: panelMeta.chatId,
    messageId: panelMeta.messageId,
  });
  watchPairingPanelUntilConnected(userId, token, senderId);
}
// Fungsi renderTextPanel: menjalankan bagian render text panel pada bot.
async function renderTextPanel(ctx, text, keyboard, extra = {}) {
  const options = { ...extra, reply_markup: keyboard.reply_markup };
  const currentPanel = ctx.callbackQuery?.message?.text
    ? ctx.callbackQuery.message
    : null;
  const result = await editOrResendTelegramPanel({
    currentPanel,
    editPanel: () => ctxEditMessageTextSafe(ctx, text, options),
    discardPanel: () =>
      ctx.deleteMessage().catch((error) =>
        logIgnoredError("TELEGRAM", "STALE_PANEL_DELETE_IGNORED", error),
      ),
    resendPanel: () => replySafe(ctx, text, options),
    onEditFallback: (error) =>
      logApp(
        "WARN",
        ctx,
        "TELEGRAM",
        "PANEL_EDIT_RESEND",
        "panel tidak tersedia untuk diedit; mengirim panel pengganti",
        { error: getTelegramErrorMessage(error) },
      ),
  });
  return rememberGroupPanelOwnerFromResult(ctx, result);
}
// Fungsi uploadAndSendBanner: menjalankan bagian upload and send banner pada bot.
async function uploadAndSendBanner(ctx, caption, keyboard) {
  const bannerPath = path.join(process.cwd(), "banner.jpg");
  if (!fs.existsSync(bannerPath))
    return replySafe(ctx, caption, {
      parse_mode: "HTML",
      reply_markup: keyboard,
    });
  try {
    const sent = await replyWithPhotoSafe(
      ctx,
      { source: bannerPath },
      { caption, parse_mode: "HTML", reply_markup: keyboard },
      { maxAttempts: 5, timeoutMs: 120000 },
    );
    if (sent.photo && sent.photo.length)
      await saveBannerCache(sent.photo[sent.photo.length - 1].file_id);
    return sent;
  } catch (err) {
    console.error("Gagal upload banner:", err.message);
    return replySafe(ctx, caption, {
      parse_mode: "HTML",
      reply_markup: keyboard,
    });
  }
}
// Fungsi replyMainMenuCard: menjalankan bagian reply main menu card pada bot.
async function replyMainMenuCard(ctx) {
  const userId = ctx.from.id;
  if (isGroupChat(ctx)) {
    return replySafe(ctx, getGroupMenuCardHtml(ctx.from), {
      parse_mode: "HTML",
    });
  }
  const caption = getMainMenuCardHtml(ctx.from);
  const keyboard = mainKeyboard(userId).reply_markup;
  if (cachedBannerFileId) {
    return replyWithPhotoSafe(ctx, cachedBannerFileId, {
      caption,
      parse_mode: "HTML",
      reply_markup: keyboard,
    }).catch(async (err) => {
      console.warn(
        "File_id banner tidak valid, akan upload ulang:",
        err.message,
      );
      cachedBannerFileId = null;
      try {
        if (fs.existsSync(BANNER_CACHE_PATH)) fs.unlinkSync(BANNER_CACHE_PATH);
      } catch (err) {
        logIgnoredError("INDEX", "THROW_IGNORED", err);
      }
      return uploadAndSendBanner(ctx, caption, keyboard);
    });
  }
  return uploadAndSendBanner(ctx, caption, keyboard);
}
// Fungsi replySummaryThenMainMenu: menjalankan bagian reply summary then main menu pada bot.
async function replySummaryThenMainMenu(ctx, summaryText) {
  // Setelah /cekbio atau /cekbiotxt selesai, jangan munculkan menu utama lagi.
  // User cukup menerima ringkasan + file TXT hasil pengecekan.
  return replySafe(ctx, summaryText);
}
// Fungsi renderCleanTextPanel: menjalankan bagian render clean text panel pada bot.
async function renderCleanTextPanel(ctx, text, keyboard, extra = {}) {
  if (ctx.callbackQuery?.message?.photo?.length) {
    await ctx
      .deleteMessage()
      .catch((err) => logIgnoredError("INDEX", "PROMISE_IGNORED", err));
  }
  return renderTextPanel(ctx, text, keyboard, extra);
}
// Fungsi editOrSendTextPanelByMeta: menjalankan bagian edit or send text panel by meta pada bot.
async function editOrSendTextPanelByMeta(
  panelMeta,
  text,
  keyboard,
  extra = {},
) {
  const options = { ...extra, reply_markup: keyboard.reply_markup };
  if (panelMeta?.chatId && panelMeta?.messageId) {
    try {
      const result = await editMessageTextByMetaSafe(panelMeta, text, options, {
        maxAttempts: 3,
        timeoutMs: 30000,
      });
      if (result?.message_id && result?.chat?.id)
        return {
          chatId: result.chat.id,
          messageId: result.message_id,
          text: result.text ?? clampTelegramText(text),
          replyMarkup: result.reply_markup ?? options.reply_markup ?? null,
        };
      return {
        ...panelMeta,
        text: clampTelegramText(text),
        replyMarkup: options.reply_markup ?? null,
      };
    } catch (error) {
      if (/message is not modified/i.test(String(error))) return panelMeta;
      logApp(
        "WARN",
        panelMeta.chatId,
        "TELEGRAM",
        "EDIT_PANEL_FAIL",
        "gagal edit panel, kirim panel baru",
        {
          error:
            getTelegramErrorMessage(error) || error?.message || String(error),
        },
      );
    }
  }
  if (panelMeta?.chatId) {
    const sent = await sendMessageSafe(panelMeta.chatId, text, options, {
      maxAttempts: 4,
      timeoutMs: 30000,
    });
    if (sent?.chat?.id && sent?.message_id)
      return {
        chatId: sent.chat.id,
        messageId: sent.message_id,
        text: sent.text ?? clampTelegramText(text),
        replyMarkup: sent.reply_markup ?? options.reply_markup ?? null,
      };
  }
  return null;
}
// Fungsi finishPairingCodeFlow: menjalankan bagian finish pairing code flow pada bot.
async function finishPairingCodeFlow(userId, phoneNumberDigits, panelMeta) {
  try {
    const res = await requestNewSenderPairingCode(userId, phoneNumberDigits);
    const senderId = res?.senderId || "default";
    const targetMeta = panelMeta;
    if (res?.alreadyConnected) {
      clearActivePairingPanel(userId);
      clearUserState(userId);
      const snapshot = getSenderUiSnapshot(userId, senderId);
      const connectedPanel = await editOrSendTextPanelByMeta(
        targetMeta,
        buildSenderConnectedNotice({
          number: snapshot.number,
          activeCount: getConnectedSenderUiList(userId).length,
        }),
        connectedSenderKeyboard(),
      );
      if (connectedPanel) {
        markSenderReady(userId, senderId, {
          source: "pairing_already_connected",
          messageId: connectedPanel.messageId || null,
        });
      }
      return;
    }
    const updatedMeta = await editOrSendTextPanelByMeta(
      targetMeta,
      buildPairingCodePanel(phoneNumberDigits, res?.code || "-"),
      cancelStateKeyboard(),
      { parse_mode: "HTML" },
    );
    setUserState(userId, {
      type: "await_pairing_result",
      phoneNumberDigits,
      senderId,
    });
    trackActivePairingPanelFromMeta(userId, updatedMeta || targetMeta, senderId);
  } catch (error) {
    clearActivePairingPanel(userId);
    await editOrSendTextPanelByMeta(
      panelMeta,
      buildFriendlyIssueCard(
        "PAIRING BELUM BERHASIL",
        "Kode pairing belum bisa dibuat dengan mulus.",
        "Coba ulangi dari menu koneksi.",
      ),
      waMenuKeyboard(userId),
    );
  }
}
// Fungsi getReloadResultText: menjalankan bagian get reload result text pada bot.
function getReloadResultText(result, connected) {
  if (result?.authDeleted) return buildWaDisconnectedPanel();
  if (result?.autoRestarted)
    return connected
      ? buildFriendlyIssueCard(
          "SESI MASIH AKTIF",
          "Sesi lama masih terhubung.",
          "Periksa status sebelum mencoba kembali.",
        )
      : buildFriendlyIssueCard(
          "SESI MASIH TERSIMPAN",
          "Koneksi belum aktif penuh.",
          "Buka Senderku → Add Sender bila ingin menghubungkan ulang.",
        );
  return boxPanel("SENDER KOSONG", [
    `${ACCENTS.disconnect} Tidak ada Sender yang perlu dihapus.`,
    `${ACCENTS.pairing} Senderku siap digunakan.`,
  ]);
}

// Fungsi escapeHtml: menjalankan bagian escape html pada bot.
function escapeHtml(v) {
  return String(v || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
// Fungsi getDisplayName: menjalankan bagian get display name pada bot.
function getDisplayName(user) {
  const fn = String(user?.first_name || "").trim(),
    ln = String(user?.last_name || "").trim(),
    full = [fn, ln].filter(Boolean).join(" ").trim();
  if (full) return full;
  if (user?.username) return user.username;
  return `User ${user?.id || ""}`.trim();
}
// Fungsi formatSuccessRatio: menjalankan bagian format success ratio pada bot.
function formatSuccessRatio(v) {
  if (!Number.isFinite(v) || v <= 0) return "0";
  const r = v.toFixed(1);
  return r.endsWith(".0") ? r.slice(0, -2) : r;
}

function buildEmojiCommandUsageCard(notice = "") {
  return boxPanel("EMOJI UI", [
    notice ? `⚠️ ${notice}` : null,
    "Gunakan format:",
    "<code>/emoji ✅=✅</code>",
    "Emoji di kanan tanda = harus custom/premium emoji Telegram yang bergerak.",
    "👉 Gunakan /listemoji untuk melihat emoji UI yang bisa diganti.",
  ].filter(Boolean));
}

function buildEmojiListCard() {
  const rows = getUiEmojiRows();
  const premiumCount = rows.filter((row) => row.mapping?.customEmojiId).length;
  const lines = rows.map((row) => {
    if (row.mapping?.customEmojiId) {
      const motion = row.mapping.isVideo ? "video" : row.mapping.isAnimated ? "animasi" : "custom";
      return `${row.emoji} ${row.name} · 💎 PREMIUM (${motion})`;
    }
    return `${row.emoji} ${row.name} · ○ biasa`;
  });
  lines.push(`💎 ${premiumCount}/${rows.length} emoji sudah memakai custom emoji.`);
  return boxPanel("LIST EMOJI UI", lines);
}

async function handleEmojiCommand(ctx) {
  if (!isOwner(ctx.from?.id)) {
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "AKSES DITOLAK",
        "Pengaturan emoji hanya dapat diubah owner.",
        "Gunakan menu bot seperti biasa.",
      ),
    );
  }

  const parsed = extractEmojiMappingCommand(ctx.message || {});
  if (parsed.error) return replySafe(ctx, buildEmojiCommandUsageCard(parsed.error), { parse_mode: "HTML" });

  let sticker = null;
  try {
    const stickers = await telegramCallWithRetry(
      ctx,
      "getCustomEmojiStickers",
      (signal) => bot.telegram.callApi(
        "getCustomEmojiStickers",
        { custom_emoji_ids: [parsed.customEmojiId] },
        { signal },
      ),
      { maxAttempts: 3, timeoutMs: 30000 },
    );
    sticker = Array.isArray(stickers) ? stickers[0] : null;
  } catch (error) {
    return replySafe(
      ctx,
      buildEmojiCommandUsageCard(`Custom emoji tidak dapat diverifikasi: ${getTelegramErrorMessage(error)}`),
      { parse_mode: "HTML" },
    );
  }

  if (!sticker?.custom_emoji_id) {
    return replySafe(
      ctx,
      buildEmojiCommandUsageCard("Custom emoji ID tidak ditemukan oleh Telegram."),
      { parse_mode: "HTML" },
    );
  }

  if (sticker.is_animated !== true && sticker.is_video !== true) {
    return replySafe(
      ctx,
      buildEmojiCommandUsageCard("Emoji custom yang dipilih tidak bergerak. Pilih custom emoji animated/video."),
      { parse_mode: "HTML" },
    );
  }

  await emojiMappings.setMapping(parsed.emoji, {
    emoji: parsed.emoji,
    customEmojiId: parsed.customEmojiId,
    customAlt: sticker.emoji || parsed.customAlt || parsed.emoji,
    isAnimated: sticker.is_animated === true,
    isVideo: sticker.is_video === true,
    updatedAt: new Date().toISOString(),
  });

  return replySafe(
    ctx,
    boxPanel("EMOJI DIPERBARUI", [
      `${parsed.emoji} ${parsed.name}`,
      `💎 Premium ID: <code>${escapeHtml(parsed.customEmojiId)}</code>`,
      `🎞 Tipe: ${sticker.is_video ? "Video" : "Animated"}`,
      "✅ Mulai sekarang emoji ini dipakai sebagai custom emoji pada UI bot dan ikon tombol yang sesuai.",
    ]),
    { parse_mode: "HTML" },
  );
}

async function handleListEmojiCommand(ctx) {
  if (!isOwner(ctx.from?.id)) {
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "AKSES DITOLAK",
        "Daftar konfigurasi emoji hanya tersedia untuk owner.",
        "Gunakan menu bot seperti biasa.",
      ),
    );
  }
  return replySafe(ctx, buildEmojiListCard(), { parse_mode: "HTML" });
}
// Fungsi buildWaStatusPanel: membuat tampilan tombol Status WA.
function buildWaStatusPanel(connected) {
  return buildWaStatusCard(connected);
}

// Fungsi buildWaPairingPanel: membuat instruksi nomor pairing.
function buildWaPairingPanel(ctx = null) {
  return buildSenderPairingPromptCard({ group: Boolean(ctx && isGroupChat(ctx)) });
}

// Fungsi buildFormatChoiceCard: kartu pilih format hasil (Simple/Detail).
function buildFormatChoiceCard(
  total,
  { source = "cekbio", fileName = "", speed = DEFAULT_CHECK_SPEED } = {},
) {
  const knownTotal = Number.isFinite(Number(total)) && Number(total) >= 0
    ? Number(total)
    : null;
  const isTxt = source === "cekbiotxt";
  const selectedSpeed = normalizeCheckSpeed(speed);
  const summary = isTxt
    ? `📁 ${fileName || "File TXT"}`
    : `📦 ${knownTotal ?? 0} nomor`;

  return boxPanelFramed(isTxt ? "CEKBIO TXT" : "CEKBIO", [
    summary,
    `⚡ Speed : ${selectedSpeed} / Sender`,
    "📄 Simple · ringkas, nomor + status inti",
    "📋 Detail · lengkap dengan info profil bisnis",
    "👇 Pilih format atau ubah kecepatan.",
  ]);
}

function buildCheckSpeedChoiceCard(speed = DEFAULT_CHECK_SPEED) {
  const selectedSpeed = normalizeCheckSpeed(speed);
  return boxPanelFramed("KECEPATAN", [
    `⚡ Aktif : ${selectedSpeed} / Sender`,
    "👇 Pilih kecepatan baru.",
  ]);
}

// Fungsi buildPairMethodCard: kartu pilihan metode pairing.
function buildPairMethodCard() {
  return buildSenderMethodCard();
}

// Fungsi buildQrWaitCard: kartu saat menyiapkan QR.
function buildQrWaitCard(sessionId) {
  return buildSenderQrWaitCard(sessionId);
}

// Fungsi buildQrCaption: caption di bawah gambar QR.
function buildQrCaption(sessionId) {
  return buildSenderQrCaption(sessionId);
}

// Fungsi buildPairingStudioPanel: membuat progress persiapan pairing.
function buildPairingStudioPanel(phoneNumberDigits, percent = 0) {
  return boxPanel("PAIRING CODE", [
    `📱 +${phoneNumberDigits}`,
    `⏳ ${uxProgressBarPercent(percent)}`,
  ]);
}

// Fungsi buildPairingCodePanel: membuat kartu kode pairing.
function buildPairingCodePanel(phoneNumberDigits, code) {
  return buildSenderPairingCodeCard(phoneNumberDigits, code);
}

// Fungsi buildWaSessionProgressPanel: membuat progress putuskan sesi WA.
function buildWaSessionProgressPanel(percent = 0) {
  return boxPanel("HAPUS SENDER", [
    `🗑 ${uxProgressBarPercent(percent)}`,
  ]);
}

// Fungsi buildWaDisconnectedPanel: membuat panel WA berhasil diputuskan.
function buildWaDisconnectedPanel() {
  return buildWaDisconnectedCard();
}

// Fungsi buildMaintenancePanel: membuat kartu status maintenance untuk owner.
function buildMaintenancePanel(enabled, extraLine = "") {
  const lines = enabled
    ? ["🛠️ Bot sedang diperbarui.", "⏳ Fitur user sementara dijeda."]
    : ["✅ Semua fitur sudah aktif kembali.", "🚀 Bot siap digunakan."];
  if (extraLine) lines.push(String(extraLine));
  return boxPanel(enabled ? "MAINTENANCE" : "BOT AKTIF", lines);
}

// Fungsi buildMaintenanceDisabledNoticePanel: membuat notifikasi ke user saat maintenance selesai.
function buildMaintenanceDisabledNoticePanel() {
  return boxPanel("BOT AKTIF", [
    "✅ Semua fitur sudah aktif kembali.",
    "🚀 Bot siap digunakan.",
  ]);
}

// Fungsi buildMaintenanceNotificationDonePanel: membuat ringkasan notifikasi maintenance untuk owner.
function buildMaintenanceNotificationDonePanel(total, ok, failed) {
  return boxPanel("NOTIFIKASI MAINTENANCE", [
    `${ACCENTS.total} Target: ${formatStatNumber(total)} user`,
    `${ACCENTS.success} Terkirim: ${formatStatNumber(ok)}`,
    `${ACCENTS.failed} Gagal: ${formatStatNumber(failed)}`,
  ]);
}

// Fungsi getMaintenanceNotificationTargets: mengambil target user non-owner untuk notifikasi maintenance.
function getMaintenanceNotificationTargets(triggerOwnerId = null) {
  const seen = new Set();
  return stats
    .getUserIds()
    .map((id) => Number(id))
    .filter((id) => {
      if (!Number.isInteger(id) || id <= 0) return false;
      if (seen.has(id)) return false;
      seen.add(id);
      if (isOwner(id)) return false;
      if (triggerOwnerId != null && Number(triggerOwnerId) === id) return false;
      return true;
    });
}

// Fungsi notifyMaintenanceDisabledUsers: mengirim notifikasi ke user saat maintenance dinonaktifkan.
async function notifyMaintenanceDisabledUsers(triggerOwnerId = null) {
  const targets = getMaintenanceNotificationTargets(triggerOwnerId);
  const text = buildMaintenanceDisabledNoticePanel();
  const options = { reply_markup: menuOnlyKeyboard().reply_markup };
  let ok = 0;
  let failed = 0;

  for (const target of targets) {
    try {
      const sent = await sendMessageSafe(target, text, options, {
        maxAttempts: 4,
        timeoutMs: 45000,
      });
      if (sent) ok++;
      else failed++;
    } catch (error) {
      failed++;
      logApp("WARN", target, "MAINTENANCE", "NOTIFY_FAIL", "notifikasi maintenance gagal dikirim", {
        error: getTelegramErrorMessage(error),
      });
    }

    if (targets.length > 1) await sleep(BROADCAST_DELAY_MS);
  }

  return { total: targets.length, ok, failed };
}

// Fungsi runMaintenanceDisabledNotification: menjalankan notifikasi maintenance selesai di background.
function runMaintenanceDisabledNotification(ownerChatId, ownerId) {
  Promise.resolve()
    .then(() => notifyMaintenanceDisabledUsers(ownerId))
    .then((summary) => {
      if (!ownerChatId) return null;
      return sendMessageSafe(
        ownerChatId,
        buildMaintenanceNotificationDonePanel(summary.total, summary.ok, summary.failed),
        { reply_markup: menuOnlyKeyboard().reply_markup },
        { maxAttempts: 3, timeoutMs: 30000 },
      ).catch((err) => logIgnoredError("INDEX", "PROMISE_IGNORED", err));
    })
    .catch((error) => {
      logApp("ERROR", ownerId || "SYSTEM", "MAINTENANCE", "NOTIFY_ALL_FAIL", "proses notifikasi maintenance gagal", {
        error: getTelegramErrorMessage(error),
      });
    });
}

// Fungsi buildBroadcastPanel: membuat panel instruksi broadcast owner.
function buildBroadcastPanel() {
  return boxPanel("BROADCAST", [
    "📢 Kirim pesan yang ingin disebarkan ke seluruh user.",
    "🧩 HTML / rich text Telegram didukung.",
    `📦 Maks. ${BROADCAST_MAX_TEXT_LENGTH} karakter`,
  ]);
}

// Fungsi buildBroadcastProgressPanel: membuat panel progres broadcast.
function buildBroadcastProgressPanel(done, total, ok, failed, mode = "-") {
  const percent = total ? Math.round((done / total) * 100) : 100;
  return boxPanel("BROADCAST PROSES", [
    `📊 ${uxProgressBarPercent(percent)}`,
    `👥 ${formatStatNumber(done)}/${formatStatNumber(total)}`,
    `✅ ${formatStatNumber(ok)} terkirim · ❌ ${formatStatNumber(failed)} gagal`,
  ]);
}

// Fungsi buildBroadcastDonePanel: membuat ringkasan broadcast selesai.
function buildBroadcastDonePanel(total, ok, failed, mode = "-") {
  return boxPanel("BROADCAST SELESAI", [
    `👥 Target   : ${formatStatNumber(total)}`,
    `✅ Terkirim : ${formatStatNumber(ok)}`,
    `❌ Gagal    : ${formatStatNumber(failed)}`,
  ]);
}

function looksLikeHtmlBroadcast(text) {
  return /<\/?(?:b|strong|i|em|u|ins|s|strike|del|code|pre|a|blockquote|tg-emoji)\b/i.test(
    String(text || ""),
  );
}

function sanitizeTelegramEntities(entities) {
  if (!Array.isArray(entities)) return [];
  return entities
    .filter((entity) => Number.isInteger(entity?.offset) && Number.isInteger(entity?.length))
    .map((entity) => ({ ...entity }));
}

function applyCustomEmojiTagsForHtml(text, entities) {
  const customEntities = sanitizeTelegramEntities(entities)
    .filter((entity) => entity.type === "custom_emoji" && entity.custom_emoji_id)
    .sort((a, b) => b.offset - a.offset);
  let out = String(text || "");
  for (const entity of customEntities) {
    const start = entity.offset;
    const end = entity.offset + entity.length;
    const visibleEmoji = out.slice(start, end) || "⭐";
    const tag = `<tg-emoji emoji-id="${escapeHtml(entity.custom_emoji_id)}">${escapeHtml(visibleEmoji)}</tg-emoji>`;
    out = out.slice(0, start) + tag + out.slice(end);
  }
  return out;
}

function extractBroadcastPayload(ctx) {
  const message = ctx.message || {};
  const rawText = message.text || message.caption || "";
  const text = String(rawText || "").trim();
  if (!text) return { error: "Pesan broadcast kosong." };
  if (text.length > BROADCAST_MAX_TEXT_LENGTH) {
    return {
      error: `Pesan terlalu panjang. Maksimal ${BROADCAST_MAX_TEXT_LENGTH} karakter.`,
    };
  }

  const entities = sanitizeTelegramEntities(
    message.entities || message.caption_entities || [],
  );
  const hasCustomEmoji = entities.some((entity) => entity.type === "custom_emoji");
  const htmlMode = looksLikeHtmlBroadcast(text);
  let sendText = text;
  const options = { disable_web_page_preview: true };
  let mode = "Plain Text";

  if (htmlMode) {
    sendText = hasCustomEmoji ? applyCustomEmojiTagsForHtml(text, entities) : text;
    options.parse_mode = "HTML";
    mode = hasCustomEmoji ? "HTML + Premium Emoji" : "HTML";
  } else if (entities.length) {
    options.entities = entities;
    mode = hasCustomEmoji ? "Telegram Premium Emoji" : "Telegram Rich Text";
  }

  if (sendText.length > 4096) {
    return {
      error: "Pesan terlalu panjang setelah premium emoji HTML diproses. Kurangi isi broadcast.",
    };
  }

  return { text: sendText, options, mode };
}

async function sendBroadcastMessageSafe(chatId, payload) {
  try {
    return await telegramCallWithRetry(
      chatId,
      "broadcast.sendMessage",
      (signal) =>
        bot.telegram.callApi(
          "sendMessage",
          { chat_id: chatId, text: payload.text, ...payload.options },
          { signal },
        ),
      { maxAttempts: 4, timeoutMs: 45000 },
    );
  } catch (error) {
    const message = getTelegramErrorMessage(error);
    if (payload.options?.parse_mode === "HTML" && /can't parse entities|parse entities|unsupported start tag/i.test(message)) {
      const fallbackOptions = { disable_web_page_preview: true };
      return telegramCallWithRetry(
        chatId,
        "broadcast.sendMessage.plainFallback",
        (signal) =>
          bot.telegram.callApi(
            "sendMessage",
            { chat_id: chatId, text: payload.text, ...fallbackOptions },
            { signal },
          ),
        { maxAttempts: 3, timeoutMs: 45000 },
      );
    }
    throw error;
  }
}

async function promptBroadcast(ctx) {
  if (!isOwner(ctx.from?.id)) {
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "AKSES DITOLAK",
        "Menu ini hanya untuk owner.",
        "Kembali ke menu utama.",
      ),
    );
  }
  setUserState(ctx.from.id, { type: "await_owner_broadcast" });
  return renderTextPanel(ctx, buildBroadcastPanel(), cancelStateKeyboard());
}

async function handleBroadcastText(ctx) {
  const ownerId = ctx.from.id;
  if (!isOwner(ownerId)) {
    clearUserState(ownerId);
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "AKSES DITOLAK",
        "Menu ini hanya untuk owner.",
        "Kembali ke menu utama.",
      ),
    );
  }

  const payload = extractBroadcastPayload(ctx);
  if (payload.error) {
    return replySafe(ctx, buildFriendlyIssueCard("BROADCAST DITOLAK", payload.error, "Kirim ulang pesan broadcast yang lebih rapi."), cancelStateKeyboard());
  }

  clearUserState(ownerId);
  const targets = stats
    .getUserIds()
    .filter((id) => Number.isInteger(Number(id)) && Number(id) > 0);

  if (!targets.length) {
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "BROADCAST KOSONG",
        "Belum ada user penerima.",
        "Kembali ke menu owner.",
      ),
      menuOnlyKeyboard(),
    );
  }

  let ok = 0;
  let failed = 0;
  let done = 0;
  const progress = await replySafe(
    ctx,
    buildBroadcastProgressPanel(0, targets.length, 0, 0, payload.mode),
    menuOnlyKeyboard(),
  );

  for (const target of targets) {
    done++;
    try {
      const sent = await sendBroadcastMessageSafe(target, payload);
      if (sent) ok++;
      else failed++;
    } catch (error) {
      failed++;
      logApp("WARN", target, "BROADCAST", "SEND_FAIL", "broadcast gagal dikirim", {
        error: getTelegramErrorMessage(error),
      });
    }

    if (done % 20 === 0 || done === targets.length) {
      if (progress?.message_id) {
        await editMessageTextSafe(
          ctx,
          ctx.chat.id,
          progress.message_id,
          undefined,
          buildBroadcastProgressPanel(done, targets.length, ok, failed, payload.mode),
          menuOnlyKeyboard(),
        ).catch((err) => logIgnoredError("INDEX", "PROMISE_IGNORED", err));
      }
    }

    if (done < targets.length) await sleep(BROADCAST_DELAY_MS);
  }

  if (progress?.message_id) {
    return editMessageTextSafe(
      ctx,
      ctx.chat.id,
      progress.message_id,
      undefined,
      buildBroadcastDonePanel(targets.length, ok, failed, payload.mode),
      menuOnlyKeyboard(),
    ).catch(() => replySafe(ctx, buildBroadcastDonePanel(targets.length, ok, failed, payload.mode), menuOnlyKeyboard()));
  }

  return replySafe(
    ctx,
    buildBroadcastDonePanel(targets.length, ok, failed, payload.mode),
    menuOnlyKeyboard(),
  );
}
// Fungsi getMainMenuCardHtml: menjalankan bagian get main menu card html pada bot.
function getMainMenuCardHtml(user) {
  const userId = user?.id;
  return buildMainMenuCard({
    name: escapeHtml(getDisplayName(user)),
    userId: escapeHtml(userId || "-"),
    senderCount: userId ? getConnectedSenderUiList(userId).length : 0,
    speed: userId ? getUserDefaultCheckSpeed(userId) : DEFAULT_CHECK_SPEED,
    directLimit: DIRECT_CHECK_MAX_NUMBERS,
    txtLimit: TXT_CHECK_MAX_NUMBERS,
  });
}

// Fungsi getGroupMenuCardHtml: menjalankan bagian get group menu card html pada bot.
function getGroupMenuCardHtml(user) {
  return buildMainMenuCard({
    name: escapeHtml(getDisplayName(user)),
    userId: escapeHtml(user?.id || "-"),
    directLimit: DIRECT_CHECK_MAX_NUMBERS,
    txtLimit: TXT_CHECK_MAX_NUMBERS,
    group: true,
  });
}

// Fungsi replyGroupRecognizedStart: membalas /start di grup untuk user yang sudah dikenali.
async function replyGroupRecognizedStart(ctx) {
  const joinStatus = await getForceJoinStatus(ctx.from.id).catch((err) => {
    logIgnoredError("INDEX", "GROUP_START_JOIN_STATUS", err);
    return null;
  });
  const result = await replySafe(ctx, getUserKnownStatusText(ctx, ctx.from, joinStatus), {
    parse_mode: "HTML",
    ...groupHelperKeyboard(ctx),
  });
  return rememberGroupPanelOwnerFromResult(ctx, result);
}
// Fungsi showMainMenu: menjalankan bagian show main menu pada bot.
async function showMainMenu(ctx, text = null) {
  clearUserState(ctx.from.id);
  const panelText = text || (isGroupChat(ctx)
    ? getGroupMenuCardHtml(ctx.from)
    : getMainMenuCardHtml(ctx.from));
  return renderTextPanel(ctx, panelText, mainKeyboard(ctx.from.id));
}
// Fungsi getSafeUserSlug: menjalankan bagian get safe user slug pada bot.
function getSafeUserSlug(ctx) {
  return (ctx.from?.username || ctx.from?.first_name || `user_${ctx.from.id}`)
    .toString()
    .replace(/[^a-zA-Z0-9_-]/g, "_");
}

// Tanggal singkat untuk nama file: YYYY-MM-DD.
function getDateStamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
// Fungsi extractCommandPayload: menjalankan bagian extract command payload pada bot.
function extractCommandPayload(rawText, commandName) {
  const pattern = new RegExp(`^\\/${commandName}(?:@\\w+)?\\b`, "i");
  return String(rawText || "")
    .replace(pattern, "")
    .trim();
}
// Fungsi rememberUser: menyimpan user yang sudah dikenali ke statistik bot.
function rememberUser(ctx, options = {}) {
  if (ctx.from?.id != null) {
    const userId = Number(ctx.from.id);
    if (
      isGroupChat(ctx) &&
      !options.allowGroupRegister &&
      !isKnownTelegramUser(userId)
    ) {
      return { recognized: false, tracked: null };
    }
    const isKnown = knownUsers.has(userId);
    knownUsers.add(userId);
    const tracked = stats.trackUser(userId);
    if (!isKnown || tracked.isNew)
      logApp(
        "INFO",
        ctx,
        isOwner(userId) ? "OWNER" : "USER",
        "TRACKED",
        `${isOwner(userId) ? "owner" : "user"} dikenali oleh bot`,
        { knownUsersNew: !isKnown, statsNew: tracked.isNew },
      );
    return { recognized: true, tracked };
  }
  return { recognized: false, tracked: null };
}

// Fungsi getCheckBioUsageText: membuat bantuan singkat command /cekbio.
function getCheckBioUsageText(notice = "") {
  const lines = [
    notice ? `⚠️ ${notice}` : "📱 Kirim nomor setelah command /cekbio.",
    "✍️ Contoh: /cekbio 62812xxxxxxx",
    `📦 Maks. ${DIRECT_CHECK_MAX_NUMBERS} nomor`,
    "📄 Hasil: TXT Simple / Detail",
  ];
  return boxPanel("CEKBIO", lines);
}

// Fungsi getCheckBioTxtUsageText: membuat bantuan singkat command /cekbiotxt.
function getCheckBioTxtUsageText(notice = "") {
  const lines = [
    notice ? `⚠️ ${notice}` : null,
    "📄 Upload file TXT dengan caption /cekbiotxt.",
    "↩️ Atau reply file lalu kirim /cekbiotxt.",
    "📱 Satu nomor per baris.",
    `📦 Maks. ${formatStatNumber(TXT_CHECK_MAX_NUMBERS)} nomor/file`,
  ];
  return boxPanel("CEKBIO TXT", lines);
}

async function replyHelp(ctx) {
  return renderTextPanel(
    ctx,
    buildHelpCard({
      directLimit: DIRECT_CHECK_MAX_NUMBERS,
      txtLimit: TXT_CHECK_MAX_NUMBERS,
    }),
    isGroupChat(ctx) ? {} : menuOnlyKeyboard(),
  );
}

async function renderCheckProgress(
  ctx,
  job,
  text,
  keyboard = null,
  { signal, fallbackPanel = null } = {},
) {
  // Lifecycle/progress panels sengaja plain-text agar aman di semua client
  // Telegram (terutama mobile) dan tidak pernah menampilkan tag HTML mentah.
  // Premium emoji tetap ditangani otomatis oleh prepareUiTelegramText().
  const options = keyboard ? { reply_markup: keyboard.reply_markup } : {};
  return updateTrackedProgressPanel(job, {
    fallbackPanel,
    editPanel: (currentPanel) =>
      editMessageTextSafe(
        ctx,
        currentPanel.chat?.id || ctx.chat.id,
        currentPanel.message_id,
        undefined,
        text,
        options,
        { signal },
      ),
    discardPanel: (currentPanel) =>
      deleteProgressPanelMessage(ctx, currentPanel, { signal }),
    resendPanel: async () => {
      const resent = await replySafe(ctx, text, options, { signal });
      return rememberGroupPanelOwnerFromResult(ctx, resent);
    },
    onEditFallback: (error) =>
      logApp(
        "WARN",
        ctx,
        "CHECK",
        "CHECK_PANEL_EDIT_RESEND",
        "panel cek tidak tersedia untuk diedit; mengirim panel pengganti",
        { error: getTelegramErrorMessage(error) },
      ),
  });
}

async function renderCheckLifecyclePanelSafe(
  ctx,
  job,
  text,
  keyboard,
  {
    signal,
    logCode = "CHECK_PANEL_UI_FAIL",
    fallbackPanel = null,
  } = {},
) {
  try {
    return await renderCheckProgress(ctx, job, text, keyboard, {
      signal,
      fallbackPanel,
    });
  } catch (error) {
    if (signal?.aborted) throw signal.reason || error;
    logIgnoredError("CHECK", logCode, error);
    return job?.progressMsg || fallbackPanel || null;
  }
}

async function deleteProgressPanelMessage(ctx, progressMsg, { signal } = {}) {
  if (!progressMsg?.message_id || !ctx.chat?.id) return false;
  await telegramCallWithRetry(
    ctx,
    "deleteProgressMessage",
    (attemptSignal) =>
      ctx.telegram.callApi(
        "deleteMessage",
        {
          chat_id: progressMsg.chat?.id || ctx.chat.id,
          message_id: progressMsg.message_id,
        },
        { signal: attemptSignal },
      ),
    { maxAttempts: 2, timeoutMs: 20000, signal },
  ).catch((error) => logIgnoredError("INDEX", "PROMISE_IGNORED", error));
  return true;
}

async function deleteCheckProgress(ctx, job, { signal } = {}) {
  if (!job) return false;
  return deleteTrackedProgressPanel(job, {
    deletePanel: (currentPanel) =>
      deleteProgressPanelMessage(ctx, currentPanel, { signal }),
  });
}

async function deliverStateReport(
  ctx,
  state,
  { baseName, cachedResults = new Map(), signal, format = null, sourceName = "" } = {},
) {
  await sendPolishAction(ctx, "upload_document", { signal }).catch((error) => {
    logIgnoredError("CHECK", "UPLOAD_ACTION_FAIL", error);
  });

  const outcome = await createAndDeliverReportPair({
    state,
    baseName,
    titleName: "MOCI",
    cachedResults,
    format,
    sourceName,
    // Keterangan (kartu ringkasan) disatukan sebagai caption file.
    buildCaption: (summary) => buildResultCaption(summary, format),
    sendFile: ({ filePath, caption }) =>
      replyWithDocumentSafe(ctx, filePath, { signal, caption }),
    onFileFailure: (file, error) =>
      logApp(
        "ERROR",
        ctx,
        "CHECK",
        file.kind === "summary" ? "SUMMARY_REPORT_UPLOAD_FAIL" : "FULL_REPORT_UPLOAD_FAIL",
        `${file.kind === "summary" ? "laporan ringkas" : "laporan lengkap"} gagal dikirim`,
        {
          path: file.filePath,
          error: getTelegramErrorMessage(error),
        },
      ),
  });

  return outcome.summary;
}

async function runPersistentCheckState({
  ctx,
  job,
  state,
  progressMsg,
  mode,
  fileName = "",
  baseName,
  signal,
  format = null,
  speedPerSender = DEFAULT_CHECK_SPEED,
}) {
  const userId = ctx.from.id;
  const safeChunkSize = Math.max(1, Number(config.CHUNK_SIZE) || 200);
  const batchTotal = Math.max(1, Math.ceil(state.total / safeChunkSize));
  const checkType = String(state?.metadata?.type || "");
  const useMultiSenderPool = ["cekbio", "cekbiotxt"].includes(checkType);
  const selectedSpeed = normalizeCheckSpeed(speedPerSender);
  job.speedPerSender = selectedSpeed;
  let cachedResults = new Map();
  let lastEdit = 0;
  let editBusy = false;

  if (!job.checkStartedAt) job.checkStartedAt = Date.now();
  setTrackedProgressPanel(job, progressMsg);

  try {
    while (state.nextIndex < state.total) {
      signal.throwIfAborted();
      job.status = "running";
      job.pauseManifest = null;
      job.pauseContext = null;
      if (!job.sessionDisconnectController) {
        job.sessionDisconnectController = new AbortController();
      }

      const checkConcurrency = useMultiSenderPool
        ? senderCheckRouter.getConcurrency(
            userId,
            runtime.MULTI_SENDER_MAX_CONCURRENCY,
            {
              maxActivePerSender: selectedSpeed,
              totalLimit: Math.max(1, state.total - state.nextIndex),
            },
          )
        : runtime.MAX_CONCURRENCY;
      const run = await runResumableChecks({
        userId,
        state,
        startIndex: state.nextIndex,
        cachedResults,
        concurrency: checkConcurrency,
        delayMs: runtime.CHECK_DELAY_MS,
        jobSignal: signal,
        sessionSignal: job.sessionDisconnectController.signal,
        checkNumber: useMultiSenderPool
          ? (ownerId, number, options) =>
              cekSafeWithSenderPool(ownerId, number, {
                ...options,
                checkType,
                speedPerSender: selectedSpeed,
              })
          : cekSafe,
        onProgress: async (done) => {
          if (!job.progressMsg?.message_id || editBusy) return;
          const now = Date.now();
          if (now - lastEdit < 1200 && done !== state.total) return;
          lastEdit = now;
          editBusy = true;
          try {
            const senderSnapshot = senderCheckRouter.getSnapshot(userId, {
              maxActivePerSender: selectedSpeed,
            });
            const senderCount = senderSnapshot.ready + senderSnapshot.busy;
            await renderCheckLifecyclePanelSafe(
              ctx,
              job,
              buildCheckProgressCard({
                done,
                total: state.total,
                senderCount,
                batchSize: checkConcurrency,
                startedAt: job.checkStartedAt,
              }),
              activeCheckKeyboard(),
              { signal, logCode: "PROGRESS_ASYNC_FAIL" },
            );
          } finally {
            editBusy = false;
          }
        },
      });

      cachedResults = run.cachedResults;
      if (!run.paused || state.nextIndex >= state.total) break;

      const manifest = await state.savePause({
        cachedResults,
        disconnect: run.disconnect,
      });
      clearPausedReconnectWait(job);
      job.status = "paused";
      job.pauseManifest = manifest;
      job.pauseContext = {
        ctx,
        state,
        cachedResults,
        baseName,
        mode,
        fileName,
        speedPerSender: selectedSpeed,
      };
      job.sendConfirmationPending = false;
      job.finalizationInProgress = false;
      job.resumeRequested = false;
      job.reconnectResumeClaimed = false;
      job.pauseTimeout?.();
      const pauseActionPromise = waitForPausedJobAction(job, signal);

      await renderCheckLifecyclePanelSafe(
        ctx,
        job,
        buildPausedCheckCard({
          checked: manifest.checkedCount,
          pending: manifest.pendingCount,
          total: manifest.total,
        }),
        pausedCheckKeyboard(),
        { signal, logCode: "PAUSED_PANEL_FAIL" },
      );

      let pauseActionWait = pauseActionPromise;
      while (true) {
        const pauseAction = await pauseActionWait;
        signal.throwIfAborted();
        if (pauseAction === "finalize") return { finalizedPartial: true };

        // Arm terminal-disconnect detection before rechecking connectivity so a
        // close racing with the button click cannot turn the remaining input
        // into ordinary failed results.
        job.sessionDisconnectController = new AbortController();
        job.status = "running";
        if (
          isCheckJobSenderReady(job, userId) &&
          !job.sessionDisconnectController.signal.aborted
        ) {
          break;
        }

        job.status = "paused";
        job.resumeRequested = false;
        job.reconnectResumeClaimed = false;
        pauseActionWait = waitForPausedJobAction(job, signal);
        armPausedReconnectResume(job, ctx);
      }

      clearPausedReconnectWait(job);
      job.resumeRequested = false;
      job.reconnectResumeClaimed = false;
      job.sendConfirmationPending = false;
      job.pauseManifest = null;
      job.pauseContext = null;
      job.resumeTimeout?.();
      await state.clearPauseArtifacts();

      const done = state.nextIndex;
      const senderSnapshot = senderCheckRouter.getSnapshot(userId, {
        maxActivePerSender: selectedSpeed,
      });
      const senderCount = senderSnapshot.ready + senderSnapshot.busy;
      const resumeBatchSize = senderCheckRouter.getConcurrency(
        userId,
        runtime.MULTI_SENDER_MAX_CONCURRENCY,
        {
          maxActivePerSender: selectedSpeed,
          totalLimit: Math.max(1, state.total - done),
        },
      );
      await renderCheckLifecyclePanelSafe(
        ctx,
        job,
        buildCheckProgressCard({
          done,
          total: state.total,
          senderCount,
          batchSize: resumeBatchSize,
          startedAt: job.checkStartedAt,
        }),
        activeCheckKeyboard(),
        { signal, logCode: "AUTO_RESUME_PANEL_FAIL" },
      );
    }

    // Progress selesai: hilangkan panel cek lalu gunakan chat action
    // upload_document selama dua file hasil disiapkan/dikirim.
    await deleteCheckProgress(ctx, job, { signal });

    let summary;
    try {
      summary = await deliverStateReport(ctx, state, {
        baseName,
        cachedResults,
        signal,
        format,
        sourceName: fileName || "Input langsung",
      });
    } catch (error) {
      if (signal.aborted) throw signal.reason || error;
      if (!error.reportSummary) throw error;
      summary = error.reportSummary;
      logApp(
        "ERROR",
        ctx,
        "CHECK",
        "EXPORT_FAIL",
        "gagal membuat atau mengirim file laporan",
        { error: error?.message || String(error) },
      );
      await replySafe(
        ctx,
        buildFriendlyIssueCard(
          "LAPORAN TERTAHAN",
          "Pengecekan selesai, tetapi dokumen belum bisa dikirim dengan mulus.",
          "Coba ulangi beberapa saat lagi atau cek koneksi Telegram bot.",
        ),
        contextMainKeyboard(ctx, userId),
        { signal },
      );
    }
    await deleteCheckProgress(ctx, job, { signal });
    stats.recordCheckCounters({
      total: summary.total,
      failed: summary.failedChecks,
    });
    // Ringkasan sudah menyatu sebagai caption file, tidak dikirim terpisah lagi.
    return null;
  } finally {
    job.pauseContext = null;
    job.pauseManifest = null;
    job.resumePausedCheck = null;
    job.finalizePausedCheck = null;
    job.sendConfirmationPending = false;
    // Cleanup always targets the latest tracked panel and intentionally does
    // not inherit an aborted signal, so abort/timeout cannot leave it behind.
    await deleteCheckProgress(ctx, job).catch(() => {});
    await state.cleanup().catch(() => {});
  }
}

// Fungsi runCheckBioFromNumbers: memproses daftar nomor dari /cekbio sampai laporan TXT dikirim.
async function runCheckBioFromNumbers(
  ctx,
  nums,
  { signal, job, format = null, speedPerSender = DEFAULT_CHECK_SPEED } = {},
) {
  const userId = ctx.from.id;
  const waTargetUserId = userId;

  // Persiapan cepat tidak membuat bubble palsu; cukup indikator Telegram.
  await sendPolishAction(ctx, "typing", { signal });
  const senderSnapshot = await prepareUserSenderPoolForCheck(
    waTargetUserId,
    8000,
  );
  if (!senderSnapshot.available) {
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "SENDER BELUM TERHUBUNG",
        "Belum ada Sender milik kamu yang siap untuk melakukan pengecekan.",
        "Buka Senderku → Add Sender, lalu jalankan cek ulang.",
      ),
      contextMainKeyboard(ctx, userId),
      { signal },
    );
  }

  const selectedSpeed = normalizeCheckSpeed(speedPerSender);
  job.speedPerSender = selectedSpeed;
  job.checkStartedAt = Date.now();
  const speedSnapshot = senderCheckRouter.getSnapshot(userId, {
    maxActivePerSender: selectedSpeed,
  });
  const senderCount = speedSnapshot.ready + speedSnapshot.busy;
  const batchSize = senderCheckRouter.getConcurrency(
    userId,
    runtime.MULTI_SENDER_MAX_CONCURRENCY,
    { maxActivePerSender: selectedSpeed, totalLimit: nums.length },
  );
  const progressMsg = await sendMessageSafe(
    ctx.chat.id,
    buildCheckProgressCard({
      done: 0,
      total: nums.length,
      senderCount,
      batchSize,
      startedAt: job.checkStartedAt,
    }),
    {
      reply_markup: activeCheckKeyboard().reply_markup,
    },
    { maxAttempts: 2, timeoutMs: 15000, signal },
  ).catch((error) => {
    logIgnoredError("INDEX", "PROMISE_NULL", error);
    return null;
  });
  setTrackedProgressPanel(job, progressMsg);
  if (progressMsg?.message_id) {
    rememberGroupPanelOwner(userId, progressMsg.chat?.id ?? ctx.chat?.id, progressMsg.message_id);
  }

  const stamp = `${getSafeUserSlug(ctx)}_${getDateStamp()}`;
  const state = await createCheckState({
    numbers: nums,
    total: nums.length,
    metadata: { type: "cekbio", userId, chatId: ctx.chat.id },
  });
  return runPersistentCheckState({
    ctx,
    job,
    state,
    progressMsg: job.progressMsg || progressMsg,
    mode: "Cek nomor langsung",
    baseName: `cekbio_detail_${stamp}`,
    signal,
    format,
    speedPerSender: selectedSpeed,
  });
}

// Fungsi handleCheckBioDocument: memproses file TXT secara streaming dan bounded concurrency.
async function handleCheckBioDocument(ctx, doc) {
  const userId = ctx.from.id;
  const fileDescriptor = describeTelegramTextFile(doc?.file_name);
  if (fileDescriptor.extension !== ".txt") {
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "FORMAT FILE BELUM COCOK",
        "Cek file hanya menerima dokumen .txt.",
        "Kirim file .txt dengan satu nomor per baris.",
      ),
      contextMainKeyboard(ctx, userId),
    );
  }
  // Simpan dokumen, minta user pilih format dulu. Kecepatan mengikuti
  // preferensi terakhir user dan default 100/Sender untuk user baru.
  const preferredSpeed = getUserDefaultCheckSpeed(userId);
  setUserState(userId, {
    type: "await_format_choice",
    source: "cekbiotxt",
    document: doc,
    speed: preferredSpeed,
  });
  return renderCleanTextPanel(
    ctx,
    buildFormatChoiceCard(null, {
      source: "cekbiotxt",
      fileName: fileDescriptor.safeFileName,
      speed: preferredSpeed,
    }),
    keyboardPresentation.formatChoiceKeyboard({
      callbacks: CALLBACKS,
      speed: preferredSpeed,
    }),
  );
}

// Fungsi runCheckBioDocumentWithFormat: proses file TXT dengan format terpilih.
async function runCheckBioDocumentWithFormat(
  ctx,
  doc,
  { signal, job, format = null, speedPerSender = DEFAULT_CHECK_SPEED } = {},
) {
  const userId = ctx.from.id;
  const waTargetUserId = userId;
  const fileDescriptor = describeTelegramTextFile(doc?.file_name);
  const fileName = fileDescriptor.safeFileName;
  let progressMsg = null;
  let downloaded;

  try {
    signal.throwIfAborted();
    await sendPolishAction(ctx, "typing", { signal });

    const senderSnapshot = await prepareUserSenderPoolForCheck(
      waTargetUserId,
      8000,
    );
    if (!senderSnapshot.available) {
      return replySafe(
        ctx,
        buildFriendlyIssueCard(
          "SENDER BELUM TERHUBUNG",
          "Belum ada Sender milik kamu yang siap untuk membaca daftar nomor.",
          "Buka Senderku → Add Sender, lalu kirim file ulang.",
        ),
        contextMainKeyboard(ctx, userId),
        { signal },
      );
    }

    // Download + normalisasi adalah persiapan; tampilkan chat action saja.
    await sendPolishAction(ctx, "typing", { signal });
    const fileUrl = await getTelegramFileUrl(ctx, doc.file_id, { signal });
    downloaded = await downloadTelegramFileToTemp({
      fileUrl,
      signal,
      timeoutMs: config.DOWNLOAD_TIMEOUT_MS,
      maxAttempts: config.DOWNLOAD_RETRY_ATTEMPTS,
      retryBaseMs: config.DOWNLOAD_RETRY_BASE_MS,
      onRetry({ attempt, nextAttempt, maxAttempts, delayMs, error }) {
        logApp(
          "WARN",
          ctx,
          "CEKBIOTXT",
          "DOWNLOAD_RETRY",
          "download file Telegram mengalami gangguan transien",
          {
            attempt,
            nextAttempt,
            maxAttempts,
            delayMs,
            error: getTelegramErrorMessage(error),
          },
        );
      },
    });
    const normalizedPath = path.join(
      path.dirname(downloaded.filePath),
      "normalized-numbers.txt",
    );
    const normalized = await normalizeNumberFile(
      downloaded.filePath,
      normalizedPath,
      {
        limit: TXT_CHECK_MAX_NUMBERS,
        signal,
        normalizeNumber: normalizeInputNumber,
      },
    );

    if (!normalized.count) {
      return replySafe(
        ctx,
        buildFriendlyIssueCard(
          "NOMOR BELUM TERBACA",
          "File tidak berisi nomor valid.",
          "Gunakan satu nomor per baris.",
        ),
        contextMainKeyboard(ctx, userId),
        { signal },
      );
    }

    const selectedSpeed = normalizeCheckSpeed(speedPerSender);
    job.speedPerSender = selectedSpeed;
    job.checkStartedAt = Date.now();
    const speedSnapshot = senderCheckRouter.getSnapshot(userId, {
      maxActivePerSender: selectedSpeed,
    });
    const senderCount = speedSnapshot.ready + speedSnapshot.busy;
    const batchSize = senderCheckRouter.getConcurrency(
      userId,
      runtime.MULTI_SENDER_MAX_CONCURRENCY,
      { maxActivePerSender: selectedSpeed, totalLimit: normalized.count },
    );
    progressMsg = await sendMessageSafe(
      ctx.chat.id,
      buildCheckProgressCard({
        done: 0,
        total: normalized.count,
        senderCount,
        batchSize,
        startedAt: job.checkStartedAt,
      }),
      {
        reply_markup: activeCheckKeyboard().reply_markup,
      },
      { maxAttempts: 2, timeoutMs: 15000, signal },
    ).catch((error) => {
      logIgnoredError("INDEX", "PROMISE_NULL", error);
      return null;
    });
    setTrackedProgressPanel(job, progressMsg);
    if (progressMsg?.message_id) {
      rememberGroupPanelOwner(userId, progressMsg.chat?.id ?? ctx.chat?.id, progressMsg.message_id);
    }

    const stamp = `${getSafeUserSlug(ctx)}_${getDateStamp()}`;
    const state = await createCheckState({
      inputPath: normalized.filePath,
      total: normalized.count,
      metadata: { type: "cekbiotxt", userId, chatId: ctx.chat.id, fileName },
    });
    await downloaded.cleanup();
    downloaded = null;
    return runPersistentCheckState({
      ctx,
      job,
      state,
      progressMsg: job.progressMsg || progressMsg,
      mode: "Cek dari file TXT",
      fileName,
      baseName: `cekbio_detail_${fileDescriptor.safeStem}_${stamp}`,
      signal,
      format,
      speedPerSender: selectedSpeed,
    });
  } catch (error) {
    if (signal.aborted) throw signal.reason || error;
    logApp(
      "ERROR",
      ctx,
      "CEKBIOTXT",
      "PROCESS_ERROR",
      "proses cekbiotxt gagal",
      {
        code: error?.code || error?.cause?.code || "-",
        error: getTelegramErrorMessage(error),
      },
    );
    const isLimit =
      error instanceof NumberLimitError || error?.code === "NUMBER_LIMIT_EXCEEDED";
    const isTelegramDownloadFailure = [
      "TELEGRAM_FILE_ACCESS_FAILED",
      "TELEGRAM_FILE_DOWNLOAD_FAILED",
    ].includes(error?.code);
    const text = isLimit
      ? buildFriendlyIssueCard(
          "LIMIT /CEKBIOTXT",
          `Maksimal ${formatStatNumber(TXT_CHECK_MAX_NUMBERS)} nomor per file TXT.`,
          "Pecah file menjadi beberapa bagian.",
        )
      : isTelegramDownloadFailure
        ? buildTelegramDownloadFailedCard()
        : buildFriendlyIssueCard(
            "FILE BELUM BISA DIPROSES",
            "File masuk, tetapi belum bisa dirapikan menjadi laporan.",
            "Pastikan isi file .txt berisi satu nomor per baris, lalu kirim ulang.",
          );
    if (job.progressMsg?.message_id) {
      await renderCheckProgress(ctx, job, text, contextMainKeyboard(ctx, userId));
    } else {
      await replySafe(ctx, text, contextMainKeyboard(ctx, userId));
    }
    return null;
  } finally {
    await downloaded?.cleanup().catch(() => {});
  }
}

// Fungsi promptCheckBio: menjalankan bagian prompt check bio pada bot.
async function promptCheckBio(ctx) {
  return replySafe(ctx, getCheckBioUsageText());
}
// Fungsi handleCheckBioText: membaca dan memvalidasi nomor dari command /cekbio.
async function handleCheckBioText(ctx, rawText) {
  const userId = ctx.from.id;
  const cleaned = String(rawText || "").replace(/--txt/gi, "");
  const nums = parseNumbersFromMessage(cleaned, DIRECT_CHECK_MAX_NUMBERS + 1);
  if (!nums.length)
    return replySafe(ctx, getCheckBioUsageText("Nomor belum terbaca."));
  if (nums.length > DIRECT_CHECK_MAX_NUMBERS) {
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "LIMIT /CEKBIO",
        `Maksimal ${DIRECT_CHECK_MAX_NUMBERS} nomor per command.`,
        "Untuk jumlah besar, pakai /cekbiotxt dengan file .txt.",
      ),
    );
  }
  // Simpan nomor di state, minta user pilih format dulu (Simple/Detail).
  // Kecepatan mengikuti preferensi terakhir user.
  const preferredSpeed = getUserDefaultCheckSpeed(userId);
  setUserState(userId, {
    type: "await_format_choice",
    source: "cekbio",
    numbers: nums,
    speed: preferredSpeed,
  });
  return renderCleanTextPanel(
    ctx,
    buildFormatChoiceCard(nums.length, { speed: preferredSpeed }),
    keyboardPresentation.formatChoiceKeyboard({
      callbacks: CALLBACKS,
      speed: preferredSpeed,
    }),
  );
}
async function requestPausedCheckResultsConfirmation(ctx) {
  const userId = ctx.from.id;
  const lockKey = getCheckLockKey(userId);
  const currentJob = checkJobQueue.get(lockKey);
  if (currentJob?.finalizationInProgress) {
    return replySafe(
      ctx,
      boxPanel("HASIL SEDANG DIKIRIM", [
        `${ACCENTS.status} File hasil sementara sedang disiapkan.`,
      ]),
    );
  }

  const activeJob = getPausedCheckJob(checkJobQueue, lockKey);
  if (!activeJob) {
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "SESI SUDAH SELESAI",
        "Pengecekan jeda ini sudah tidak tersedia.",
        "Jalankan /cekbio atau /cekbiotxt bila ingin memulai pengecekan baru.",
      ),
      contextMainKeyboard(ctx, userId),
    );
  }

  clearPausedReconnectWait(activeJob);
  const manifest = beginPausedCheckSendConfirmation(activeJob);
  if (!manifest) {
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "KONFIRMASI BELUM TERSEDIA",
        "Aksi kirim hasil belum bisa dibuka sekarang.",
        "Coba tekan Kirim Hasil sekali lagi.",
      ),
      pausedCheckKeyboard(),
    );
  }

  return renderCheckLifecyclePanelSafe(
    ctx,
    activeJob,
    buildPausedCheckSendConfirmationCard({ remaining: manifest.pendingCount }),
    pausedCheckConfirmationKeyboard(),
    { fallbackPanel: ctx.callbackQuery?.message || null },
  );
}

async function cancelPausedCheckResultsConfirmation(ctx) {
  const userId = ctx.from.id;
  const activeJob = getPausedCheckJob(checkJobQueue, getCheckLockKey(userId));
  if (!activeJob) {
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "SESI SUDAH SELESAI",
        "Pengecekan jeda ini sudah tidak tersedia.",
        "Jalankan command cek bila ingin memulai proses baru.",
      ),
      contextMainKeyboard(ctx, userId),
    );
  }

  if (!cancelPausedCheckSendConfirmation(activeJob)) {
    return renderCheckLifecyclePanelSafe(
      ctx,
      activeJob,
      buildPausedCheckCard({
        checked: activeJob.pauseManifest?.checkedCount,
        pending: activeJob.pauseManifest?.pendingCount,
        total: activeJob.pauseManifest?.total,
      }),
      pausedCheckKeyboard(),
      { fallbackPanel: ctx.callbackQuery?.message || null },
    );
  }

  return renderCheckLifecyclePanelSafe(
    ctx,
    activeJob,
    buildPausedCheckCard({
      checked: activeJob.pauseManifest.checkedCount,
      pending: activeJob.pauseManifest.pendingCount,
      total: activeJob.pauseManifest.total,
    }),
    pausedCheckKeyboard(),
    { fallbackPanel: ctx.callbackQuery?.message || null },
  );
}

async function confirmPausedCheckResults(ctx) {
  const userId = ctx.from.id;
  const lockKey = getCheckLockKey(userId);
  const currentJob = checkJobQueue.get(lockKey);
  if (currentJob?.finalizationInProgress) {
    return replySafe(
      ctx,
      boxPanel("HASIL SEDANG DIKIRIM", [
        `${ACCENTS.status} File hasil sementara sedang disiapkan.`,
      ]),
    );
  }

  const activeJob = getPausedCheckJob(checkJobQueue, lockKey);
  if (!activeJob || !activeJob.sendConfirmationPending) {
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "SESI SUDAH SELESAI",
        "Konfirmasi ini sudah tidak aktif.",
        "Jalankan /cekbio atau /cekbiotxt bila ingin memulai pengecekan baru.",
      ),
      contextMainKeyboard(ctx, userId),
    );
  }

  clearPausedReconnectWait(activeJob);
  const { state, cachedResults, baseName, fileName } = activeJob.pauseContext;
  try {
    return await finalizePausedCheckJob(activeJob, {
      deliverReport: () =>
        deliverStateReport(ctx, state, {
          baseName: `${baseName}_sebagian_${Date.now()}`,
          cachedResults,
          signal: activeJob.controller.signal,
          sourceName: fileName || "Input langsung",
        }),
      sendSummary: (summary) =>
        replySafe(
          ctx,
          buildSummaryCard(summary.counts, summary.total, "Sebagian"),
        ),
      deletePanel: () => deleteCheckProgress(ctx, activeJob),
      recordSummary: (summary) =>
        stats.recordCheckCounters({
          total: summary.total,
          failed: summary.failedChecks,
        }),
    });
  } catch (error) {
    if (activeJob.controller.signal.aborted) return null;
    logApp("ERROR", ctx, "CHECK", "FINAL_PARTIAL_REPORT_FAIL", "gagal mengirim hasil sebagian final", {
      error: error?.message || String(error),
    });
    return renderCheckLifecyclePanelSafe(
      ctx,
      activeJob,
      buildFriendlyIssueCard(
        "HASIL BELUM TERKIRIM",
        "File hasil sebagian belum bisa dibuat atau dikirim.",
        "State jeda tetap aman. Tekan Kirim Hasil untuk mencoba lagi.",
      ),
      pausedCheckKeyboard(),
      { fallbackPanel: ctx.callbackQuery?.message || null },
    );
  }
}

async function resumePausedCheck(ctx) {
  const userId = ctx.from.id;
  const activeJob = checkJobQueue.get(getCheckLockKey(userId));
  if (isMultiSenderCheckType(activeJob?.type) && !isCheckJobSenderReady(activeJob, userId)) {
    await prepareUserSenderPoolForCheck(userId, 2500).catch((error) =>
      logIgnoredError("CHECK", "MANUAL_RESUME_POOL_PREPARE_FAIL", error),
    );
  }
  const resumeStatus = getResumeStatus(
    activeJob,
    activeJob ? isCheckJobSenderReady(activeJob, userId) : false,
  );
  if (resumeStatus === "missing") {
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "PENGECEKAN TIDAK DIJEDA",
        "Tidak ada pengecekan yang menunggu untuk dilanjutkan.",
        "Jalankan command cek bila ingin memulai proses baru.",
      ),
      contextMainKeyboard(ctx, userId),
    );
  }

  if (resumeStatus === "finalizing") {
    return replySafe(
      ctx,
      boxPanel("HASIL SEDANG DIKIRIM", [
        `${ACCENTS.status} File hasil sementara sedang disiapkan.`,
      ]),
    );
  }

  if (resumeStatus === "confirmation_pending") {
    return renderCheckLifecyclePanelSafe(
      ctx,
      activeJob,
      buildPausedCheckSendConfirmationCard({
        remaining: activeJob.pauseManifest?.pendingCount || 0,
      }),
      pausedCheckConfirmationKeyboard(),
      { fallbackPanel: ctx.callbackQuery?.message || null },
    );
  }

  if (resumeStatus === "already_requested") {
    return replySafe(
      ctx,
      boxPanel("PENGECEKAN DILANJUTKAN", [
        `${ACCENTS.status} Permintaan lanjut sudah diterima.`,
      ]),
    );
  }

  if (resumeStatus === "not_connected") {
    armPausedReconnectResume(activeJob, ctx);
    return { status: "waiting_for_ready" };
  }

  return continuePausedCheck(activeJob, ctx);
}

// Fungsi getOwnerStatsText: membuat ringkasan statistik penuh untuk owner.
function getOwnerStatsText() {
  const summary = stats.getSummary();
  return boxPanel("STATISTIK BOT", [
    `👥 User        : ${formatStatNumber(summary.totalUsers)}`,
    `🔎 Nomor dicek : ${formatStatNumber(summary.totalNumbersChecked)}`,
    `✅ Sukses      : ${formatStatNumber(summary.successfulChecks)}`,
    `📈 Rasio       : ${formatSuccessRatio(summary.successRatio)}%`,
  ]);
}

async function replyOwnerStats(ctx) {
  return renderTextPanel(ctx, getOwnerStatsText(), mainKeyboard(ctx.from.id));
}
// Fungsi replyWaSourceMenu: menjalankan bagian reply wa source menu pada bot.
async function replyWaSourceMenu(ctx, notice = "") {
  const userId = ctx.from.id;
  const text = buildSenderManagerCard({
    senders: getSenderUiList(userId),
    notice,
  });
  return renderCleanTextPanel(ctx, text, waMenuKeyboard(userId));
}
// Fungsi replyWhatsAppStatus: menjalankan bagian reply whats app status pada bot.
async function replyWhatsAppStatus(ctx) {
  const userId = ctx.from.id;
  try {
    return replyWaSourceMenu(ctx);
  } catch (error) {
    return renderCleanTextPanel(
      ctx,
      buildFriendlyIssueCard(
        "STATUS BELUM TERBACA",
        "Panel koneksi belum bisa diperbarui dengan mulus.",
        "Buka menu koneksi sekali lagi.",
      ),
      waMenuKeyboard(userId),
    );
  }
}

async function replyDisconnectSenderMenu(ctx) {
  const userId = ctx.from.id;
  const senders = getSenderUiList(userId);
  if (!senders.length) return replyWaSourceMenu(ctx);
  return renderCleanTextPanel(
    ctx,
    buildSenderDisconnectMenuCard(),
    disconnectSenderKeyboard(userId),
  );
}
// Fungsi pairMethodKeyboard: keyboard pilih metode pairing.
function pairMethodKeyboard() {
  return keyboardPresentation.pairMethodKeyboard({ callbacks: CALLBACKS });
}
// Fungsi promptPairing: tampilkan PILIHAN metode (Pairing Code / QR).
async function promptPairing(ctx) {
  const userId = ctx.from.id;
  clearUserState(userId);
  return renderCleanTextPanel(ctx, buildPairMethodCard(), pairMethodKeyboard());
}
// Fungsi promptPairingCode: alur pairing pakai KODE (minta nomor dulu).
async function promptPairingCode(ctx) {
  const userId = ctx.from.id;
  try {
    const promptPanel = await renderCleanTextPanel(
      ctx,
      buildWaPairingPanel(ctx),
      cancelStateKeyboard(),
      { parse_mode: "HTML" },
    );
    setUserState(
      userId,
      createAwaitPairingState(getTelegramPanelMetaFromResult(ctx, promptPanel)),
    );
    return promptPanel;
  } catch (error) {
    clearUserState(userId);
    return renderCleanTextPanel(
      ctx,
      buildFriendlyIssueCard(
        "PAIRING BELUM TERBUKA",
        "Panel pairing belum bisa dibuka dengan mulus.",
        "Kembali ke menu koneksi lalu ulangi sekali lagi.",
      ),
      waMenuKeyboard(userId),
    );
  }
}
// ==== QR PAIRING ENGINE ====
// Melacak pesan foto QR per user agar bisa di-update saat QR berganti.
const qrPanels = new Map(); // userId -> { chatId, messageId }

function createSenderSessionId() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

// Fungsi renderQrBuffer: ubah string QR jadi PNG buffer.
async function renderQrBuffer(qr) {
  return QRCode.toBuffer(qr, {
    type: "png",
    width: 320,
    margin: 2,
    errorCorrectionLevel: "M",
  });
}

// Notifier dipanggil session manager tiap ada QR baru untuk user.
setQrNotifier(async (userId, qr, senderId = "default") => {
  const panelKey = Number(userId);
  if (!Number.isInteger(panelKey) || panelKey <= 0) return;
  try {
    const buffer = await renderQrBuffer(qr);
    const existing = qrPanels.get(panelKey);
    const chatId = Number(existing?.chatId ?? userId);
    if (!Number.isSafeInteger(chatId) || chatId === 0) return;
    if (existing?.senderId && existing.senderId !== senderId) return;
    if (existing && !existing.senderId) existing.senderId = senderId;
    const caption = buildQrCaption(existing?.sessionId);
    if (existing?.messageId) {
      // Update foto QR yang sudah ada (QR berganti tiap ~20 detik).
      try {
        await bot.telegram.editMessageMedia(
          chatId,
          existing.messageId,
          undefined,
          {
            type: "photo",
            media: { source: buffer },
            caption,
            parse_mode: "HTML",
          },
          cancelStateKeyboard(),
        );
        return;
      } catch (error) {
        // Kalau gagal edit (mis. pesan hilang), kirim ulang di bawah.
        logIgnoredError("INDEX", "QR_EDIT_IGNORED", error);
        qrPanels.delete(panelKey);
      }
    }
    const sent = await bot.telegram
      .sendPhoto(chatId, { source: buffer }, {
        caption,
        parse_mode: "HTML",
        ...cancelStateKeyboard(),
      })
      .catch((error) => {
        logIgnoredError("INDEX", "QR_SEND_IGNORED", error);
        return null;
      });
    if (sent?.message_id) {
      rememberGroupPanelOwner(userId, sent.chat?.id ?? chatId, sent.message_id);
      const prev = qrPanels.get(panelKey) || { chatId };
      // QR sudah tampil — hapus kartu "nyiapin QR" karena tugasnya selesai.
      if (prev.waitMessageId) {
        bot.telegram
          .deleteMessage(chatId, prev.waitMessageId)
          .catch((error) => logIgnoredError("INDEX", "QR_WAIT_REMOVE_IGNORED", error));
      }
      qrPanels.set(panelKey, {
        ...prev,
        chatId,
        messageId: sent.message_id,
        waitMessageId: null,
      });
    }
  } catch (error) {
    logIgnoredError("INDEX", "QR_RENDER_IGNORED", error);
  }
});

// Bersihkan panel QR saat sesi sudah tersambung (QR tak perlu lagi).
// Fungsi cancelQrFlow: membatalkan pairing QR — hapus foto QR + kartu nyiapin,
// dan hentikan sesi WA QR yang sedang berjalan agar tidak lanjut di background.
async function cancelQrFlow(userId, state = null) {
  const tracked = qrPanels.get(Number(userId));
  const senderId = state?.senderId || tracked?.senderId || "default";
  clearActivePairingPanel(userId);
  clearQrPanel(userId);
  try {
    await cancelSenderPairing(userId, senderId);
  } catch (error) {
    logIgnoredError("INDEX", "QR_CANCEL_RESET_IGNORED", error, { senderId });
  }
}

function clearQrPanel(userId) {
  const panelKey = Number(userId);
  const existing = qrPanels.get(panelKey);
  const chatId = Number(existing?.chatId ?? userId);
  if (existing?.messageId && Number.isSafeInteger(chatId) && chatId !== 0) {
    bot.telegram
      .deleteMessage(chatId, existing.messageId)
      .catch((error) => logIgnoredError("INDEX", "QR_CLEANUP_IGNORED", error));
  }
  if (existing?.waitMessageId && Number.isSafeInteger(chatId) && chatId !== 0) {
    bot.telegram
      .deleteMessage(chatId, existing.waitMessageId)
      .catch((error) => logIgnoredError("INDEX", "QR_WAIT_CLEANUP_IGNORED", error));
  }
  qrPanels.delete(panelKey);
}

// Fungsi startQrFlow: mulai pairing lewat QR.
async function startQrFlow(ctx) {
  const userId = ctx.from.id;
  clearUserState(userId);
  qrPanels.delete(Number(userId));
  const sessionId = createSenderSessionId();

  // Tidak ada bubble "menyiapkan QR". Bersihkan menu metode dan tampilkan
  // indikator typing sampai notifier menerima QR dari Baileys.
  await sendPolishAction(ctx, "typing");
  if (ctx.callbackQuery?.message?.message_id) {
    await ctx.deleteMessage().catch((error) =>
      logIgnoredError("INDEX", "QR_METHOD_PANEL_DELETE_IGNORED", error),
    );
  }
  qrPanels.set(Number(userId), {
    chatId: Number(ctx.chat?.id),
    messageId: null,
    waitMessageId: null,
    sessionId,
    senderId: null,
  });

  setUserState(userId, {
    type: "await_qr_pairing",
    sessionId,
    senderId: null,
    chatId: Number(ctx.chat?.id),
  });
  let senderId = "default";
  const bindAllocatedQrSender = (allocatedSenderId) => {
    senderId = String(allocatedSenderId || "default");
    const tracked = qrPanels.get(Number(userId));
    if (tracked) tracked.senderId = senderId;
    setUserState(userId, {
      type: "await_qr_pairing",
      sessionId,
      senderId,
      chatId: Number(ctx.chat?.id),
    });
  };
  try {
    const result = await startNewQrPairingSession(userId, {
      onSenderAllocated: bindAllocatedQrSender,
    });
    bindAllocatedQrSender(result?.senderId || senderId || "default");
  } catch (error) {
    clearUserState(userId);
    qrPanels.delete(Number(userId));
    logIgnoredError("INDEX", "QR_START_IGNORED", error);
    return replySafe(
      ctx,
      buildFriendlyIssueCard(
        "QR BELUM BISA DIBUKA",
        "QR belum bisa disiapkan dengan mulus.",
        "Coba lagi sebentar atau pakai Pairing Code.",
      ),
      waMenuKeyboard(userId),
    );
  }
  // QR dikirim otomatis oleh notifier saat event qr datang.
  watchQrUntilConnected(userId, senderId).catch((error) =>
    logIgnoredError("INDEX", "QR_WATCH_IGNORED", error),
  );
  return null;
}

// Fungsi watchQrUntilConnected: pantau sampai QR discan & sesi tersambung.
async function watchQrUntilConnected(userId, senderId = "default") {
  const connected = await ensureSenderConnectedSession(userId, senderId, 120000);
  if (!connected) return;
  const tracked = qrPanels.get(Number(userId));
  const state = getUserState(userId);
  const chatId = Number(tracked?.chatId ?? state?.chatId ?? userId);
  clearUserState(userId);
  clearQrPanel(userId);
  if (isSenderReady(userId, senderId)) return;
  if (!Number.isSafeInteger(chatId) || chatId === 0) return;
  const snapshot = getSenderUiSnapshot(userId, senderId);
  const connectedPanel = await sendMessageSafe(
    chatId,
    buildSenderConnectedNotice({
      number: snapshot.number,
      activeCount: getConnectedSenderUiList(userId).length,
    }),
    { reply_markup: connectedSenderKeyboard().reply_markup },
    { maxAttempts: 3, timeoutMs: 30000 },
  );
  if (connectedPanel?.message_id) {
    rememberGroupPanelOwner(userId, connectedPanel.chat?.id ?? chatId, connectedPanel.message_id);
  }
  markSenderReady(userId, senderId, {
    source: "qr_connected_card",
    messageId: connectedPanel?.message_id || null,
  });
}

// Fungsi handlePairingText: menjalankan bagian handle pairing text pada bot.
async function handlePairingText(ctx, rawInput) {
  const userId = ctx.from.id;
  const pairingState = getUserState(userId);
  await deletePairingPromptMessage(ctx.telegram || bot.telegram, pairingState, {
    onIgnored: (error) =>
      logIgnoredError("INDEX", "PAIRING_PROMPT_DELETE_IGNORED", error),
  });

  const num = normalizeInputNumber(rawInput);
  if (!num) {
    const issuePanel = await renderTextPanel(
      ctx,
      buildFriendlyIssueCard(
        "NOMOR BELUM COCOK",
        "Format nomor belum bisa dibaca sebagai nomor internasional.",
        "Kirim seperti 628123456789 atau +628123456789.",
      ),
      cancelStateKeyboard(),
    );
    setUserState(
      userId,
      createAwaitPairingState(getTelegramPanelMetaFromResult(ctx, issuePanel)),
    );
    return issuePanel;
  }

  clearUserState(userId);
  await sendPolishAction(ctx, "typing");
  // Tidak membuat bubble progress. panelMeta hanya membawa chatId agar hasil
  // Pairing Code langsung dikirim ketika kode sudah siap.
  const panelMeta = { chatId: ctx.chat?.id, messageId: null };
  if (
    !startWaConnectJob(userId, "pair", () =>
      finishPairingCodeFlow(userId, num, panelMeta),
    )
  ) {
    return editOrSendTextPanelByMeta(
      panelMeta,
      warningPanel("PAIRING MASIH BERJALAN", [
        `${ACCENTS.warning} Permintaan pairing sebelumnya masih aktif.`,
        `${ACCENTS.low} Tunggu kode pairing yang sedang disiapkan.`,
      ]),
      waMenuKeyboard(userId),
    );
  }
  return null;
}

// Fungsi reloadWhatsAppSession: menjalankan bagian reload whats app session pada bot.
async function reloadWhatsAppSession(ctx, options = {}) {
  const userId = ctx.from.id;
  const senderBeforeReset = getSenderUiSnapshot(userId);
  clearUserState(userId);
  clearActivePairingPanel(userId);

  // Hapus Sender tidak perlu animasi progress palsu. Telegram cukup
  // menampilkan indikator typing, lalu panel Senderku diperbarui saat selesai.
  const panelMeta = await beginSenderDisconnectProgress(ctx);

  try {
    const resetSource = String(options.source || "button_disconnect");
    const resetFn = forceResetWA;
    const result = await resetFn(userId, { source: resetSource });
    const connected = result.autoRestarted
      ? await ensureUserWAConnected(userId, 4000)
      : false;

    if (result?.authDeleted && !connected) {
      const text = buildSenderManagerCard({
        senders: getSenderUiList(userId),
        notice: buildSenderDisconnectedNotice(senderBeforeReset.number),
      });
      return (
        (await editOrSendTextPanelByMeta(panelMeta, text, waMenuKeyboard(userId)).catch(
          (err) => {
            logIgnoredError("INDEX", "PROMISE_IGNORED", err);
            return null;
          },
        )) || renderTextPanel(ctx, text, waMenuKeyboard(userId))
      );
    }

    const text = getReloadResultText(result, connected);
    return (
      (await editOrSendTextPanelByMeta(panelMeta, text, waMenuKeyboard(userId)).catch(
        (err) => {
          logIgnoredError("INDEX", "PROMISE_IGNORED", err);
          return null;
        },
      )) || renderTextPanel(ctx, text, waMenuKeyboard(userId))
    );
  } catch (error) {
    const text = buildFriendlyIssueCard(
      "SESI BELUM RAPI",
      "Koneksi belum bisa ditata ulang dengan mulus.",
      "Buka menu koneksi lalu ulangi sekali lagi.",
    );
    return (
      (await editOrSendTextPanelByMeta(panelMeta, text, waMenuKeyboard(userId)).catch(
        (err) => {
          logIgnoredError("INDEX", "PROMISE_IGNORED", err);
          return null;
        },
      )) || renderTextPanel(ctx, text, waMenuKeyboard(userId))
    );
  }
}

async function beginSenderDisconnectProgress(ctx) {
  await sendPolishAction(ctx, "typing");
  const message = ctx.callbackQuery?.message;
  if (message?.chat?.id && message?.message_id) {
    return {
      chatId: message.chat.id,
      messageId: message.message_id,
      text: message.text ?? message.caption ?? "",
      replyMarkup: message.reply_markup ?? null,
    };
  }
  return ctx.chat?.id ? { chatId: ctx.chat.id, messageId: null } : null;
}

async function renderSenderManagerAfterDisconnect(ctx, panelMeta, notice = "") {
  const userId = ctx.from.id;
  const text = buildSenderManagerCard({
    senders: getSenderUiList(userId),
    notice,
  });
  return (
    (await editOrSendTextPanelByMeta(panelMeta, text, waMenuKeyboard(userId)).catch(
      (err) => {
        logIgnoredError("INDEX", "PROMISE_IGNORED", err);
        return null;
      },
    )) || renderTextPanel(ctx, text, waMenuKeyboard(userId))
  );
}

// Menghapus sender yang dipilih saja. senderId berasal dari callback keyboard
// Senderku dan diteruskan sampai session manager, sehingga default maupun
// sender tambahan tidak lagi saling ikut terhapus.
async function disconnectSenderById(ctx, senderId) {
  const userId = ctx.from.id;
  const senderBeforeReset = getSenderUiList(userId).find(
    (sender) => String(sender?.senderId || "default") === String(senderId || "default"),
  );
  if (!senderBeforeReset) return replyWaSourceMenu(ctx);

  clearUserState(userId);
  clearActivePairingPanel(userId);
  const panelMeta = await beginSenderDisconnectProgress(ctx);

  try {
    const result = await disconnectSenderSession(userId, senderBeforeReset.senderId, {
      source: "sender_disconnect_selected",
    });
    if (!result?.authDeleted) {
      return renderSenderManagerAfterDisconnect(
        ctx,
        panelMeta,
        "• Sender belum bisa diputuskan. Coba ulangi sekali lagi.",
      );
    }
    return renderSenderManagerAfterDisconnect(
      ctx,
      panelMeta,
      buildSenderDisconnectedNotice(senderBeforeReset.number),
    );
  } catch (error) {
    logApp("ERROR", ctx, "SENDER", "DISCONNECT_ONE_FAIL", "gagal menghapus sender terpilih", {
      senderId: senderBeforeReset.senderId,
      error: error?.message || String(error),
    });
    return renderSenderManagerAfterDisconnect(
      ctx,
      panelMeta,
      "• Sender belum bisa diputuskan. Sender lain tetap dibiarkan berjalan.",
    );
  }
}

// Callback lama dipertahankan untuk kompatibilitas panel yang mungkin masih
// tersimpan di Telegram. Ia memilih sender pertama dari daftar saat ini.
async function disconnectCurrentSender(ctx) {
  const sender = getSenderUiList(ctx.from.id)[0];
  if (!sender) return replyWaSourceMenu(ctx);
  return disconnectSenderById(ctx, sender.senderId || "default");
}

async function disconnectAllSenders(ctx) {
  const userId = ctx.from.id;
  const before = getSenderUiList(userId);
  if (!before.length) return replyWaSourceMenu(ctx);

  clearUserState(userId);
  clearActivePairingPanel(userId);
  const panelMeta = await beginSenderDisconnectProgress(ctx);

  try {
    const result = await disconnectAllSenderSessions(userId, {
      source: "sender_disconnect_all",
    });
    const notice = result.failed > 0
      ? `• ${result.deleted}/${result.total} Sender berhasil diputuskan. ${result.failed} gagal dibersihkan.`
      : buildAllSendersDisconnectedNotice(result.deleted);
    return renderSenderManagerAfterDisconnect(ctx, panelMeta, notice);
  } catch (error) {
    logApp("ERROR", ctx, "SENDER", "DISCONNECT_ALL_FAIL", "gagal menghapus semua sender", {
      error: error?.message || String(error),
    });
    return renderSenderManagerAfterDisconnect(
      ctx,
      panelMeta,
      "• Sebagian Sender belum bisa dibersihkan. Sender yang masih tersimpan ditampilkan di bawah.",
    );
  }
}

// Controller wiring dipisahkan dari bootstrap dan logika service.
async function answerCallback(ctx) {
  return ctx.answerCbQuery().catch((error) =>
    logIgnoredError("CONTROLLER", "CALLBACK_IGNORED", error),
  );
}

registerStartController({
  bot,
  isGroupChat,
  isKnownTelegramUser,
  replyUserUnknownInGroup,
  rememberUser,
  clearActivePairingPanel,
  clearUserState,
  replyGroupRecognizedStart,
  replyMainMenuCard,
});

registerCheckBioController({
  bot,
  callbacks: CALLBACKS,
  answerCallback,
  abortActiveCheck,
  requestPausedCheckResultsConfirmation,
  confirmPausedCheckResults,
  cancelPausedCheckResultsConfirmation,
  resumePausedCheck,
  isGroupChat,
  isKnownTelegramUser,
  replyUserUnknownInGroup,
  rememberUser,
  extractCommandPayload,
  promptCheckBio,
  clearUserState,
  handleCheckBioText,
  replySafe,
  getCheckBioTxtUsageText,
  handleCheckBioDocument,
  isCekbioTxtCaption,
});

registerWhatsAppController({
  bot,
  callbacks: CALLBACKS,
  answerCallback,
  rememberUser,
  isGroupChat,
  replyWaSourceMenu,
  replyDisconnectSenderMenu,
  promptPairing,
  promptPairingCode,
  startQrFlow,
  replyWhatsAppStatus,
  reloadWhatsAppSession,
  disconnectCurrentSender,
  disconnectSenderById,
  disconnectAllSenders,
});

// Handler pilihan format hasil cek (Simple / Detail).
async function handleFormatChoice(ctx, format) {
  await answerCallback(ctx);
  rememberUser(ctx);
  const userId = ctx.from.id;
  // Hapus kartu pilihan format begitu user memilih, biar tidak menumpuk.
  await ctx.deleteMessage().catch((error) =>
    logIgnoredError("INDEX", "FORMAT_CARD_DELETE_IGNORED", error),
  );
  const state = getUserState(userId);
  if (!state || state.type !== "await_format_choice") {
    // State hilang (mis. bot restart) — minta ulangi.
    return renderTextPanel(
      ctx,
      buildFriendlyIssueCard(
        "SESI FORMAT HABIS",
        "Pilihan format sudah kedaluwarsa.",
        "Kirim ulang /cekbio atau /cekbiotxt ya.",
      ),
      contextMainKeyboard(ctx, userId),
    );
  }
  const speedPerSender = normalizeCheckSpeed(state.speed);
  clearUserState(userId);

  if (state.source === "cekbio") {
    const nums = state.numbers || [];
    return runCheckInBackground(ctx, "cekbio", userId, ({ signal, job }) =>
      runCheckBioFromNumbers(ctx, nums, {
        signal,
        job,
        format,
        speedPerSender,
      }),
    );
  }
  if (state.source === "cekbiotxt") {
    const doc = state.document;
    return runCheckInBackground(ctx, "cekbiotxt", userId, async ({ signal, job }) =>
      runCheckBioDocumentWithFormat(ctx, doc, {
        signal,
        job,
        format,
        speedPerSender,
      }),
    );
  }
  return null;
}

function getFormatChoiceStateMeta(state) {
  const isTxt = state?.source === "cekbiotxt";
  return {
    total: isTxt ? null : (state?.numbers || []).length,
    fileName: isTxt
      ? describeTelegramTextFile(state?.document?.file_name).safeFileName
      : "",
  };
}

function renderFormatChoiceFromState(ctx, state) {
  const { total, fileName } = getFormatChoiceStateMeta(state);
  const selectedSpeed = normalizeCheckSpeed(state?.speed);
  return renderCleanTextPanel(
    ctx,
    buildFormatChoiceCard(total, {
      source: state.source,
      fileName,
      speed: selectedSpeed,
    }),
    keyboardPresentation.formatChoiceKeyboard({
      callbacks: CALLBACKS,
      speed: selectedSpeed,
    }),
  );
}

async function handleCheckSpeedMenu(ctx) {
  await answerCallback(ctx);
  rememberUser(ctx);
  const userId = ctx.from.id;
  const state = getUserState(userId);
  if (!state || state.type !== "await_format_choice") {
    return renderTextPanel(
      ctx,
      buildFriendlyIssueCard(
        "SESI FORMAT HABIS",
        "Pengaturan kecepatan sudah kedaluwarsa.",
        "Kirim ulang /cekbio atau /cekbiotxt ya.",
      ),
      contextMainKeyboard(ctx, userId),
    );
  }

  const selectedSpeed = normalizeCheckSpeed(state.speed);
  return renderCleanTextPanel(
    ctx,
    buildCheckSpeedChoiceCard(selectedSpeed),
    keyboardPresentation.checkSpeedKeyboard({
      callbacks: CALLBACKS,
      speed: selectedSpeed,
      speedOptions: CHECK_SPEED_OPTIONS,
    }),
  );
}

async function handleCheckSpeedBack(ctx) {
  await answerCallback(ctx);
  rememberUser(ctx);
  const userId = ctx.from.id;
  const state = getUserState(userId);
  if (!state || state.type !== "await_format_choice") {
    return renderTextPanel(
      ctx,
      buildFriendlyIssueCard(
        "SESI FORMAT HABIS",
        "Pilihan format sudah kedaluwarsa.",
        "Kirim ulang /cekbio atau /cekbiotxt ya.",
      ),
      contextMainKeyboard(ctx, userId),
    );
  }
  return renderFormatChoiceFromState(ctx, state);
}

async function handleCheckSpeedChoice(ctx, speedValue) {
  await answerCallback(ctx);
  rememberUser(ctx);
  const userId = ctx.from.id;
  const state = getUserState(userId);
  if (!state || state.type !== "await_format_choice") {
    return renderTextPanel(
      ctx,
      buildFriendlyIssueCard(
        "SESI FORMAT HABIS",
        "Pilihan kecepatan sudah kedaluwarsa.",
        "Kirim ulang /cekbio atau /cekbiotxt ya.",
      ),
      contextMainKeyboard(ctx, userId),
    );
  }

  const selectedSpeed = normalizeCheckSpeed(speedValue, NaN);
  if (!CHECK_SPEED_OPTIONS.includes(selectedSpeed)) return null;

  // Simpan sebagai default permanen user. Nilai ini dipakai oleh /cekbio dan
  // /cekbiotxt berikutnya sampai user memilih kecepatan lain.
  await userPreferences.setCheckSpeed(userId, selectedSpeed);
  const nextState = { ...state, speed: selectedSpeed };
  setUserState(userId, nextState);
  return renderFormatChoiceFromState(ctx, nextState);
}

bot.command("saldo", async (ctx) => replyBalance(ctx));
bot.command("topup", async (ctx) => topup(ctx, String(ctx.message?.text || "").replace(/^\/topup(?:@\w+)?/i, "").trim()));
bot.command("paket", async (ctx) => { const packages=await pricing.getPackages(); return ctx.reply(`💳 <b>PAKET TOKEN</b>\n\n${html(packages.map((p,i)=>`${i+1}. ${money(p.tokens)} token — Rp${money(p.price)}`).join("\n"))}`, {parse_mode:"HTML", ...packageKeyboard(packages)}); });
bot.command("emoji", handleEmojiCommand);
bot.command("listemoji", handleListEmojiCommand);

bot.action(CALLBACKS.CHECK_SPEED_MENU, handleCheckSpeedMenu);
bot.action(CALLBACKS.CHECK_SPEED_BACK, handleCheckSpeedBack);
bot.action(
  new RegExp(`^${CALLBACKS.CHECK_SPEED_PREFIX}(\\d+)$`),
  (ctx) => handleCheckSpeedChoice(ctx, ctx.match?.[1]),
);
bot.action(CALLBACKS.FORMAT_SIMPLE, (ctx) => handleFormatChoice(ctx, "simple"));
bot.action(CALLBACKS.FORMAT_DETAIL, (ctx) => handleFormatChoice(ctx, "detail"));

bot.action(CALLBACKS.BALANCE, async (ctx) => { await ctx.answerCbQuery(); return replyBalance(ctx); });
bot.action(CALLBACKS.TOPUP, async (ctx) => { await ctx.answerCbQuery(); const packages=await pricing.getPackages(); return ctx.reply(`💳 <b>PAKET TOKEN</b>\n\n${html(packages.map((p,i)=>`${i+1}. ${money(p.tokens)} token — Rp${money(p.price)}`).join("\n"))}`, {parse_mode:"HTML", ...packageKeyboard(packages)}); });
bot.action(CALLBACKS.HISTORY, async (ctx) => { await ctx.answerCbQuery(); const rows=await wallet.listUserQrisTransactions(ctx.from.id,10); const text=rows.length?rows.map((t,i)=>`${i+1}. ${t.status==='success'?'✅':'⏳'} <code>${html(t.transactionId||'-')}</code> · Rp${money(t.amountPaid||t.amount||0)} · ${tokenFmt(t.tokensCredited||t.tokensExpected||0)} token`).join("\n"):"Belum ada transaksi."; return ctx.reply(`🧾 <b>RIWAYAT TOPUP</b>\n\n${text}`,{parse_mode:"HTML"}); });
bot.action(/^BUY_(\d+)$/, async (ctx) => { await ctx.answerCbQuery(); return topup(ctx, ctx.match[1]); });

registerOwnerController({
  bot,
  callbacks: CALLBACKS,
  isOwner,
  isGroupChat,
  rememberUser,
  promptBroadcast,
  replyOwnerStats,
  answerCallback,
  replySafe,
  buildFriendlyIssueCard,
  isMaintenanceMode,
  setMaintenanceMode,
  runMaintenanceDisabledNotification,
  renderTextPanel,
  buildMaintenancePanel,
  menuOnlyKeyboard,
});

registerCallbackController({
  bot,
  callbacks: CALLBACKS,
  answerCallback,
  isGroupChat,
  isKnownTelegramUser,
  replyUserUnknownInGroup,
  rememberUser,
  getForceJoinStatus,
  replyMainMenuCard,
  showForceJoinGate,
  renderTextPanel,
  getForceJoinVerifiedText,
  emptyKeyboard: keyboardPresentation.emptyKeyboard,
  replyGroupRecognizedStart,
  showMainMenu,
  getUserState,
  clearUserState,
  replyWaSourceMenu,
  buildSenderPairingCancelledCard,
  cancelQrFlow,
});

registerHelpController({
  bot,
  isGroupChat,
  isKnownTelegramUser,
  replyUserUnknownInGroup,
  rememberUser,
  replyHelp,
});

registerTextController({
  bot,
  isGroupChat,
  getUserState,
  rememberUser,
  handleBroadcastText,
  extractSlashCommandInfo,
  handlePairingText,
});

bot.catch((err, ctx) => {
  if (isTelegramMessageNotModifiedError(err)) {
    logApp(
      "WARN",
      ctx || "-",
      "TELEGRAF",
      "IGNORED",
      "edit pesan diabaikan karena isi pesan sama",
      { error: getTelegramErrorMessage(err) },
    );
    return;
  }
  if (isTelegramBlockedByUserError(err)) {
    logApp(
      "WARN",
      ctx || "-",
      "TELEGRAM",
      "USER_BLOCKED",
      "update diabaikan karena user memblokir bot",
      { error: getTelegramErrorMessage(err) },
    );
    return;
  }
  if (isRetryableTelegramError(err)) {
    logApp(
      "WARN",
      ctx || "-",
      "TELEGRAM",
      "TRANSIENT_NETWORK",
      "gangguan koneksi Telegram diabaikan setelah retry",
      { error: getTelegramErrorMessage(err) },
    );
    return;
  }
  logApp(
    "ERROR",
    ctx || "-",
    "TELEGRAF",
    "CATCH",
    "telegraf error tertangkap",
    { error: err?.message },
  );
  console.error("TELEGRAF ERROR:", err);
});
process.on("unhandledRejection", (reason) => {
  if (isIgnorableTelegramError(reason)) {
    logApp(
      "WARN",
      "SYSTEM",
      "PROCESS",
      "IGNORED_REJECTION",
      "telegram error ringan diabaikan",
      { error: getTelegramErrorMessage(reason) },
    );
    return;
  }
  if (isTelegramConflictError(reason)) {
    console.error(
      "[ERROR][SYSTEM][TELEGRAM_CONFLICT] polling Telegram bentrok. Pastikan hanya satu instance bot yang berjalan.",
    );
    shutdownBot("TELEGRAM_CONFLICT", 1);
    return;
  }
  console.error("[ERROR][PROCESS][UNHANDLED_REJECTION]", reason);
});
process.on("uncaughtException", (err) => {
  if (isIgnorableTelegramError(err)) {
    logApp(
      "WARN",
      "SYSTEM",
      "PROCESS",
      "IGNORED_EXCEPTION",
      "telegram error ringan diabaikan",
      { error: getTelegramErrorMessage(err) },
    );
    return;
  }
  if (isTelegramConflictError(err)) {
    console.error(
      "[ERROR][SYSTEM][TELEGRAM_CONFLICT] polling Telegram bentrok. Pastikan hanya satu instance bot yang berjalan.",
    );
    shutdownBot("TELEGRAM_CONFLICT", 1);
    return;
  }
  console.error("[ERROR][PROCESS][UNCAUGHT_EXCEPTION]", err);
});
process.once("SIGINT", () => shutdownBot("SIGINT", 0));
process.once("SIGTERM", () => shutdownBot("SIGTERM", 0));

async function startBot() {
  try {
    const tempDir = await ensureTempDirWritable(config.TEMP_DIR);
    console.log(`[INFO][SYSTEM][TEMP_DIR][READY] ${tempDir}`);
  } catch (error) {
    console.error(
      `[FATAL][SYSTEM][TEMP_DIR] ${error?.message || error}`,
    );
    throw error;
  }
  await Promise.all([
    stats.initializeStats(),
    userPreferences.initializeUserPreferences(),
    emojiMappings.initializeEmojiMappings(),
    loadRuntimeState(),
  ]);
  for (const userId of stats.getUserIds()) knownUsers.add(userId);
  console.log(
    "\x1b[36m╔════════════════════════════════════════════════════════════════════╗",
  );
  console.log(
    "\x1b[35m║ \x1b[1;36m ██████╗███████╗██╗  ██╗██████╗ ██╗ ██████╗     ███╗   ███╗ ██████╗ \x1b[35m║",
  );
  console.log(
    "\x1b[35m║ \x1b[1;36m██╔════╝██╔════╝██║ ██╔╝██╔══██╗██║██╔═══██╗    ████╗ ████║██╔════╝ \x1b[35m║",
  );
  console.log(
    "\x1b[35m║ \x1b[1;36m██║     █████╗  █████╔╝ ██████╔╝██║██║   ██║    ██╔████╔██║██║      \x1b[35m║",
  );
  console.log(
    "\x1b[35m║ \x1b[1;36m██║     ██╔══╝  ██╔═██╗ ██╔══██╗██║██║   ██║    ██║╚██╔╝██║██║      \x1b[35m║",
  );
  console.log(
    "\x1b[35m║ \x1b[1;36m╚██████╗███████╗██║  ██╗██████╔╝██║╚██████╔╝    ██║ ╚═╝ ██║╚██████╗ \x1b[35m║",
  );
  console.log(
    "\x1b[35m║ \x1b[1;36m ╚═════╝╚══════╝╚═╝  ╚═╝╚═════╝ ╚═╝ ╚═════╝     ╚═╝     ╚═╝ ╚═════╝ \x1b[35m║",
  );
  console.log(
    "\x1b[33m╠══════════════════════ \x1b[1;31m[ CEKBIO BY MOCI ] \x1b[33m══════════════════════╣",
  );
  console.log(
    "\x1b[32m║ \x1b[1;36m⚡ WhatsApp Business Checker  │  Force Join Gate  │  Stable Checkflow \x1b[32m║",
  );
  console.log(
    "\x1b[32m║ \x1b[1;35m📁 TXT Batch Support  │  🔌 Auto Reconnect  │  👑 Owner Menu      \x1b[32m║",
  );
  console.log(
    "\x1b[36m╚════════════════════════════════════════════════════════════════════╝\x1b[0m",
  );
  try {
    await registerTelegramCommands();
  } catch (err) {
    console.error(
      "[ERROR][SYSTEM][COMMANDS] gagal register telegram commands",
      err,
    );
  }
  // Resolve force join targets lebih awal supaya tombol menampilkan nama grup/channel dari ID.
  if (RAW_FORCE_JOIN_TARGETS.length > 0) {
    try {
      await resolveForceJoinTargets();
    } catch (err) {
      console.warn("[WARN][FORCE_JOIN] gagal resolve targets:", err.message);
    }
  }

  // FIX: hapus webhook & drop pending updates sebelum launch
  // untuk mencegah TELEGRAM_CONFLICT jika sesi polling sebelumnya belum bersih
  try {
    await bot.telegram.deleteWebhook({ drop_pending_updates: true });
    console.log(
      "[INFO][SYSTEM][BOT][LAUNCH] webhook dihapus, memulai polling...",
    );
  } catch (err) {
    console.warn(
      "[WARN][SYSTEM][BOT][LAUNCH] gagal hapus webhook (diabaikan):",
      err.message,
    );
  }
  // Ambil username bot untuk footer laporan SEBELUM launch (via getMe, dijamin ada).
  if (!process.env.BOT_USERNAME) {
    try {
      const me = await bot.telegram.getMe();
      if (me?.username) {
        process.env.BOT_USERNAME = `@${me.username}`;
        if (!bot.botInfo) bot.botInfo = me;
      }
    } catch (meErr) {
      console.warn(
        "[WARN][SYSTEM][BOT][GETME] gagal ambil username bot (footer pakai fallback):",
        meErr.message,
      );
    }
  }
  startQrisWebhookServer();
  if (qris) setInterval(() => pollQrisPayments().catch((e) => console.warn("[QRIS] polling error:", e.message)), 20000).unref?.();
  try {
    await bot.launch();
  } catch (err) {
    if (isTelegramConflictError(err)) {
      console.error(
        "[ERROR][SYSTEM][TELEGRAM_CONFLICT] gagal start polling karena ada instance bot lain yang aktif.",
      );
      await shutdownBot("TELEGRAM_CONFLICT", 1);
      return;
    }
    console.error("[ERROR][SYSTEM][BOT][LAUNCH_FAIL]", err);
    throw err;
  }
  console.log(
    "[INFO][SYSTEM][BOT][READY] bot berhasil dijalankan\n✅ Bot berjalan",
  );
}

module.exports = { startBot, bot };
