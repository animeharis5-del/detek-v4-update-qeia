function createCheckJobQueue({ timeoutMs }) {
  // Tahap 8: queue ini sengaja TIDAK memiliki batas global jumlah user/job.
  // Eksklusivitas hanya berlaku per key (satu user/sesi tidak menumpuk dua
  // pengecekan sekaligus), sedangkan key milik user lain boleh aktif paralel.
  // Resource tetap dibatasi di level worker/Sender, bukan lewat kuota 5 user.
  const activeJobs = new Map();

  function get(key) {
    return activeJobs.get(String(key)) || null;
  }

  function getActiveCount() {
    return activeJobs.size;
  }

  function getActiveJobs() {
    return Array.from(activeJobs.values());
  }

  function start(key, metadata, runner) {
    const normalizedKey = String(key);
    const existing = activeJobs.get(normalizedKey);
    if (existing) return { accepted: false, activeJob: existing };

    const controller = new AbortController();
    const job = {
      ...metadata,
      key: normalizedKey,
      id: metadata?.id || `${normalizedKey}:${Date.now()}`,
      startedAt: Date.now(),
      controller,
      status: "running",
      timeoutPaused: false,
      timeoutHandle: null,
    };

    const clearJobTimeout = () => {
      if (job.timeoutHandle) clearTimeout(job.timeoutHandle);
      job.timeoutHandle = null;
    };
    const armJobTimeout = () => {
      clearJobTimeout();
      if (!Number.isFinite(timeoutMs) || timeoutMs <= 0 || controller.signal.aborted) return;
      job.timeoutHandle = setTimeout(() => {
        controller.abort(new DOMException("Job melewati batas waktu.", "TimeoutError"));
      }, timeoutMs);
    };
    job.pauseTimeout = () => {
      job.timeoutPaused = true;
      clearJobTimeout();
    };
    job.resumeTimeout = () => {
      job.timeoutPaused = false;
      armJobTimeout();
    };

    armJobTimeout();
    activeJobs.set(normalizedKey, job);

    const promise = Promise.resolve()
      .then(() => runner({ signal: controller.signal, job }))
      .finally(() => {
        clearJobTimeout();
        if (activeJobs.get(normalizedKey)?.id === job.id) activeJobs.delete(normalizedKey);
      });

    job.promise = promise;
    return { accepted: true, job, promise };
  }

  function abort(key, reason = new DOMException("Job dibatalkan.", "AbortError")) {
    const job = get(key);
    if (!job) return false;
    job.controller.abort(reason);
    return true;
  }

  async function abortAndWait(
    key,
    reason = new DOMException("Job dibatalkan.", "AbortError"),
  ) {
    const job = get(key);
    if (!job) return { aborted: false, released: true, job: null };

    const aborted = abort(key, reason);
    await Promise.resolve(job.promise).catch(() => {});
    return {
      aborted,
      released: get(key) === null,
      job,
    };
  }

  function abortAll(reason = new DOMException("Bot dihentikan.", "AbortError")) {
    for (const job of activeJobs.values()) job.controller.abort(reason);
  }

  async function abortAllAndWait(
    reason = new DOMException("Bot dihentikan.", "AbortError"),
  ) {
    const jobs = [...activeJobs.values()];
    for (const job of jobs) job.controller.abort(reason);
    await Promise.allSettled(jobs.map((job) => Promise.resolve(job.promise)));
    return {
      aborted: jobs.length,
      released: jobs.filter((job) => get(job.key) === null).length,
      remaining: activeJobs.size,
    };
  }

  return {
    get,
    getActiveCount,
    getActiveJobs,
    start,
    abort,
    abortAndWait,
    abortAll,
    abortAllAndWait,
  };
}

module.exports = { createCheckJobQueue };
