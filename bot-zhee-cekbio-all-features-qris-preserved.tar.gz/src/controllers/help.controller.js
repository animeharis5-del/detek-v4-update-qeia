function registerHelpController({
  bot,
  isGroupChat,
  isKnownTelegramUser,
  replyUserUnknownInGroup,
  rememberUser,
  replyHelp,
}) {
  bot.command("help", async (ctx) => {
    if (isGroupChat(ctx) && !isKnownTelegramUser(ctx.from.id)) {
      return replyUserUnknownInGroup(ctx);
    }
    rememberUser(ctx, { allowGroupRegister: true });
    return replyHelp(ctx);
  });
}

module.exports = { registerHelpController };
