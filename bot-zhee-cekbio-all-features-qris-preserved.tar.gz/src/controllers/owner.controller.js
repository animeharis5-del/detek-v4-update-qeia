function registerOwnerController({
  bot,
  callbacks,
  isOwner,
  isGroupChat,
  rememberUser,
  promptBroadcast,
  replyOwnerStats,
  answerCallback,
  replySafe,
  buildFriendlyIssueCard,
  isMaintenanceMode,
  setMaintenanceMode,
  runMaintenanceDisabledNotification,
  renderTextPanel,
  buildMaintenancePanel,
  menuOnlyKeyboard,
}) {
  bot.command("broadcast", async (ctx) => {
    if (!isOwner(ctx.from?.id) || isGroupChat(ctx)) return;
    rememberUser(ctx);
    return promptBroadcast(ctx);
  });

  bot.command("stats", async (ctx) => {
    if (!isOwner(ctx.from?.id) || isGroupChat(ctx)) return;
    rememberUser(ctx);
    return replyOwnerStats(ctx);
  });

  bot.action(callbacks.OWN_BROADCAST, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return promptBroadcast(ctx);
  });

  bot.action(callbacks.OWN_MAINTENANCE, async (ctx) => {
    if (!isOwner(ctx.from?.id)) {
      await answerCallback(ctx);
      return replySafe(
        ctx,
        buildFriendlyIssueCard(
          "AKSES DITOLAK",
          "Menu ini hanya untuk owner.",
          "Kembali ke menu utama.",
        ),
      );
    }

    rememberUser(ctx);
    const newState = !isMaintenanceMode();
    await setMaintenanceMode(newState);
    await ctx
      .answerCbQuery(`Maintenance ${newState ? "aktif" : "nonaktif"}.`)
      .catch(() => {});

    if (!newState) {
      runMaintenanceDisabledNotification(ctx.chat?.id, ctx.from?.id);
      return renderTextPanel(
        ctx,
        buildMaintenancePanel(newState, "Notifikasi sedang dikirim ke semua user."),
        menuOnlyKeyboard(),
      );
    }

    return renderTextPanel(ctx, buildMaintenancePanel(newState), menuOnlyKeyboard());
  });
}

module.exports = { registerOwnerController };
