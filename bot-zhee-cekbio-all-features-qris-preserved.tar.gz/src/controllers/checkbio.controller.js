function registerCheckBioController({
  bot,
  callbacks,
  answerCallback,
  abortActiveCheck,
  requestPausedCheckResultsConfirmation,
  confirmPausedCheckResults,
  cancelPausedCheckResultsConfirmation,
  resumePausedCheck,
  isGroupChat,
  isKnownTelegramUser,
  replyUserUnknownInGroup,
  rememberUser,
  extractCommandPayload,
  promptCheckBio,
  clearUserState,
  handleCheckBioText,
  replySafe,
  getCheckBioTxtUsageText,
  handleCheckBioDocument,
  isCekbioTxtCaption,
}) {
  bot.command("cekbio", async (ctx) => {
    if (isGroupChat(ctx) && !isKnownTelegramUser(ctx.from.id)) {
      return replyUserUnknownInGroup(ctx);
    }
    rememberUser(ctx, { allowGroupRegister: true });
    const payload = extractCommandPayload(ctx.message?.text || "", "cekbio");
    if (!payload) return promptCheckBio(ctx);
    clearUserState(ctx.from.id);
    return handleCheckBioText(ctx, payload);
  });

  bot.command("cekbiotxt", async (ctx) => {
    if (isGroupChat(ctx) && !isKnownTelegramUser(ctx.from.id)) {
      return replyUserUnknownInGroup(ctx);
    }
    rememberUser(ctx, { allowGroupRegister: true });
    const doc = ctx.message?.reply_to_message?.document;
    if (!doc) return replySafe(ctx, getCheckBioTxtUsageText());
    clearUserState(ctx.from.id);
    return handleCheckBioDocument(ctx, doc);
  });

  bot.action(callbacks.ABORT_CHECK, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return abortActiveCheck(ctx);
  });

  bot.action(callbacks.SEND_PARTIAL_CHECK, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return requestPausedCheckResultsConfirmation(ctx);
  });

  bot.action(callbacks.CONFIRM_SEND_PARTIAL_CHECK, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return confirmPausedCheckResults(ctx);
  });

  bot.action(callbacks.CANCEL_SEND_PARTIAL_CHECK, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return cancelPausedCheckResultsConfirmation(ctx);
  });

  bot.action(callbacks.RESUME_CHECK, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return resumePausedCheck(ctx);
  });

  bot.on("document", async (ctx) => {
    if (!isCekbioTxtCaption(ctx)) return;
    if (isGroupChat(ctx) && !isKnownTelegramUser(ctx.from.id)) {
      return replyUserUnknownInGroup(ctx);
    }
    rememberUser(ctx, { allowGroupRegister: true });
    clearUserState(ctx.from.id);
    return handleCheckBioDocument(ctx, ctx.message.document);
  });
}

module.exports = { registerCheckBioController };
