function registerWhatsAppController({
  bot,
  callbacks,
  answerCallback,
  rememberUser,
  isGroupChat,
  replyWaSourceMenu,
  replyDisconnectSenderMenu,
  promptPairing,
  promptPairingCode,
  startQrFlow,
  replyWhatsAppStatus,
  reloadWhatsAppSession,
  disconnectCurrentSender,
  disconnectSenderById,
  disconnectAllSenders,
}) {
  bot.command("senderku", async (ctx) => {
    rememberUser(ctx, { allowGroupRegister: true });
    return replyWaSourceMenu(ctx);
  });

  bot.action(callbacks.WA_MENU, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return replyWaSourceMenu(ctx);
  });
  // Tombol Pairing WA: tampilkan pilihan metode (Pairing Code / QR).
  bot.action(callbacks.PAIR, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return promptPairing(ctx);
  });
  // Pilih metode: Pairing Code (minta nomor).
  bot.action(callbacks.PAIR_CODE, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return promptPairingCode(ctx);
  });
  // Pilih metode: QR (kirim gambar QR).
  bot.action(callbacks.PAIR_QR, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return startQrFlow(ctx);
  });
  bot.action(callbacks.DISCONNECT_MENU, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return replyDisconnectSenderMenu(ctx);
  });
  bot.action(callbacks.DISCONNECT_CURRENT, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return disconnectCurrentSender(ctx);
  });

  const senderPrefix = String(callbacks.DISCONNECT_SENDER_PREFIX || "DS:");
  const escapedSenderPrefix = senderPrefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  bot.action(
    new RegExp(`^${escapedSenderPrefix}([A-Za-z0-9_-]{1,64})$`),
    async (ctx) => {
      await answerCallback(ctx);
      rememberUser(ctx);
      return disconnectSenderById(ctx, ctx.match?.[1] || "default");
    },
  );

  bot.action(callbacks.DISCONNECT_ALL, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return disconnectAllSenders(ctx);
  });
  bot.action(callbacks.STATUS, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return replyWhatsAppStatus(ctx);
  });
  bot.action(callbacks.RELOAD, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return reloadWhatsAppSession(ctx);
  });
}

module.exports = { registerWhatsAppController };
