function registerStartController({
  bot,
  isGroupChat,
  isKnownTelegramUser,
  replyUserUnknownInGroup,
  rememberUser,
  clearActivePairingPanel,
  clearUserState,
  replyGroupRecognizedStart,
  replyMainMenuCard,
}) {
  bot.start(async (ctx) => {
    if (isGroupChat(ctx)) {
      if (!isKnownTelegramUser(ctx.from.id)) return replyUserUnknownInGroup(ctx);
      rememberUser(ctx, { allowGroupRegister: true });
      clearActivePairingPanel(ctx.from.id);
      clearUserState(ctx.from.id);
      return replyGroupRecognizedStart(ctx);
    }
    rememberUser(ctx);
    clearActivePairingPanel(ctx.from.id);
    clearUserState(ctx.from.id);
    return replyMainMenuCard(ctx);
  });
}

module.exports = { registerStartController };
