function registerCallbackController({
  bot,
  callbacks,
  answerCallback,
  isGroupChat,
  isKnownTelegramUser,
  replyUserUnknownInGroup,
  rememberUser,
  getForceJoinStatus,
  replyMainMenuCard,
  showForceJoinGate,
  renderTextPanel,
  getForceJoinVerifiedText,
  emptyKeyboard,
  replyGroupRecognizedStart,
  showMainMenu,
  getUserState,
  clearUserState,
  replyWaSourceMenu,
  buildSenderPairingCancelledCard,
  cancelQrFlow,
}) {
  bot.action(/^noop_\d+$/, async (ctx) => {
    await ctx.answerCbQuery(
      "⚠️ Link belum tersedia. Pastikan bot sudah jadi admin di grup/channel ini.",
      { show_alert: true },
    );
  });

  bot.action(callbacks.JOIN_VERIFY, async (ctx) => {
    await answerCallback(ctx);
    if (isGroupChat(ctx) && !isKnownTelegramUser(ctx.from.id)) {
      return replyUserUnknownInGroup(ctx);
    }
    rememberUser(ctx, { allowGroupRegister: true });
    const joinStatus = await getForceJoinStatus(ctx.from.id, { force: true });
    if (!joinStatus.enabled) return replyMainMenuCard(ctx);
    if (!joinStatus.canVerify) return showForceJoinGate(ctx, "unavailable", joinStatus);
    if (!joinStatus.joined) return showForceJoinGate(ctx, "failed", joinStatus);
    await renderTextPanel(ctx, getForceJoinVerifiedText(), emptyKeyboard());
    if (isGroupChat(ctx)) return replyGroupRecognizedStart(ctx);
    return replyMainMenuCard(ctx);
  });

  bot.action(callbacks.MENU, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return showMainMenu(ctx);
  });

  bot.action(callbacks.CLOSE_WA_MENU, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    return showMainMenu(ctx);
  });

  bot.action(callbacks.CANCEL_STATE, async (ctx) => {
    await answerCallback(ctx);
    rememberUser(ctx);
    const state = getUserState(ctx.from.id);
    clearUserState(ctx.from.id);

    const isPairingState = [
      "await_pairing",
      "await_pairing_result",
      "await_qr_pairing",
    ].includes(state?.type);

    if (isPairingState) {
      // Reset socket/auth hanya bila pairing memang sudah dimulai. Saat user
      // baru berada di prompt nomor, cukup keluar dari state UI saja.
      if (
        state?.type !== "await_pairing" &&
        typeof cancelQrFlow === "function"
      ) {
        await cancelQrFlow(ctx.from.id, state).catch(() => {});
      }
      return replyWaSourceMenu(ctx, buildSenderPairingCancelledCard());
    }
    return showMainMenu(ctx);
  });
}

module.exports = { registerCallbackController };
