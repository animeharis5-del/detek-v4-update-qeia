function sameChat(left, right) {
  return String(left ?? "") === String(right ?? "");
}

function registerTextController({
  bot,
  isGroupChat,
  getUserState,
  rememberUser,
  handleBroadcastText,
  extractSlashCommandInfo,
  handlePairingText,
}) {
  bot.on("text", async (ctx) => {
    const userId = ctx.from.id;
    const text = String(ctx.message?.text || "").trim();
    const state = getUserState(userId);
    const group = typeof isGroupChat === "function" && isGroupChat(ctx);

    // Di grup, teks biasa hanya boleh masuk ke state Pairing Code milik user
    // yang dibuat di grup yang sama. Pesan anggota lain tetap diabaikan.
    if (group) {
      const pairingChatId = state?.promptMessage?.chatId ?? state?.chatId;
      if (state?.type !== "await_pairing" || !sameChat(pairingChatId, ctx.chat?.id)) {
        return;
      }
    }

    rememberUser(ctx, group ? { allowGroupRegister: true } : undefined);
    if (!text) return;
    if (!group && state?.type === "await_owner_broadcast") return handleBroadcastText(ctx);
    if (extractSlashCommandInfo(text)) return;
    if (state?.type === "await_pairing") return handlePairingText(ctx, text);
  });
}

module.exports = { registerTextController };
