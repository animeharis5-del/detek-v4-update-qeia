const path = require('node:path');
const crypto = require('node:crypto');
const { readJsonFile, updateJsonFileAtomic } = require('../repositories/json.repository');

const WALLET_PATH = path.join(process.cwd(), 'wallet.json');

function defaultDb() {
  return { version: 1, users: {}, reservations: {}, transactions: {} };
}

function key(userId) {
  const id = String(userId ?? '').trim();
  if (!/^\d+$/.test(id)) throw new Error('Telegram user id tidak valid.');
  return id;
}

function n(value) {
  const x = Number(value);
  return Number.isFinite(x) ? x : 0;
}
// Token bisa pecahan (mis. 0.4 token untuk 20 dari 50 nomor/token).
// Dibulatkan ke 2 desimal supaya tidak ada floating point drift di JSON.
function round2(value) {
  return Math.max(0, Math.round(n(value) * 100) / 100);
}
function cloneDb(db) { return JSON.parse(JSON.stringify(db)); }

async function getWalletDb() {
  return readJsonFile(WALLET_PATH, defaultDb());
}

async function getBalance(userId) {
  const db = await getWalletDb();
  return Math.max(0, round2(n(db.users[key(userId)]?.balance)));
}

async function getUserWallet(userId) {
  const db = await getWalletDb();
  const user = db.users[key(userId)] || {};
  return {
    userId: key(userId),
    balance: Math.max(0, round2(n(user.balance))),
    totalPurchased: Math.max(0, round2(n(user.totalPurchased))),
    totalUsed: Math.max(0, round2(n(user.totalUsed))),
  };
}

async function addBalance(userId, amount, meta = {}) {
  const id = key(userId);
  const delta = round2(n(amount));
  if (delta <= 0) throw new Error('Jumlah saldo harus lebih dari 0.');
  return updateJsonFileAtomic(WALLET_PATH, defaultDb(), (db) => {
    const next = cloneDb(db);
    next.users[id] ||= { balance: 0, totalPurchased: 0, totalUsed: 0 };
    next.users[id].balance = round2(round2(n(next.users[id].balance)) + delta);
    next.users[id].totalPurchased = round2(round2(n(next.users[id].totalPurchased)) + delta);
    return next;
  }).then((db) => ({ balance: round2(n(db.users[id].balance)), added: delta, meta }));
}

async function deductBalance(userId, amount, meta = {}) {
  const id = key(userId);
  const delta = round2(n(amount));
  if (delta <= 0) throw new Error('Jumlah saldo harus lebih dari 0.');
  let deducted = 0;
  const db = await updateJsonFileAtomic(WALLET_PATH, defaultDb(), (db) => {
    const next = cloneDb(db);
    next.users[id] ||= { balance: 0, totalPurchased: 0, totalUsed: 0 };
    const balance = Math.max(0, round2(n(next.users[id].balance)));
    deducted = round2(Math.min(balance, delta));
    next.users[id].balance = round2(balance - deducted);
    return next;
  });
  return { balance: round2(n(db.users[id].balance)), deducted, meta };
}

async function reserveBalance(userId, amount, meta = {}) {
  const id = key(userId);
  const reserve = round2(n(amount));
  if (reserve < 0) throw new Error('Reservasi saldo tidak valid.');
  const reservationId = String(meta.reservationId || `res_${crypto.randomUUID()}`);
  let result;
  await updateJsonFileAtomic(WALLET_PATH, defaultDb(), (db) => {
    const next = cloneDb(db);
    next.users[id] ||= { balance: 0, totalPurchased: 0, totalUsed: 0 };
    const existing = next.reservations[reservationId];
    if (existing) {
      if (String(existing.userId) !== id || round2(existing.reserved) !== reserve) {
        const error = new Error('Reservation ID sudah digunakan untuk transaksi berbeda.');
        error.code = 'RESERVATION_CONFLICT';
        throw error;
      }
      if (existing.status === 'reserved') {
        result = {
          reservationId,
          reserved: round2(existing.reserved),
          balanceAfterReserve: round2(n(next.users[id].balance)),
          duplicate: true,
        };
        return next;
      }
      const error = new Error('Reservation ID sudah tidak aktif.');
      error.code = 'RESERVATION_NOT_ACTIVE';
      throw error;
    }
    const balance = round2(n(next.users[id].balance));
    if (balance < reserve) {
      const error = new Error(`Saldo tidak cukup. Dibutuhkan ${reserve} token, saldo ${balance} token.`);
      error.code = 'INSUFFICIENT_BALANCE';
      error.balance = balance;
      error.required = reserve;
      throw error;
    }
    next.users[id].balance = balance - reserve;
    next.reservations[reservationId] = {
      reservationId,
      userId: id,
      reserved: reserve,
      status: 'reserved',
      createdAt: new Date().toISOString(),
      meta,
    };
    result = { reservationId, reserved: reserve, balanceAfterReserve: next.users[id].balance };
    return next;
  });
  return result;
}

async function settleReservation(reservationId, actualUsed) {
  const rid = String(reservationId || '').trim();
  const used = Math.max(0, round2(n(actualUsed)));
  let result = null;
  await updateJsonFileAtomic(WALLET_PATH, defaultDb(), (db) => {
    const next = cloneDb(db);
    const r = next.reservations[rid];
    if (!r || r.status !== 'reserved') return next;
    const reserved = Math.max(0, round2(n(r.reserved)));
    const charge = Math.min(reserved, used);
    const refund = reserved - charge;
    const id = key(r.userId);
    next.users[id] ||= { balance: 0, totalPurchased: 0, totalUsed: 0 };
    next.users[id].balance = round2(round2(n(next.users[id].balance)) + refund);
    next.users[id].totalUsed = round2(round2(n(next.users[id].totalUsed)) + charge);
    r.status = 'settled';
    r.actualUsed = charge;
    r.refund = refund;
    r.settledAt = new Date().toISOString();
    result = { reservationId: rid, reserved, charged: charge, refunded: refund, balance: next.users[id].balance };
    return next;
  });
  return result || { reservationId: rid, charged: 0, refunded: 0 };
}

async function refundReservation(reservationId) {
  return settleReservation(reservationId, 0);
}

async function recordQrisTransaction(transactionId, data) {
  const id = String(transactionId || '').trim();
  if (!id) throw new Error('transaction_id kosong.');
  let created = false;
  await updateJsonFileAtomic(WALLET_PATH, defaultDb(), (db) => {
    const next = cloneDb(db);
    if (next.transactions[id]) return next;
    next.transactions[id] = { ...data, transactionId: id, status: 'pending', createdAt: new Date().toISOString() };
    created = true;
    return next;
  });
  return { created };
}

async function getQrisTransaction(transactionId) {
  const db = await getWalletDb();
  return db.transactions[String(transactionId || '').trim()] || null;
}

async function completeQrisTransaction(transactionId, payment) {
  const id = String(transactionId || '').trim();
  let result = null;
  await updateJsonFileAtomic(WALLET_PATH, defaultDb(), async (db) => {
    const next = cloneDb(db);
    const trx = next.transactions[id];
    if (!trx) return next;
    if (trx.status === 'success') {
      result = { duplicate: true, transaction: trx };
      return next;
    }
    const amount = Math.max(0, round2(n(payment?.amount)));
    const tokens = Math.max(0, round2(n(trx.tokensExpected)));
    if (tokens <= 0) return next;
    const uid = key(trx.userId);
    next.users[uid] ||= { balance: 0, totalPurchased: 0, totalUsed: 0 };
    next.users[uid].balance += tokens;
    next.users[uid].totalPurchased += tokens;
    trx.status = 'success';
    trx.amountPaid = amount;
    trx.paidAt = payment?.paid_at || new Date().toISOString();
    trx.tokensCredited = tokens;
    result = { duplicate: false, userId: uid, tokens, balance: next.users[uid].balance, transaction: trx };
    return next;
  });
  return result;
}

async function listAllUserWallets() {
  const db = await getWalletDb();
  return Object.entries(db.users || {}).map(([userId, user]) => ({
    userId: String(userId),
    balance: Math.max(0, round2(n(user?.balance))),
    totalPurchased: Math.max(0, round2(n(user?.totalPurchased))),
    totalUsed: Math.max(0, round2(n(user?.totalUsed))),
  }));
}

async function listUserQrisTransactions(userId, limit = 10) {
  const uid = key(userId);
  const db = await getWalletDb();
  return Object.values(db.transactions || {})
    .filter((trx) => String(trx.userId || '') === uid)
    .sort((a, b) => Date.parse(b.createdAt || 0) - Date.parse(a.createdAt || 0))
    .slice(0, Math.max(1, Number(limit) || 10));
}

async function listPendingQrisTransactions(limit = 20) {
  const db = await getWalletDb();
  return Object.values(db.transactions || {})
    .filter((trx) => trx.status === 'pending')
    .sort((a, b) => Date.parse(a.createdAt || 0) - Date.parse(b.createdAt || 0))
    .slice(0, Math.max(1, Number(limit) || 20));
}

async function markQrisTransactionStatus(transactionId, status, extra = {}) {
  const id = String(transactionId || '').trim();
  await updateJsonFileAtomic(WALLET_PATH, defaultDb(), (db) => {
    const next = cloneDb(db);
    const trx = next.transactions[id];
    if (!trx) return next;
    if (trx.status === 'success') return next;
    trx.status = String(status || trx.status);
    Object.assign(trx, extra);
    trx.updatedAt = new Date().toISOString();
    return next;
  });
}

async function recoverStaleReservations(maxAgeMs = 2 * 60 * 60 * 1000, protectedReservationIds = []) {
  const now = Date.now();
  const protectedIds = new Set((Array.isArray(protectedReservationIds) ? protectedReservationIds : [protectedReservationIds]).map((id) => String(id || '').trim()).filter(Boolean));
  const recovered = [];
  await updateJsonFileAtomic(WALLET_PATH, defaultDb(), (db) => {
    const next = cloneDb(db);
    for (const [rid, r] of Object.entries(next.reservations || {})) {
      if (r.status !== 'reserved') continue;
      if (protectedIds.has(String(rid))) continue;
      const age = now - Date.parse(r.createdAt || 0);
      if (!Number.isFinite(age) || age < maxAgeMs) continue;
      const id = key(r.userId);
      next.users[id] ||= { balance: 0, totalPurchased: 0, totalUsed: 0 };
      const refund = Math.max(0, round2(n(r.reserved)));
      next.users[id].balance += refund;
      r.status = 'recovered';
      r.refund = refund;
      r.recoveredAt = new Date().toISOString();
      recovered.push({ reservationId: rid, userId: id, refund });
    }
    return next;
  });
  return recovered;
}

module.exports = {
  WALLET_PATH,
  getBalance,
  getUserWallet,
  listAllUserWallets,
  addBalance,
  deductBalance,
  reserveBalance,
  settleReservation,
  refundReservation,
  recordQrisTransaction,
  getQrisTransaction,
  completeQrisTransaction,
  listPendingQrisTransactions,
  listUserQrisTransactions,
  markQrisTransactionStatus,
  recoverStaleReservations,
};
