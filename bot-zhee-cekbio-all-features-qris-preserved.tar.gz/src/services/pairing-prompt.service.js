function normalizePromptMessageMeta(panelMeta) {
  const chatId = panelMeta?.chatId;
  const messageId = panelMeta?.messageId;
  if (chatId === undefined || chatId === null || !messageId) return null;
  return { chatId, messageId };
}

function createAwaitPairingState(panelMeta) {
  const promptMessage = normalizePromptMessageMeta(panelMeta);
  return promptMessage
    ? { type: "await_pairing", promptMessage }
    : { type: "await_pairing" };
}

async function deletePairingPromptMessage(
  telegram,
  state,
  { onIgnored } = {},
) {
  const promptMessage = normalizePromptMessageMeta(state?.promptMessage);
  if (!promptMessage || typeof telegram?.deleteMessage !== "function") {
    return false;
  }

  try {
    await telegram.deleteMessage(
      promptMessage.chatId,
      promptMessage.messageId,
    );
    return true;
  } catch (error) {
    onIgnored?.(error);
    return false;
  }
}

module.exports = {
  createAwaitPairingState,
  deletePairingPromptMessage,
};
