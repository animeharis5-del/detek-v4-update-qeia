const { abortableDelay } = require("../utils/abort");

class NoReadySenderError extends Error {
  constructor(userId, { attemptedSenderIds = [], cause = null } = {}) {
    super("Tidak ada Sender milik user yang siap menerima pekerjaan.", cause ? { cause } : undefined);
    this.name = "NoReadySenderError";
    this.code = "NO_READY_SENDER";
    this.userId = String(userId ?? "");
    this.attemptedSenderIds = [...new Set(attemptedSenderIds.map(String))];
  }
}

function isSenderConnectionFailure(error, senderSnapshot = null) {
  const code = String(error?.code || "");
  if (
    code === "WA_SENDER_NOT_CONNECTED" ||
    code === "WA_PROFILE_CONNECTION_FAILED" ||
    code === "WA_SESSION_DISCONNECTED"
  ) {
    return true;
  }

  // Error query transien hanya dipindahkan ke Sender lain bila Sender yang
  // mengerjakannya memang sudah tidak READY. Rate-limit/query error pada
  // Sender yang masih sehat tetap ditangani retry biasa dan tidak dipakai
  // untuk mengakali pembatasan platform.
  return Boolean(
    error?.retryable === true &&
      senderSnapshot &&
      (senderSnapshot.connectivityState !== "ready" ||
        senderSnapshot.connected !== true ||
        senderSnapshot.ready !== true),
  );
}

/**
 * Router pengecekan multi-Sender untuk /cekbio dan /cekbiotxt.
 *
 * Pool selalu di-scope dengan Telegram user id pemilik job sehingga Sender
 * user lain tidak pernah masuk kandidat scheduler.
 *
 * Tahap 7 menambah failover per-task: jika Sender yang memegang task benar-
 * benar kehilangan koneksi, task yang sama boleh dipindahkan ke Sender sehat
 * lain milik user. Satu Sender tidak dicoba dua kali dalam satu putaran
 * failover agar error koneksi tidak membuat loop tanpa batas.
 */
function createSenderCheckRouter({
  senderPool,
  checkWithSender,
  waitForSlotMs = 50,
  maxWaitMs = 5000,
  now = () => Date.now(),
} = {}) {
  if (!senderPool || typeof senderPool.acquire !== "function") {
    throw new TypeError("senderPool wajib menyediakan acquire().");
  }
  if (typeof senderPool.release !== "function") {
    throw new TypeError("senderPool wajib menyediakan release().");
  }
  if (typeof senderPool.getSnapshot !== "function") {
    throw new TypeError("senderPool wajib menyediakan getSnapshot().");
  }
  if (typeof checkWithSender !== "function") {
    throw new TypeError("checkWithSender wajib berupa fungsi.");
  }

  const slotDelayMs = Math.max(10, Number(waitForSlotMs) || 50);
  const slotWaitLimitMs = Math.max(slotDelayMs, Number(maxWaitMs) || 5000);

  function getSnapshot(userId, { maxActivePerSender = null } = {}) {
    return senderPool.getSnapshot(userId, {
      capacityOverride: maxActivePerSender,
    });
  }

  function getConcurrency(
    userId,
    fallback = 1,
    { maxActivePerSender = null, totalLimit = null } = {},
  ) {
    const configured = Math.max(1, Number.parseInt(String(fallback ?? 1), 10) || 1);

    // Compatibility: tanpa pilihan speed per-Sender, pertahankan perilaku lama
    // (maksimum satu lease per Sender dan dibatasi fallback global).
    if (maxActivePerSender == null) {
      const snapshot = getSnapshot(userId, { maxActivePerSender });
      return Math.max(1, Math.min(configured, Math.max(1, snapshot.available || 0)));
    }

    const perSender = Math.max(
      1,
      Number.parseInt(String(maxActivePerSender ?? 1), 10) || 1,
    );
    const snapshot = getSnapshot(userId, { maxActivePerSender: perSender });
    const connectedSenders = snapshot.senders.filter(
      (sender) => sender.connectivityState === "ready" && sender.connected === true,
    ).length;
    const capacity = Math.max(1, connectedSenders * perSender);

    // `concurrency` merepresentasikan kapasitas job berdasarkan jumlah Sender
    // READY x speed per Sender. Jangan potong dengan sisa jumlah nomor: bila
    // 4 Sender x speed 100, panel dan scheduler tetap memiliki kapasitas 400.
    // Runner tidak akan membuat task kosong bila input yang tersisa < 400.
    void totalLimit; // dipertahankan di signature untuk kompatibilitas caller lama.
    return capacity;
  }

  function hasUntriedPotential(snapshot, attemptedSenderIds) {
    const attempted = new Set(attemptedSenderIds);
    return snapshot.senders.some(
      (sender) =>
        !attempted.has(sender.senderId) &&
        (sender.schedulerEligible === true || sender.health === "busy"),
    );
  }

  async function acquireWhenAvailable(
    userId,
    meta,
    signal,
    { excludeSenderIds = [], maxActivePerSender = null } = {},
  ) {
    const startedAt = Number(now()) || Date.now();
    while (true) {
      signal?.throwIfAborted();
      const lease = senderPool.acquire(userId, meta, {
        excludeSenderIds,
        capacityOverride: maxActivePerSender,
      });
      if (lease) return lease;

      const snapshot = getSnapshot(userId, { maxActivePerSender });
      if (!snapshot.total || (!snapshot.ready && !snapshot.busy)) {
        throw new NoReadySenderError(userId, {
          attemptedSenderIds: excludeSenderIds,
        });
      }
      if (!hasUntriedPotential(snapshot, excludeSenderIds)) {
        return null;
      }
      if ((Number(now()) || Date.now()) - startedAt >= slotWaitLimitMs) {
        throw new NoReadySenderError(userId, {
          attemptedSenderIds: excludeSenderIds,
        });
      }
      await abortableDelay(slotDelayMs, signal);
    }
  }

  async function check(
    userId,
    number,
    { signal, type = "check", maxActivePerSender = null } = {},
  ) {
    const checkType = String(type || "check").trim() || "check";
    const attemptedSenderIds = [];
    let lastSenderError = null;

    while (true) {
      const lease = await acquireWhenAvailable(
        userId,
        { type: checkType, number: String(number ?? "") },
        signal,
        { excludeSenderIds: attemptedSenderIds, maxActivePerSender },
      );

      // Tidak ada Sender lain yang belum dicoba, tetapi Sender yang gagal
      // sebelumnya masih dianggap sehat oleh pool. Biarkan retry layer normal
      // menangani error aslinya daripada mem-pause seluruh job secara salah.
      if (!lease) throw lastSenderError || new NoReadySenderError(userId);

      try {
        signal?.throwIfAborted();
        return await checkWithSender(userId, lease.senderId, number, { signal });
      } catch (error) {
        if (signal?.aborted) throw signal.reason || error;
        const senderSnapshot = getSnapshot(userId, { maxActivePerSender }).senders.find(
          (sender) => sender.senderId === lease.senderId,
        );
        if (!isSenderConnectionFailure(error, senderSnapshot)) throw error;

        lastSenderError = error;
        attemptedSenderIds.push(lease.senderId);
      } finally {
        senderPool.release(lease);
      }

      const snapshot = getSnapshot(userId, { maxActivePerSender });
      if (!hasUntriedPotential(snapshot, attemptedSenderIds)) {
        if (!snapshot.ready && !snapshot.busy) {
          throw new NoReadySenderError(userId, {
            attemptedSenderIds,
            cause: lastSenderError,
          });
        }
        throw lastSenderError;
      }
    }
  }

  return Object.freeze({
    getSnapshot,
    getConcurrency,
    check,
  });
}

module.exports = {
  NoReadySenderError,
  isSenderConnectionFailure,
  createSenderCheckRouter,
};
