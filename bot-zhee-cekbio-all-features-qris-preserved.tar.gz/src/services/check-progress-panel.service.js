const { editOrResendTelegramPanel } = require("./telegram.service");

function hasMessageId(panel) {
  return Boolean(panel?.message_id);
}

function getTrackedProgressPanel(job, fallbackPanel = null) {
  if (hasMessageId(job?.progressMsg)) return job.progressMsg;
  return hasMessageId(fallbackPanel) ? fallbackPanel : null;
}

function setTrackedProgressPanel(job, panel) {
  if (!job || !hasMessageId(panel)) return getTrackedProgressPanel(job);
  job.progressMsg = panel;
  return panel;
}

function enqueueProgressPanelOperation(job, operation) {
  if (!job || typeof operation !== "function") {
    return Promise.resolve(null);
  }

  const previous = job.progressPanelOperation || Promise.resolve();
  let queued;
  queued = previous
    .catch(() => {})
    .then(operation)
    .finally(() => {
      if (job.progressPanelOperation === queued) {
        job.progressPanelOperation = null;
      }
    });
  job.progressPanelOperation = queued;
  return queued;
}

async function updateTrackedProgressPanel(
  job,
  {
    fallbackPanel = null,
    editPanel,
    resendPanel,
    discardPanel = null,
    onEditFallback = null,
  } = {},
) {
  return enqueueProgressPanelOperation(job, async () => {
    const currentPanel = getTrackedProgressPanel(job, fallbackPanel);
    const rendered = await editOrResendTelegramPanel({
      currentPanel,
      editPanel:
        currentPanel && typeof editPanel === "function"
          ? () => editPanel(currentPanel)
          : null,
      resendPanel,
      discardPanel:
        currentPanel && typeof discardPanel === "function"
          ? () => discardPanel(currentPanel)
          : null,
      onEditFallback,
    });

    if (hasMessageId(rendered)) {
      job.progressMsg = rendered;
      return rendered;
    }
    return getTrackedProgressPanel(job, currentPanel);
  });
}

async function deleteTrackedProgressPanel(job, { deletePanel } = {}) {
  return enqueueProgressPanelOperation(job, async () => {
    const currentPanel = getTrackedProgressPanel(job);
    if (!currentPanel) {
      if (job) job.progressMsg = null;
      return false;
    }

    try {
      if (typeof deletePanel === "function") {
        await deletePanel(currentPanel);
      }
    } finally {
      if (job?.progressMsg?.message_id === currentPanel.message_id) {
        job.progressMsg = null;
      }
    }
    return true;
  });
}

module.exports = {
  deleteTrackedProgressPanel,
  getTrackedProgressPanel,
  setTrackedProgressPanel,
  updateTrackedProgressPanel,
};
