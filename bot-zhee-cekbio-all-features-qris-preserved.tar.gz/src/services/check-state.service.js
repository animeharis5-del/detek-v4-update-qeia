const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const readline = require("node:readline");
const { finished, pipeline } = require("node:stream/promises");
const { createStreamingTxtReport } = require("../presentation/stream-txt-report");
const {
  createStreamingSummaryOnlyReport,
} = require("../presentation/stream-summary-txt-report");
const { createTempWorkspace } = require("./temp-dir.service");

async function writeLines(filePath, values) {
  const output = fs.createWriteStream(filePath, { flags: "wx", mode: 0o600 });
  try {
    for (const value of values) {
      if (!output.write(`${String(value).trim()}\n`)) {
        await new Promise((resolve) => output.once("drain", resolve));
      }
    }
    output.end();
    await finished(output);
  } catch (error) {
    output.destroy();
    throw error;
  }
}

async function* readJsonLines(filePath) {
  const input = fs.createReadStream(filePath, { encoding: "utf8" });
  const lines = readline.createInterface({ input, crlfDelay: Infinity });
  try {
    for await (const line of lines) {
      const value = String(line || "").trim();
      if (value) yield JSON.parse(value);
    }
  } finally {
    lines.close();
    input.destroy();
  }
}

async function createCheckState({ numbers = null, inputPath = "", total, metadata = {} }) {
  const tempDir = await createTempWorkspace("cekbio-job-");
  const numbersPath = path.join(tempDir, "numbers.txt");
  const resultsPath = path.join(tempDir, "results.jsonl");
  const cachedPath = path.join(tempDir, "cached-results.jsonl");
  const remainingPath = path.join(tempDir, "remaining.txt");
  const manifestPath = path.join(tempDir, "pause-state.json");

  try {
    if (inputPath) {
      await pipeline(
        fs.createReadStream(inputPath),
        fs.createWriteStream(numbersPath, { flags: "wx", mode: 0o600 }),
      );
    } else {
      await writeLines(numbersPath, Array.isArray(numbers) ? numbers : []);
    }

    const resultHandle = await fsp.open(resultsPath, "a", 0o600);
    let nextIndex = 0;
    let closed = false;

    async function appendCommittedBatch(entries) {
      if (closed) throw new Error("State pengecekan sudah ditutup.");
      const source = Array.isArray(entries) ? entries : [];
      if (!source.length) return 0;

      let expected = nextIndex;
      const lines = [];
      for (const entry of source) {
        const index = Number(entry?.index);
        if (index !== expected) {
          throw new Error(`Urutan hasil tidak valid: expected=${expected} actual=${index}`);
        }
        lines.push(JSON.stringify({ index, result: entry.result }));
        expected++;
      }

      // Tahap 9: satu write untuk satu kelompok hasil contiguous. Ini mengurangi
      // syscall/disk await ketika ribuan hasil selesai cepat secara paralel.
      await resultHandle.write(`${lines.join("\n")}\n`);
      nextIndex = expected;
      return source.length;
    }

    async function appendCommitted(index, result) {
      await appendCommittedBatch([{ index, result }]);
    }

    async function flush() {
      if (!closed) await resultHandle.sync();
    }

    async function* readInput(startIndex = 0) {
      const input = fs.createReadStream(numbersPath, { encoding: "utf8" });
      const lines = readline.createInterface({ input, crlfDelay: Infinity });
      let index = 0;
      try {
        for await (const line of lines) {
          const number = String(line || "").trim();
          if (!number) continue;
          if (index >= startIndex) yield { index, number };
          index++;
        }
      } finally {
        lines.close();
        input.destroy();
      }
    }

    async function savePause({ cachedResults = new Map(), disconnect = {} } = {}) {
      await flush();
      await fsp.rm(cachedPath, { force: true });
      await fsp.rm(remainingPath, { force: true });

      const cachedEntries = [...cachedResults.entries()]
        .filter(([index]) => Number(index) >= nextIndex)
        .sort((a, b) => a[0] - b[0]);
      await writeLines(
        cachedPath,
        cachedEntries.map(([index, result]) => JSON.stringify({ index, result })),
      );

      const cachedIndexes = new Set(cachedEntries.map(([index]) => Number(index)));
      const remaining = fs.createWriteStream(remainingPath, { flags: "wx", mode: 0o600 });
      try {
        for await (const item of readInput(nextIndex)) {
          if (cachedIndexes.has(item.index)) continue;
          if (!remaining.write(`${item.number}\n`)) {
            await new Promise((resolve) => remaining.once("drain", resolve));
          }
        }
        remaining.end();
        await finished(remaining);
      } catch (error) {
        remaining.destroy();
        throw error;
      }

      const manifest = {
        version: 1,
        ...metadata,
        total: Number(total) || 0,
        nextIndex,
        checkedCount: nextIndex + cachedEntries.length,
        pendingCount: Math.max(0, (Number(total) || 0) - nextIndex - cachedEntries.length),
        disconnect,
        updatedAt: new Date().toISOString(),
        files: {
          numbers: numbersPath,
          results: resultsPath,
          cachedResults: cachedPath,
          remaining: remainingPath,
        },
      };
      await fsp.writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, {
        mode: 0o600,
      });
      return manifest;
    }

    async function clearPauseArtifacts() {
      await Promise.all([
        fsp.rm(cachedPath, { force: true }),
        fsp.rm(remainingPath, { force: true }),
        fsp.rm(manifestPath, { force: true }),
      ]);
    }

    async function* readCheckedResults(cachedResults = new Map()) {
      await flush();
      for await (const entry of readJsonLines(resultsPath)) yield entry;
      for (const [index, result] of [...cachedResults.entries()].sort((a, b) => a[0] - b[0])) {
        if (index >= nextIndex) yield { index, result };
      }
    }

    async function createReport(baseName, titleName, cachedResults = new Map(), options = {}) {
      const report = await createStreamingTxtReport(baseName, titleName, options);
      try {
        for await (const { result } of readCheckedResults(cachedResults)) {
          await report.append(result);
        }
        const finalized = await report.finalize();
        return {
          ...finalized,
          async cleanup() {
            await report.cleanup();
          },
        };
      } catch (error) {
        await report.cleanup().catch(() => {});
        throw error;
      }
    }

    async function createReports(baseName, titleName, cachedResults = new Map(), options = {}) {
      const completeReport = await createStreamingTxtReport(baseName, titleName, options);
      let summaryOnlyReport;
      try {
        summaryOnlyReport = await createStreamingSummaryOnlyReport(baseName, titleName, options);
        for await (const { result } of readCheckedResults(cachedResults)) {
          // Satu pembacaan hasil memberi makan dua writer streaming. Tidak ada
          // query WhatsApp tambahan dan hasil tidak ditumpuk di RAM.
          await completeReport.append(result);
          await summaryOnlyReport.append(result);
        }
        const [complete, summaryOnly] = await Promise.all([
          completeReport.finalize(),
          summaryOnlyReport.finalize(),
        ]);
        return {
          complete,
          summaryOnly,
          summary: complete.summary,
          async cleanup() {
            await Promise.allSettled([
              completeReport.cleanup(),
              summaryOnlyReport.cleanup(),
            ]);
          },
        };
      } catch (error) {
        await Promise.allSettled([
          completeReport.cleanup(),
          summaryOnlyReport?.cleanup(),
        ]);
        throw error;
      }
    }

    async function cleanup() {
      if (!closed) {
        closed = true;
        await resultHandle.close().catch(() => {});
      }
      await fsp.rm(tempDir, { recursive: true, force: true });
    }

    return {
      tempDir,
      numbersPath,
      resultsPath,
      cachedPath,
      remainingPath,
      manifestPath,
      total: Number(total) || 0,
      metadata,
      get nextIndex() {
        return nextIndex;
      },
      appendCommitted,
      appendCommittedBatch,
      flush,
      readInput,
      savePause,
      clearPauseArtifacts,
      readCheckedResults,
      createReport,
      createReports,
      cleanup,
    };
  } catch (error) {
    await fsp.rm(tempDir, { recursive: true, force: true });
    throw error;
  }
}

module.exports = { createCheckState };
