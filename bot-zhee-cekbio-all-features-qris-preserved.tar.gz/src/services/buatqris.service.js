const crypto = require('node:crypto');

async function postForm(baseUrl, fields, { timeoutMs = 30000 } = {}) {
  const body = new URLSearchParams();
  for (const [key, value] of Object.entries(fields)) body.set(key, String(value));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(String(baseUrl).replace(/\/+$/, ''), {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
      signal: controller.signal,
    });
    const text = await response.text();
    let data;
    try { data = JSON.parse(text); } catch { throw new Error(`Respons BuatQris bukan JSON (HTTP ${response.status}).`); }
    if (!response.ok || data?.success === false) {
      const error = new Error(data?.message || `BuatQris HTTP ${response.status}`);
      error.status = response.status;
      error.data = data;
      throw error;
    }
    return data;
  } finally {
    clearTimeout(timer);
  }
}

function createBuatQrisClient({ baseUrl, accountId, secretToken }) {
  if (!baseUrl || !accountId || !secretToken) throw new Error('Konfigurasi BuatQris belum lengkap.');
  return {
    createQris: (amount, description) => postForm(baseUrl, {
      action: 'api_create_qris', account_id: accountId, secret_token: secretToken,
      amount: Math.floor(Number(amount)), description: String(description || 'Pembayaran ZHEE'), fee_by: 'user',
    }),
    checkStatus: (transactionId) => postForm(baseUrl, {
      action: 'api_check_status', account_id: accountId, secret_token: secretToken, transaction_id: transactionId,
    }),
  };
}

function verifyWebhookSignature(rawBody, signature, signingSecret) {
  const expected = 'sha256=' + crypto.createHmac('sha256', String(signingSecret || '')).update(rawBody).digest('hex');
  const a = Buffer.from(expected);
  const b = Buffer.from(String(signature || ''));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

module.exports = { postForm, createBuatQrisClient, verifyWebhookSignature };
