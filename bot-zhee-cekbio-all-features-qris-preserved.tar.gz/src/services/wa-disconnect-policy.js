function isTerminalSessionDisconnect({ stopRequested, authState, shouldReconnect }) {
  return (
    stopRequested !== true &&
    authState === "registered-auth" &&
    shouldReconnect === false
  );
}

module.exports = { isTerminalSessionDisconnect };
