const { abortableDelay } = require("../utils/abort");

class WaSessionDisconnectedError extends Error {
  constructor(meta = {}) {
    super("Sesi WhatsApp terputus saat pengecekan berlangsung.");
    this.name = "WaSessionDisconnectedError";
    this.code = "WA_SESSION_DISCONNECTED";
    this.meta = meta;
  }
}

function createCombinedAbortSignal(signals) {
  const controller = new AbortController();
  const listeners = [];
  const abortFrom = (signal) => {
    if (!controller.signal.aborted) {
      controller.abort(signal.reason || new DOMException("Operasi dibatalkan.", "AbortError"));
    }
  };

  for (const signal of signals.filter(Boolean)) {
    if (signal.aborted) {
      abortFrom(signal);
      break;
    }
    const listener = () => abortFrom(signal);
    signal.addEventListener("abort", listener, { once: true });
    listeners.push([signal, listener]);
  }

  return {
    signal: controller.signal,
    cleanup() {
      for (const [signal, listener] of listeners) signal.removeEventListener("abort", listener);
    },
  };
}

async function runResumableChecks({
  userId,
  state,
  startIndex = state.nextIndex,
  cachedResults = new Map(),
  concurrency,
  delayMs,
  jobSignal,
  sessionSignal,
  checkNumber,
  onProgress,
}) {
  const activeTasks = new Set();
  const completed = new Map();
  let nextToCommit = startIndex;
  let interrupted = false;
  let interruptionMeta = null;
  let primaryError = null;
  let flushQueue = Promise.resolve();

  function queueFlush() {
    flushQueue = flushQueue.then(async () => {
      const commitBatch = [];
      while (completed.has(nextToCommit)) {
        const entry = completed.get(nextToCommit);
        if (entry.interrupted) break;
        completed.delete(nextToCommit);
        cachedResults.delete(nextToCommit);
        commitBatch.push({ index: nextToCommit, result: entry.result });
        nextToCommit++;
      }

      if (!commitBatch.length) return;
      if (typeof state.appendCommittedBatch === "function") {
        await state.appendCommittedBatch(commitBatch);
      } else {
        // Compatibility untuk state mock/adapter lama.
        for (const entry of commitBatch) {
          await state.appendCommitted(entry.index, entry.result);
        }
      }
      // UI progress cukup menerima posisi commit terbaru; panel sendiri sudah
      // throttled. Ini menghindari callback per nomor saat batch selesai rapat.
      await onProgress?.(nextToCommit);
    });
    return flushQueue;
  }

  async function execute(item) {
    if (cachedResults.has(item.index)) {
      completed.set(item.index, { result: cachedResults.get(item.index) });
      await queueFlush();
      return;
    }

    const combined = createCombinedAbortSignal([jobSignal, sessionSignal]);
    try {
      const result = await checkNumber(userId, item.number, { signal: combined.signal });
      combined.signal.throwIfAborted();
      completed.set(item.index, { result });
      await queueFlush();
      await abortableDelay(delayMs, combined.signal);
    } catch (error) {
      if (jobSignal?.aborted) throw jobSignal.reason || error;
      if (
        sessionSignal?.aborted ||
        error?.code === "WA_SESSION_DISCONNECTED" ||
        error?.code === "NO_READY_SENDER"
      ) {
        interrupted = true;
        interruptionMeta =
          error?.code === "NO_READY_SENDER"
            ? {
                source: "sender_pool",
                code: error.code,
                attemptedSenderIds: Array.isArray(error.attemptedSenderIds)
                  ? [...error.attemptedSenderIds]
                  : [],
              }
            : interruptionMeta;
        completed.set(item.index, { interrupted: true });
        return;
      }
      throw error;
    } finally {
      combined.cleanup();
    }
  }

  try {
    for await (const item of state.readInput(startIndex)) {
      jobSignal?.throwIfAborted();
      if (sessionSignal?.aborted || interrupted) break;
      let task;
      task = execute(item).finally(() => activeTasks.delete(task));
      activeTasks.add(task);
      if (activeTasks.size >= Math.max(1, concurrency)) await Promise.race(activeTasks);
      if (interrupted) break;
    }
    await Promise.all(activeTasks);
    await flushQueue;
  } catch (error) {
    primaryError = error;
  } finally {
    await Promise.allSettled([...activeTasks]);
    await flushQueue.catch(() => {});
  }

  if (primaryError) throw primaryError;

  if (interrupted || sessionSignal?.aborted) {
    for (const [index, entry] of completed.entries()) {
      if (!entry.interrupted && entry.result && index >= nextToCommit) {
        cachedResults.set(index, entry.result);
      }
    }
    return {
      paused: true,
      nextIndex: nextToCommit,
      cachedResults,
      disconnect:
        interruptionMeta ||
        (sessionSignal?.reason instanceof WaSessionDisconnectedError
          ? sessionSignal.reason.meta
          : {}),
    };
  }

  return {
    paused: false,
    nextIndex: nextToCommit,
    cachedResults,
  };
}

module.exports = {
  WaSessionDisconnectedError,
  createCombinedAbortSignal,
  runResumableChecks,
};
