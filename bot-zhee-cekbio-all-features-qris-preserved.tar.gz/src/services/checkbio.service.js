const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const readline = require("node:readline");
const { Readable } = require("node:stream");
const { once } = require("node:events");
const { finished, pipeline } = require("node:stream/promises");
const { abortableDelay, createOperationSignal } = require("../utils/abort");
const { createTempWorkspace } = require("./temp-dir.service");

class NumberLimitError extends Error {
  constructor(limit) {
    super(`Jumlah nomor melebihi batas ${limit}.`);
    this.name = "NumberLimitError";
    this.code = "NUMBER_LIMIT_EXCEEDED";
    this.limit = limit;
  }
}

class TelegramFileDownloadError extends Error {
  constructor(message, { cause, attempts } = {}) {
    super(message, { cause });
    this.name = "TelegramFileDownloadError";
    this.code = "TELEGRAM_FILE_DOWNLOAD_FAILED";
    this.attempts = attempts;
  }
}

function getErrorChain(error, maxDepth = 6) {
  const chain = [];
  const seen = new Set();
  let current = error;

  while (current && chain.length < maxDepth && !seen.has(current)) {
    chain.push(current);
    seen.add(current);
    current = current.cause;
  }

  return chain;
}

function formatTelegramDownloadError(error) {
  return getErrorChain(error)
    .flatMap((item) => [item?.name, item?.code, item?.errno, item?.message])
    .filter(Boolean)
    .map(String)
    .filter((value, index, values) => values.indexOf(value) === index)
    .join(" | ");
}

function isTransientTelegramDownloadError(error) {
  const chain = getErrorChain(error);
  const codes = chain
    .flatMap((item) => [item?.code, item?.errno])
    .filter(Boolean)
    .map((value) => String(value).toUpperCase());
  const statuses = chain
    .flatMap((item) => [item?.status, item?.statusCode, item?.response?.status])
    .map(Number)
    .filter(Number.isFinite);
  const text = formatTelegramDownloadError(error);

  if (statuses.some((status) => [408, 425, 429, 500, 502, 503, 504].includes(status))) {
    return true;
  }

  if (
    codes.some((code) =>
      [
        "ECONNRESET",
        "ETIMEDOUT",
        "EPIPE",
        "ENETUNREACH",
        "EHOSTUNREACH",
        "EAI_AGAIN",
        "ECONNREFUSED",
        "UND_ERR_CONNECT_TIMEOUT",
        "UND_ERR_HEADERS_TIMEOUT",
        "UND_ERR_BODY_TIMEOUT",
        "UND_ERR_SOCKET",
      ].includes(code),
    )
  ) {
    return true;
  }

  return /(connect timeout|socket hang up|network timeout|fetch failed|aborted|terminated|timeout|temporarily unavailable|connection reset|other side closed)/i.test(
    text,
  );
}

function getDownloadRetryDelayMs(attempt, retryBaseMs) {
  return Math.min(Math.max(0, retryBaseMs) * 2 ** Math.max(0, attempt - 1), 30000);
}

async function writeWithBackpressure(stream, content) {
  if (stream.write(content)) return;
  await once(stream, "drain");
}

async function downloadTelegramFileToTemp({
  fileUrl,
  signal,
  timeoutMs = 60000,
  maxAttempts = 4,
  retryBaseMs = 1000,
  fetchImpl = globalThis.fetch,
  tempDir,
  onRetry,
}) {
  if (typeof fetchImpl !== "function") {
    throw new TypeError("fetch tidak tersedia untuk download file Telegram.");
  }

  const attempts = Math.max(1, Number(maxAttempts) || 1);
  const attemptTimeoutMs = Math.max(1, Number(timeoutMs) || 60000);
  const tempWorkspace = await createTempWorkspace("cekbio-input-", { tempDir });
  const filePath = path.join(tempWorkspace, "numbers.txt");
  let lastError;
  let attemptsUsed = 0;

  try {
    for (let attempt = 1; attempt <= attempts; attempt++) {
      attemptsUsed = attempt;
      signal?.throwIfAborted();
      await fsp.rm(filePath, { force: true });
      const operation = createOperationSignal(
        signal,
        attemptTimeoutMs,
        "download file Telegram",
      );

      try {
        const response = await fetchImpl(fileUrl, { signal: operation.signal });
        if (!response?.ok || !response.body) {
          const status = Number(response?.status || 0);
          const error = new Error(
            `Gagal download file Telegram: HTTP ${status || "unknown"}`,
          );
          error.name = "TelegramFileHttpError";
          error.code = status ? `HTTP_${status}` : "TELEGRAM_FILE_HTTP_ERROR";
          error.status = status;
          throw error;
        }

        const destination = fs.createWriteStream(filePath, {
          flags: "wx",
          mode: 0o600,
        });
        await pipeline(Readable.fromWeb(response.body), destination, {
          signal: operation.signal,
        });

        let cleaned = false;
        return {
          filePath,
          async cleanup() {
            if (cleaned) return;
            cleaned = true;
            await fsp.rm(tempWorkspace, { recursive: true, force: true });
          },
        };
      } catch (error) {
        if (signal?.aborted) throw signal.reason || error;

        const effectiveError =
          operation.signal.aborted && operation.signal.reason?.name === "TimeoutError"
            ? operation.signal.reason
            : error;
        lastError = effectiveError;
        await fsp.rm(filePath, { force: true }).catch(() => {});

        const retryable = isTransientTelegramDownloadError(effectiveError);
        if (!retryable || attempt >= attempts) break;

        const delayMs = getDownloadRetryDelayMs(attempt, retryBaseMs);
        try {
          onRetry?.({
            attempt,
            nextAttempt: attempt + 1,
            maxAttempts: attempts,
            delayMs,
            error: effectiveError,
          });
        } catch {
          // Logging/telemetry must not block the retry path.
        }
        operation.dispose();
        await abortableDelay(delayMs, signal);
      } finally {
        operation.dispose();
      }
    }

    throw new TelegramFileDownloadError(
      `Gagal mengunduh file Telegram setelah ${attemptsUsed} percobaan: ${formatTelegramDownloadError(lastError) || "alasan tidak diketahui"}`,
      { cause: lastError, attempts: attemptsUsed },
    );
  } catch (error) {
    await fsp.rm(tempWorkspace, { recursive: true, force: true });
    throw error;
  }
}

async function normalizeNumberFile(inputPath, outputPath, { limit, signal, normalizeNumber }) {
  const input = fs.createReadStream(inputPath, { encoding: "utf8" });
  const lines = readline.createInterface({ input, crlfDelay: Infinity });
  const output = fs.createWriteStream(outputPath, { flags: "wx", mode: 0o600 });
  const seen = new Set();
  let count = 0;

  try {
    for await (const line of lines) {
      signal?.throwIfAborted();
      for (const token of String(line).split(/[\s,;|\t]+/).map((item) => item.trim()).filter(Boolean)) {
        const number = normalizeNumber(token);
        if (!number || seen.has(number)) continue;
        seen.add(number);
        count++;
        if (count > limit) throw new NumberLimitError(limit);
        await writeWithBackpressure(output, `${number}\n`);
      }
    }
    output.end();
    await finished(output);
    return { filePath: outputPath, count };
  } catch (error) {
    output.destroy();
    await fsp.rm(outputPath, { force: true });
    throw error;
  } finally {
    lines.close();
    input.destroy();
  }
}

module.exports = {
  NumberLimitError,
  TelegramFileDownloadError,
  downloadTelegramFileToTemp,
  formatTelegramDownloadError,
  isTransientTelegramDownloadError,
  normalizeNumberFile,
};
