const crypto = require("node:crypto");

const SENDER_HEALTH = Object.freeze({
  READY: "ready",
  BUSY: "busy",
  RECONNECTING: "reconnecting",
  DEAD: "dead",
});

function normalizeUserId(userId) {
  const value = String(userId ?? "").trim();
  if (!/^\d+$/.test(value)) throw new Error("Telegram user id tidak valid.");
  return value;
}

function normalizeSenderId(senderId) {
  const value = String(senderId ?? "").trim();
  if (!/^[A-Za-z0-9_-]{1,64}$/.test(value)) {
    throw new Error("Sender id tidak valid.");
  }
  return value;
}

function senderKey(userId, senderId) {
  return `${normalizeUserId(userId)}:${normalizeSenderId(senderId)}`;
}

function toPositiveInteger(value, fallback = 1) {
  const parsed = Number.parseInt(String(value ?? ""), 10);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

/**
 * Sender Pool adalah lapisan scheduler-ready di atas runtime Baileys.
 *
 * Tahap 4 belum mengarahkan /cekbio ke pool ini. Pool hanya bertugas:
 * - membaca health setiap Sender secara independen;
 * - mengecualikan Sender yang reconnect/dead dari kandidat kerja;
 * - menyimpan load/lease per Sender;
 * - memilih Sender paling ringan secara fair ketika tahap berikutnya mulai
 *   mendistribusikan pekerjaan.
 */
function createSenderPool({
  getSenderSnapshots,
  getSenderConnectivityState = null,
  maxActivePerSender = 1,
  now = () => Date.now(),
  createLeaseId = () => crypto.randomUUID(),
} = {}) {
  if (typeof getSenderSnapshots !== "function") {
    throw new TypeError("getSenderSnapshots wajib berupa fungsi.");
  }

  const defaultCapacity = toPositiveInteger(maxActivePerSender, 1);
  const leases = new Map();
  const senderLeaseIds = new Map();
  const assignmentOrder = new Map();
  let assignmentSequence = 0;

  function getLeaseSet(userId, senderId, create = false) {
    const key = senderKey(userId, senderId);
    let ids = senderLeaseIds.get(key);
    if (!ids && create) {
      ids = new Set();
      senderLeaseIds.set(key, ids);
    }
    return ids || null;
  }

  function getActiveCount(userId, senderId) {
    return getLeaseSet(userId, senderId)?.size || 0;
  }

  function resolveConnectivityState(userId, sender) {
    const declared = String(sender?.connectivityState || "").trim().toLowerCase();
    if (["ready", "reconnecting", "dead"].includes(declared)) return declared;
    if (typeof getSenderConnectivityState === "function") {
      try {
        const resolved = String(
          getSenderConnectivityState(userId, sender?.senderId),
        ).trim().toLowerCase();
        if (["ready", "reconnecting", "dead"].includes(resolved)) return resolved;
      } catch {
        // Snapshot tetap bisa dinilai dari connected/ready bila runtime baru hilang.
      }
    }
    if (sender?.connected === true && sender?.ready === true) return "ready";
    if (sender?.connected === true) return "reconnecting";
    return "dead";
  }

  function decorateSender(userId, sender, { capacityOverride = null } = {}) {
    const senderId = normalizeSenderId(sender?.senderId || "default");
    const activeTasks = getActiveCount(userId, senderId);
    const capacity = capacityOverride == null
      ? toPositiveInteger(sender?.capacity, defaultCapacity)
      : toPositiveInteger(capacityOverride, defaultCapacity);
    const connectivityState = resolveConnectivityState(userId, {
      ...sender,
      senderId,
    });
    const socketReady =
      sender?.connected === true &&
      (sender?.ready === true || connectivityState === "ready");
    let health = SENDER_HEALTH.DEAD;
    if (socketReady) {
      health = activeTasks >= capacity ? SENDER_HEALTH.BUSY : SENDER_HEALTH.READY;
    } else if (
      connectivityState === "reconnecting" ||
      sender?.connected === true
    ) {
      health = SENDER_HEALTH.RECONNECTING;
    }
    const availableSlots = socketReady
      ? Math.max(0, capacity - activeTasks)
      : 0;

    return {
      ...sender,
      senderId,
      connectivityState,
      health,
      activeTasks,
      capacity,
      availableSlots,
      schedulerEligible: availableSlots > 0,
    };
  }

  function getSnapshot(userId, { capacityOverride = null } = {}) {
    const safeUserId = normalizeUserId(userId);
    const raw = getSenderSnapshots(safeUserId);
    const source = Array.isArray(raw) ? raw : [];
    const senders = source
      .filter(Boolean)
      .map((sender) => decorateSender(safeUserId, sender, { capacityOverride }));

    const knownKeys = new Set(
      senders.map((sender) => senderKey(safeUserId, sender.senderId)),
    );
    // Load tanpa Sender runtime/auth tidak boleh memengaruhi pool selamanya.
    // Tahap 10: bila Sender benar-benar dihapus ketika masih memegang lease,
    // lease orphan juga dibersihkan. Task yang sedang berjalan tetap aman:
    // release() pada finally menjadi no-op bila lease sudah dipruning.
    for (const key of [...senderLeaseIds.keys()]) {
      if (!key.startsWith(`${safeUserId}:`) || knownKeys.has(key)) continue;
      const ids = [...(senderLeaseIds.get(key) || [])];
      for (const leaseId of ids) release(leaseId);
      senderLeaseIds.delete(key);
      assignmentOrder.delete(key);
    }

    const count = (health) => senders.filter((sender) => sender.health === health).length;
    return {
      userId: safeUserId,
      total: senders.length,
      ready: count(SENDER_HEALTH.READY),
      busy: count(SENDER_HEALTH.BUSY),
      reconnecting: count(SENDER_HEALTH.RECONNECTING),
      dead: count(SENDER_HEALTH.DEAD),
      available: senders.filter((sender) => sender.schedulerEligible).length,
      activeTasks: senders.reduce((sum, sender) => sum + sender.activeTasks, 0),
      senders,
    };
  }

  function normalizeExcludedSenderIds(values = []) {
    const source = Array.isArray(values) ? values : [values];
    return new Set(
      source
        .filter((value) => value !== undefined && value !== null && String(value).trim())
        .map((value) => normalizeSenderId(value)),
    );
  }

  function listAvailable(
    userId,
    { excludeSenderIds = [], capacityOverride = null } = {},
  ) {
    const excluded = normalizeExcludedSenderIds(excludeSenderIds);
    return getSnapshot(userId, { capacityOverride }).senders.filter(
      (sender) => sender.schedulerEligible && !excluded.has(sender.senderId),
    );
  }

  function selectCandidate(userId, options = {}) {
    const candidates = listAvailable(userId, options);
    if (!candidates.length) return null;
    candidates.sort((a, b) => {
      if (a.activeTasks !== b.activeTasks) return a.activeTasks - b.activeTasks;
      const aOrder = assignmentOrder.get(senderKey(userId, a.senderId)) || 0;
      const bOrder = assignmentOrder.get(senderKey(userId, b.senderId)) || 0;
      if (aOrder !== bOrder) return aOrder - bOrder;
      if (a.senderId === "default") return -1;
      if (b.senderId === "default") return 1;
      return a.senderId.localeCompare(b.senderId);
    });
    return candidates[0];
  }

  function acquire(
    userId,
    meta = {},
    { excludeSenderIds = [], capacityOverride = null } = {},
  ) {
    const safeUserId = normalizeUserId(userId);
    const candidate = selectCandidate(safeUserId, {
      excludeSenderIds,
      capacityOverride,
    });
    if (!candidate) return null;

    const leaseId = String(createLeaseId());
    if (!leaseId || leases.has(leaseId)) {
      throw new Error("Gagal membuat lease Sender yang unik.");
    }
    const acquiredAt = Number(now()) || Date.now();
    const lease = {
      leaseId,
      userId: safeUserId,
      senderId: candidate.senderId,
      acquiredAt,
      meta: meta && typeof meta === "object" ? { ...meta } : {},
    };
    leases.set(leaseId, lease);
    getLeaseSet(safeUserId, candidate.senderId, true).add(leaseId);
    assignmentOrder.set(
      senderKey(safeUserId, candidate.senderId),
      ++assignmentSequence,
    );
    return { ...lease };
  }

  function release(leaseOrId) {
    const leaseId = String(
      typeof leaseOrId === "object" && leaseOrId
        ? leaseOrId.leaseId || ""
        : leaseOrId || "",
    );
    if (!leaseId) return false;
    const lease = leases.get(leaseId);
    if (!lease) return false;
    leases.delete(leaseId);
    const key = senderKey(lease.userId, lease.senderId);
    const ids = senderLeaseIds.get(key);
    ids?.delete(leaseId);
    if (ids?.size === 0) senderLeaseIds.delete(key);
    return true;
  }

  function releaseSender(userId, senderId) {
    const safeUserId = normalizeUserId(userId);
    const safeSenderId = normalizeSenderId(senderId);
    const ids = [...(getLeaseSet(safeUserId, safeSenderId) || [])];
    for (const leaseId of ids) release(leaseId);
    return ids.length;
  }

  function releaseUser(userId) {
    const safeUserId = normalizeUserId(userId);
    let released = 0;
    for (const lease of [...leases.values()]) {
      if (lease.userId !== safeUserId) continue;
      if (release(lease.leaseId)) released += 1;
    }
    return released;
  }

  function getLease(leaseId) {
    const lease = leases.get(String(leaseId || ""));
    return lease ? { ...lease, meta: { ...lease.meta } } : null;
  }

  return Object.freeze({
    getSnapshot,
    listAvailable,
    acquire,
    release,
    releaseSender,
    releaseUser,
    getLease,
  });
}

module.exports = {
  SENDER_HEALTH,
  createSenderPool,
};
