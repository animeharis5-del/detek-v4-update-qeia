function isPausedReconnectEligible(job) {
  return Boolean(
    job &&
      job.status === "paused" &&
      job.pauseContext &&
      !job.finalizationInProgress &&
      !job.sendConfirmationPending &&
      !job.controller?.signal?.aborted,
  );
}

function callUnsubscribe(unsubscribe) {
  if (typeof unsubscribe !== "function") return;
  try {
    unsubscribe();
  } catch {
    // Listener cleanup must never break job cleanup/finalization.
  }
}

function clearPausedReconnectWait(job, { preserveClaim = false } = {}) {
  if (!job) return false;
  job.reconnectResumeArmId = Number(job.reconnectResumeArmId || 0) + 1;
  job.awaitingReconnectResume = false;
  job.reconnectResumeInFlight = false;
  if (!preserveClaim) job.reconnectResumeClaimed = false;

  callUnsubscribe(job.reconnectConnectivityUnsubscribe);
  callUnsubscribe(job.reconnectReadyUnsubscribe);

  job.reconnectConnectivityUnsubscribe = null;
  job.reconnectReadyUnsubscribe = null;
  return true;
}

function normalizeConnectivityState(value) {
  const state = String(value?.state || value?.status || value || "").toLowerCase();
  if (state === "ready" || state === "reconnecting" || state === "dead") {
    return state;
  }
  return "reconnecting";
}

function armPausedReconnectWait(
  job,
  {
    userId,
    subscribeConnectivity,
    subscribeReady,
    getConnectivityState,
    isReady,
    claimResume,
    onReady,
    onDisconnected = async () => {},
    onError = () => {},
  } = {},
) {
  if (!isPausedReconnectEligible(job)) return false;
  if (typeof subscribeConnectivity !== "function") {
    throw new TypeError("subscribeConnectivity wajib berupa fungsi.");
  }
  if (typeof subscribeReady !== "function") {
    throw new TypeError("subscribeReady wajib berupa fungsi.");
  }
  if (typeof getConnectivityState !== "function") {
    throw new TypeError("getConnectivityState wajib berupa fungsi.");
  }
  if (typeof isReady !== "function") {
    throw new TypeError("isReady wajib berupa fungsi.");
  }
  if (typeof claimResume !== "function") {
    throw new TypeError("claimResume wajib berupa fungsi.");
  }
  if (typeof onReady !== "function") {
    throw new TypeError("onReady wajib berupa fungsi.");
  }

  clearPausedReconnectWait(job);
  job.awaitingReconnectResume = true;
  job.reconnectResumeClaimed = false;
  const armId = Number(job.reconnectResumeArmId || 0);
  let connectivityGeneration = 0;
  let attemptInFlight = false;
  let disconnectedPanelInFlight = false;

  const isActive = () =>
    job.awaitingReconnectResume === true &&
    Number(job.reconnectResumeArmId || 0) === armId &&
    isPausedReconnectEligible(job);

  const reportError = (error) => {
    try {
      onError(error);
    } catch {
      // Error reporting is best effort only.
    }
  };

  const showDisconnected = () => {
    if (!isActive() || disconnectedPanelInFlight) return;
    disconnectedPanelInFlight = true;
    Promise.resolve(onDisconnected(job))
      .catch(reportError)
      .finally(() => {
        disconnectedPanelInFlight = false;
      });
  };

  const attemptResume = () => {
    if (!isActive() || attemptInFlight || job.reconnectResumeClaimed) return;
    attemptInFlight = true;
    job.reconnectResumeInFlight = true;
    const generation = connectivityGeneration;

    Promise.resolve()
      .then(async () => {
        if (!isActive()) return;
        if (
          generation !== connectivityGeneration ||
          normalizeConnectivityState(getConnectivityState(userId)) !== "ready" ||
          !isReady(userId)
        ) {
          return;
        }

        // claimResume must set the single-flight claim before the runner is
        // awakened. A second ready event can therefore never start a second
        // resume for the same paused job.
        if (!claimResume(job)) return;
        job.reconnectResumeClaimed = true;

        // The reconnect intent has now been claimed exactly once. Remove both
        // listeners before handing control back to the paused runner.
        clearPausedReconnectWait(job, { preserveClaim: true });
        await onReady(job);
      })
      .catch(reportError)
      .finally(() => {
        attemptInFlight = false;
        if (Number(job.reconnectResumeArmId || 0) === armId) {
          job.reconnectResumeInFlight = false;
        }
      });
  };

  const connectivityListener = (event = {}) => {
    if (!isActive()) return;
    const state = normalizeConnectivityState(event);
    if (state === "ready") return;

    // Any transition away from application-ready invalidates a ready attempt
    // that has not claimed the paused runner yet.
    connectivityGeneration += 1;
    attemptInFlight = false;
    job.reconnectResumeInFlight = false;

    if (state === "dead") showDisconnected();
    // reconnecting deliberately leaves the existing paused card untouched.
  };

  const readyListener = (event = {}) => {
    if (!isActive()) return;
    if (event.ready === true || event.status === "ready") attemptResume();
  };

  const unsubscribeConnectivity = subscribeConnectivity(
    userId,
    connectivityListener,
  );
  const unsubscribeReady = subscribeReady(userId, readyListener);
  job.reconnectConnectivityUnsubscribe =
    typeof unsubscribeConnectivity === "function" ? unsubscribeConnectivity : null;
  job.reconnectReadyUnsubscribe =
    typeof unsubscribeReady === "function" ? unsubscribeReady : null;

  // Cover races where terminal/ready status was published just before the
  // listeners were attached. Raw socket open is never treated as ready.
  const currentState = normalizeConnectivityState(getConnectivityState(userId));
  if (currentState === "ready" && isReady(userId)) attemptResume();
  else if (currentState === "dead") showDisconnected();
  return true;
}

module.exports = {
  armPausedReconnectWait,
  clearPausedReconnectWait,
};
