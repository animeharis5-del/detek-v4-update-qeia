const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const { chmodBestEffort } = require("./file-permissions.service");

const PROJECT_ROOT = path.resolve(__dirname, "../..");
const DEFAULT_TEMP_DIR = "./tmp";

function resolveTempDirPath(
  value = process.env.TEMP_DIR,
  { pathApi = path, projectRoot = PROJECT_ROOT } = {},
) {
  const configured = String(value || DEFAULT_TEMP_DIR).trim() || DEFAULT_TEMP_DIR;
  return pathApi.isAbsolute(configured)
    ? pathApi.normalize(configured)
    : pathApi.resolve(projectRoot, configured);
}

function formatFsError(error) {
  const code = String(error?.code || "UNKNOWN");
  const message = String(error?.message || error || "unknown filesystem error");
  return `${code}: ${message}`;
}

function createTempDirError(tempDir, error) {
  const wrapped = new Error(
    `TEMP_DIR tidak dapat digunakan: ${tempDir} (${formatFsError(error)})`,
  );
  wrapped.name = "TempDirError";
  wrapped.code = "TEMP_DIR_UNWRITABLE";
  wrapped.path = tempDir;
  wrapped.cause = error;
  return wrapped;
}

async function ensureTempDirWritable(
  tempDir = resolveTempDirPath(),
  { logger = console } = {},
) {
  const resolved = path.resolve(tempDir);
  let probePath = "";
  try {
    await fsp.mkdir(resolved, { recursive: true, mode: 0o700 });
    await chmodBestEffort(resolved, 0o700);
    await fsp.access(resolved, fs.constants.R_OK | fs.constants.W_OK);

    probePath = path.join(
      resolved,
      `.cekbio-write-test-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    );
    const handle = await fsp.open(probePath, "wx", 0o600);
    try {
      await handle.writeFile("ok", "utf8");
      await handle.sync();
    } finally {
      await handle.close();
    }
    await fsp.readFile(probePath, "utf8");
    await fsp.rm(probePath, { force: true });
    return resolved;
  } catch (error) {
    if (probePath) await fsp.rm(probePath, { force: true }).catch(() => {});
    const wrapped = createTempDirError(resolved, error);
    logger?.error?.(`[ERROR][SYSTEM][TEMP_DIR] ${wrapped.message}`);
    throw wrapped;
  }
}

async function createTempWorkspace(prefix, { tempDir = resolveTempDirPath() } = {}) {
  const root = await ensureTempDirWritable(tempDir);
  const safePrefix = String(prefix || "cekbio-").replace(/[^A-Za-z0-9._-]/g, "-");
  const workspace = await fsp.mkdtemp(path.join(root, safePrefix));
  await chmodBestEffort(workspace, 0o700);
  return workspace;
}

function createReadableFileError(filePath, error) {
  const wrapped = new Error(
    `File lokal tidak dapat dibaca: ${filePath} (${formatFsError(error)})`,
  );
  wrapped.name = "LocalFileReadError";
  wrapped.code = "LOCAL_FILE_UNREADABLE";
  wrapped.path = filePath;
  wrapped.cause = error;
  return wrapped;
}

async function assertReadableFile(filePath) {
  const resolved = path.resolve(String(filePath || ""));
  try {
    if (!filePath) {
      const error = new Error("path file kosong");
      error.code = "EINVAL";
      throw error;
    }
    const stat = await fsp.stat(resolved);
    if (!stat.isFile()) {
      const error = new Error("path bukan file biasa");
      error.code = "EISDIR";
      throw error;
    }
    await fsp.access(resolved, fs.constants.R_OK);
    const handle = await fsp.open(resolved, "r");
    await handle.close();
    return { filePath: resolved, size: stat.size };
  } catch (error) {
    throw createReadableFileError(resolved, error);
  }
}

module.exports = {
  DEFAULT_TEMP_DIR,
  PROJECT_ROOT,
  assertReadableFile,
  createTempWorkspace,
  ensureTempDirWritable,
  resolveTempDirPath,
};
