async function deliverReportFilesIndependently({ files, sendFile, onFileFailure = () => {} }) {
  if (!Array.isArray(files) || files.length === 0) {
    throw new TypeError("Daftar file laporan tidak boleh kosong.");
  }
  if (typeof sendFile !== "function") {
    throw new TypeError("sendFile wajib berupa fungsi.");
  }

  const sent = [];
  const failed = [];
  for (const file of files) {
    try {
      await sendFile(file);
      sent.push(file);
    } catch (error) {
      failed.push({ file, error });
      await Promise.resolve(onFileFailure(file, error)).catch(() => {});
    }
  }

  if (sent.length === 0) {
    const error = new AggregateError(
      failed.map((entry) => entry.error),
      "Semua file laporan gagal dikirim.",
    );
    error.failures = failed;
    throw error;
  }

  return { sent, failed };
}

async function createAndDeliverReportPair({
  state,
  baseName,
  titleName = "MOCI",
  cachedResults = new Map(),
  sendFile,
  onFileFailure,
  format = null,
  buildCaption = null,
  sourceName = "",
}) {
  if (!state || typeof state.createReports !== "function") {
    throw new TypeError("State laporan tidak mendukung createReports().");
  }

  const reports = await state.createReports(baseName, titleName, cachedResults, { sourceName });
  try {
    const allFiles = [
      { kind: "complete", filePath: reports.complete.filePath },
      { kind: "summary", filePath: reports.summaryOnly.filePath },
    ];
    // format "detail" -> hanya file lengkap; "simple" -> hanya ringkas;
    // null/lainnya -> kirim keduanya (perilaku lama).
    const files =
      format === "detail"
        ? allFiles.filter((f) => f.kind === "complete")
        : format === "simple"
          ? allFiles.filter((f) => f.kind === "summary")
          : allFiles;
    // Sisipkan keterangan (ringkasan) sebagai caption pada file PERTAMA
    // agar menyatu dengan file, bukan pesan terpisah.
    if (typeof buildCaption === "function" && files.length > 0) {
      try {
        const caption = buildCaption(reports.summary);
        if (caption) files[0] = { ...files[0], caption };
      } catch {
        // caption gagal dibangun -> lanjut tanpa caption.
      }
    }
    const delivery = await deliverReportFilesIndependently({
      files,
      sendFile,
      onFileFailure,
    });
    return { summary: reports.summary, delivery };
  } catch (error) {
    error.reportSummary = reports.summary;
    throw error;
  } finally {
    await reports.cleanup().catch(() => {});
  }
}

module.exports = {
  createAndDeliverReportPair,
  deliverReportFilesIndependently,
};
