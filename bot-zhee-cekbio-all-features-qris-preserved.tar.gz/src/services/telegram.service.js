const { abortableDelay, createOperationSignal } = require("../utils/abort");

function normalizeReplyMarkupValue(value) {
  if (Array.isArray(value)) return value.map(normalizeReplyMarkupValue);
  if (!value || typeof value !== "object") return value;

  return Object.fromEntries(
    Object.keys(value)
      .sort()
      .filter((key) => value[key] !== undefined)
      .map((key) => [key, normalizeReplyMarkupValue(value[key])]),
  );
}

function stableReplyMarkupString(value) {
  return JSON.stringify(normalizeReplyMarkupValue(value ?? null));
}

function decodeHtmlEntities(value) {
  return String(value)
    .replace(/&#(\d+);/g, (_match, code) => String.fromCodePoint(Number(code)))
    .replace(/&#x([0-9a-f]+);/gi, (_match, code) =>
      String.fromCodePoint(Number.parseInt(code, 16)),
    )
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&amp;/gi, "&");
}

function htmlToVisibleTelegramText(value) {
  return decodeHtmlEntities(
    String(value)
      .replace(/<br\s*\/?\s*>/gi, "\n")
      .replace(/<[^>]+>/g, ""),
  );
}

function areTelegramMessageContentsEqual(
  currentMessage,
  nextText,
  nextReplyMarkup,
  { parseMode } = {},
) {
  if (!currentMessage) return false;

  const currentText = String(
    currentMessage.text ?? currentMessage.caption ?? "",
  );
  const requestedText = String(nextText ?? "");
  const textMatches =
    currentText === requestedText ||
    (String(parseMode || "").toUpperCase() === "HTML" &&
      currentText === htmlToVisibleTelegramText(requestedText));
  if (!textMatches) return false;

  const currentReplyMarkup =
    currentMessage.reply_markup ?? currentMessage.replyMarkup ?? null;
  return (
    stableReplyMarkupString(currentReplyMarkup) ===
    stableReplyMarkupString(nextReplyMarkup)
  );
}

function getTelegramPanelErrorText(error) {
  return [
    error?.code,
    error?.errno,
    error?.type,
    error?.response?.error_code,
    error?.response?.description,
    error?.message,
  ]
    .filter(Boolean)
    .map(String)
    .join(" | ");
}

function isTelegramPanelUnavailableError(error) {
  const status = Number(
    error?.response?.error_code || error?.statusCode || error?.status || 0,
  );
  const text = getTelegramPanelErrorText(error);
  if (status && status !== 400) return false;
  return /(message to edit not found|message (?:can(?:not| not)|can't) be edited|message to delete not found)/i.test(
    text,
  );
}

async function editOrResendTelegramPanel({
  currentPanel = null,
  editPanel,
  resendPanel,
  discardPanel = null,
  onEditFallback = null,
} = {}) {
  if (currentPanel && typeof editPanel === "function") {
    try {
      const edited = await editPanel(currentPanel);
      return edited || currentPanel;
    } catch (error) {
      if (!isTelegramPanelUnavailableError(error)) throw error;
      try {
        onEditFallback?.(error);
      } catch {
        // Logging/telemetry must never block the UI fallback.
      }
      if (typeof discardPanel === "function") {
        try {
          await discardPanel(currentPanel);
        } catch {
          // Missing/undeletable stale messages are safe to ignore.
        }
      }
    }
  }

  if (typeof resendPanel !== "function") return currentPanel;
  return (await resendPanel()) || currentPanel;
}

function createTelegramRetryService({
  isIgnorableError,
  isRetryableError,
  getErrorMessage,
  getRetryDelayMs,
  onIgnored,
  onRetry,
  onFailure,
}) {
  return async function telegramCallWithRetry(ctxOrUserId, label, fn, options = {}) {
    const maxAttempts = options.maxAttempts || 8;
    const timeoutMs = options.timeoutMs || 180000;
    const parentSignal = options.signal;
    let lastError;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      parentSignal?.throwIfAborted();
      const operation = createOperationSignal(parentSignal, timeoutMs, label);

      try {
        return await fn(operation.signal, attempt);
      } catch (error) {
        lastError = error;
        if (parentSignal?.aborted) throw parentSignal.reason || error;

        if (isIgnorableError(error)) {
          onIgnored?.(ctxOrUserId, label, error);
          return null;
        }

        const timedOut =
          operation.signal.aborted && operation.signal.reason?.name === "TimeoutError";
        const retryable = timedOut || isRetryableError(error);

        if (!retryable || attempt >= maxAttempts) {
          onFailure?.(ctxOrUserId, label, error, attempt);
          throw error;
        }

        let delayMs = getRetryDelayMs(error, attempt);
        const message = getErrorMessage(error) || String(error);
        if (/ECONNRESET|socket hang up/i.test(message)) {
          delayMs = Math.min(delayMs * 3, 45000);
        }

        onRetry?.(ctxOrUserId, label, error, attempt, delayMs);
        await abortableDelay(delayMs, parentSignal);
      } finally {
        operation.dispose();
      }
    }

    throw lastError;
  };
}

module.exports = {
  areTelegramMessageContentsEqual,
  createTelegramRetryService,
  editOrResendTelegramPanel,
  isTelegramPanelUnavailableError,
};
