const fsp = require("node:fs/promises");

function supportsPosixPermissions(platform = process.platform) {
  return platform !== "win32";
}

async function chmodBestEffort(
  targetPath,
  mode,
  { platform = process.platform, chmod = fsp.chmod } = {},
) {
  if (!targetPath || !supportsPosixPermissions(platform)) return false;
  try {
    await chmod(targetPath, mode);
    return true;
  } catch {
    // Windows dan sebagian filesystem tidak menerapkan mode POSIX.
    // Permission hardening tidak boleh membuat bot berhenti.
    return false;
  }
}

function applyPrivateUmask(
  { platform = process.platform, umask = process.umask.bind(process) } = {},
) {
  if (!supportsPosixPermissions(platform)) return false;
  try {
    umask(0o077);
    return true;
  } catch {
    // Beberapa runtime/filesystem tidak mendukung umask secara penuh.
    return false;
  }
}

module.exports = {
  applyPrivateUmask,
  chmodBestEffort,
  supportsPosixPermissions,
};
