class WaCheckError extends Error {
  constructor(message, { code = "WA_CHECK_FAILED", retryable = false, cause } = {}) {
    super(message, { cause });
    this.name = "WaCheckError";
    this.code = code;
    this.retryable = retryable;
  }
}

function getWaQueryErrorMessage(error) {
  return error?.message || error?.output?.payload?.message || String(error);
}

function isTransientWaQueryError(error) {
  const statusCode = error?.output?.statusCode || error?.statusCode || error?.code;
  const message = getWaQueryErrorMessage(error);
  return (
    statusCode === 408 ||
    statusCode === 429 ||
    statusCode === 500 ||
    statusCode === 502 ||
    statusCode === 503 ||
    statusCode === 504 ||
    /timeout|timed out|rate.?limit|too many|ECONNRESET|ETIMEDOUT|EAI_AGAIN|ENOTFOUND|Connection Closed|Connection Terminated|WebSocket Error/i.test(
      message,
    )
  );
}

function isRetryableWaCheckError(error) {
  return error instanceof WaCheckError && error.retryable === true;
}

/**
 * Profile picture/business profile yang tidak tersedia bukan kegagalan cek nomor.
 * Baileys dapat membungkus status HTTP di beberapa bentuk error yang berbeda.
 */
function shouldIgnoreProfileNotFound(error) {
  const statusCode = Number(
    error?.output?.statusCode ??
      error?.statusCode ??
      error?.status ??
      error?.data?.statusCode ??
      error?.cause?.output?.statusCode ??
      error?.cause?.statusCode,
  );

  if ([401, 403, 404].includes(statusCode)) {
    return true;
  }

  const message = getWaQueryErrorMessage(error);

  return /not[ -]?found|item[ -]?not[ -]?found|profile(?: picture)?(?: is)? unavailable|no profile picture|privacy|forbidden|not authorized/i.test(
    message,
  );
}

/**
 * Baileys onWhatsApp() mengembalikan array hasil.
 * Array kosong adalah respons valid yang berarti nomor tidak terdaftar.
 */
function normalizeWaExistsResult(result) {
  if (Array.isArray(result)) {
    if (result.length === 0) {
      return { exists: false };
    }

    const first = result[0];
    if (first && typeof first === "object" && typeof first.exists === "boolean") {
      return first;
    }

    return null;
  }

  // Toleransi untuk adapter/mock yang langsung mengembalikan satu objek hasil.
  if (result && typeof result === "object" && typeof result.exists === "boolean") {
    return result;
  }

  return null;
}

async function queryOnWhatsAppCombo(sock, numberDigits) {
  const jid = `${numberDigits}@s.whatsapp.net`;
  let lastTransientError;

  for (const [candidate, method] of [
    [numberDigits, "digits"],
    [jid, "jid"],
  ]) {
    try {
      const raw = await sock.onWhatsApp(candidate);
      const found = normalizeWaExistsResult(raw);

      if (!found || typeof found.exists !== "boolean") {
        throw new WaCheckError(`Respons onWhatsApp tidak valid untuk metode ${method}.`, {
          code: "WA_INVALID_RESPONSE",
          retryable: false,
        });
      }

      if (found.exists === true) {
        return { status: "registered", exists: true, raw, found, method };
      }

      return { status: "not_registered", exists: false, raw, found, method };
    } catch (error) {
      if (error instanceof WaCheckError) throw error;
      const retryable = isTransientWaQueryError(error);
      const wrapped = new WaCheckError(
        `onWhatsApp gagal melalui metode ${method}: ${getWaQueryErrorMessage(error)}`,
        { code: "WA_QUERY_FAILED", retryable, cause: error },
      );
      if (!retryable) throw wrapped;
      lastTransientError = wrapped;
    }
  }

  throw (
    lastTransientError ||
    new WaCheckError("Tidak ada respons valid dari WhatsApp.", {
      code: "WA_NO_VALID_RESPONSE",
      retryable: false,
    })
  );
}

function canonicalUserJid(value) {
  const raw = String(value || "").trim().toLowerCase();
  if (!raw) return "";
  if (/^\d+$/.test(raw)) return `${raw}@s.whatsapp.net`;
  const separatorIndex = raw.indexOf("@");
  if (separatorIndex === -1) return raw;
  const userPart = raw.slice(0, separatorIndex).split(":")[0];
  const serverPart = raw.slice(separatorIndex + 1);
  return `${userPart}@${serverPart}`;
}

function readPresencePayload(update, requestedJid) {
  if (!update || typeof update !== "object") return null;
  const targetJid = canonicalUserJid(requestedJid);
  if (!targetJid) return null;

  const updateJid = canonicalUserJid(update.id);
  const presences =
    update.presences && typeof update.presences === "object" ? update.presences : {};
  const matchedPresenceEntry = Object.entries(presences).find(
    ([presenceJid]) => canonicalUserJid(presenceJid) === targetJid,
  );
  const directUpdateMatches = updateJid === targetJid;
  if (!matchedPresenceEntry && !directUpdateMatches) return null;

  const source = matchedPresenceEntry ? matchedPresenceEntry[1] : update;
  if (!source || typeof source !== "object") return null;

  const presence = source.lastKnownPresence ?? source.presence ?? source.status ?? null;
  const lastSeen =
    source.lastSeen ?? source.lastSeenTs ?? source.lastSeenTimestamp ?? source.t ?? null;
  if (!presence && !lastSeen) return null;
  return { presence, lastSeen };
}

module.exports = {
  WaCheckError,
  getWaQueryErrorMessage,
  isRetryableWaCheckError,
  isTransientWaQueryError,
  shouldIgnoreProfileNotFound,
  queryOnWhatsAppCombo,
  readPresencePayload,
};
