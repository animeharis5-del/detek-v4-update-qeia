function getPausedCheckJob(checkJobQueue, lockKey) {
  const job = checkJobQueue.get(lockKey);
  if (!job || job.status !== "paused" || !job.pauseContext) return null;
  return job;
}

function getResumeStatus(job, connected) {
  if (job?.finalizationInProgress) return "finalizing";
  if (!job || job.status !== "paused" || !job.pauseContext) return "missing";
  if (job.sendConfirmationPending) return "confirmation_pending";
  if (
    job.resumeRequested ||
    job.awaitingReconnectResume ||
    job.reconnectResumeInFlight ||
    job.reconnectResumeClaimed
  ) return "already_requested";
  if (!connected) return "not_connected";
  return "ready";
}

function beginPausedCheckSendConfirmation(job) {
  if (!job || job.status !== "paused" || !job.pauseContext) return null;
  if (
    job.finalizationInProgress ||
    job.resumeRequested ||
    job.reconnectResumeInFlight ||
    job.reconnectResumeClaimed
  ) return null;
  job.sendConfirmationPending = true;
  return job.pauseManifest || null;
}

function cancelPausedCheckSendConfirmation(job) {
  if (
    !job ||
    job.status !== "paused" ||
    !job.pauseContext ||
    !job.sendConfirmationPending ||
    job.finalizationInProgress
  ) {
    return false;
  }
  job.sendConfirmationPending = false;
  return true;
}

async function finalizePausedCheckJob(
  job,
  {
    deliverReport,
    sendSummary = async () => {},
    deletePanel = async () => {},
    recordSummary = async () => {},
  } = {},
) {
  if (!job || job.status !== "paused" || !job.pauseContext) {
    return { status: "missing" };
  }
  if (!job.sendConfirmationPending) return { status: "not_confirmed" };
  if (job.finalizationPromise) return job.finalizationPromise;
  if (typeof deliverReport !== "function") {
    throw new TypeError("deliverReport wajib berupa fungsi.");
  }

  job.finalizationInProgress = true;
  job.status = "finalizing";

  const task = (async () => {
    let reportDelivered = false;
    try {
      const summary = await deliverReport(job);
      reportDelivered = true;

      // File adalah hasil utama. Kegagalan pesan ringkasan atau penghapusan kartu
      // tidak boleh membuat file terkirim dianggap gagal lalu dikirim ulang.
      await Promise.resolve(sendSummary(summary)).catch(() => {});
      await Promise.resolve(deletePanel()).catch(() => {});
      await Promise.resolve(recordSummary(summary)).catch(() => {});

      job.sendConfirmationPending = false;
      const finalize = job.finalizePausedCheck;
      if (typeof finalize !== "function") {
        throw new Error("Runner pengecekan tidak siap menyelesaikan state jeda.");
      }
      finalize();
      await Promise.resolve(job.promise);
      return { status: "finalized", summary };
    } catch (error) {
      if (!reportDelivered) {
        job.status = "paused";
        job.finalizationInProgress = false;
        job.sendConfirmationPending = false;
      }
      throw error;
    } finally {
      job.finalizationPromise = null;
      if (reportDelivered) job.finalizationInProgress = false;
    }
  })();

  job.finalizationPromise = task;
  return task;
}

module.exports = {
  beginPausedCheckSendConfirmation,
  cancelPausedCheckSendConfirmation,
  finalizePausedCheckJob,
  getPausedCheckJob,
  getResumeStatus,
};
