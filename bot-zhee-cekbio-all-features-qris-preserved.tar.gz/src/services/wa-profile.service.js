const { abortableDelay } = require("../utils/abort");
const {
  WaCheckError,
  getWaQueryErrorMessage,
  isTransientWaQueryError,
  readPresencePayload,
} = require("./wa-query.service");

const PROFILE_FIELD_STATE = Object.freeze({
  AVAILABLE: "available",
  EMPTY: "empty",
  PRIVATE: "private",
  UNAVAILABLE: "unavailable",
});

function asNumber(value) {
  if (value && typeof value === "object" && typeof value.toNumber === "function") {
    return Number(value.toNumber());
  }
  return Number(value);
}

function formatWaTimestamp(rawValue) {
  if (!rawValue) return "";
  const value = asNumber(rawValue);
  if (!Number.isFinite(value) || value <= 0) return "";
  const timestamp = value > 1e12 ? value : value > 1e10 ? value : value * 1000;
  if (timestamp <= 86400000) return "";
  return new Intl.DateTimeFormat("id-ID", {
    dateStyle: "short",
    timeStyle: "medium",
    timeZone: "Asia/Jakarta",
  }).format(new Date(timestamp));
}

function cleanValue(value) {
  if (Array.isArray(value)) {
    const values = value.map(cleanValue).filter(Boolean);
    return values.join(", ");
  }
  if (value === undefined || value === null) return "";
  if (typeof value === "object") return "";
  return String(value).trim();
}

function firstValue(...values) {
  for (const value of values) {
    const cleaned = cleanValue(value);
    if (cleaned) return cleaned;
  }
  return "";
}

function field(status, value = "") {
  const safeStatus = Object.values(PROFILE_FIELD_STATE).includes(status)
    ? status
    : PROFILE_FIELD_STATE.UNAVAILABLE;
  return {
    status: safeStatus,
    value: safeStatus === PROFILE_FIELD_STATE.AVAILABLE ? cleanValue(value) : "",
  };
}

function fieldFromValue(value, emptyStatus = PROFILE_FIELD_STATE.EMPTY) {
  const cleaned = cleanValue(value);
  return cleaned
    ? field(PROFILE_FIELD_STATE.AVAILABLE, cleaned)
    : field(emptyStatus);
}

function getErrorStatusCode(error) {
  return Number(
    error?.output?.statusCode ??
      error?.statusCode ??
      error?.status ??
      error?.data?.statusCode ??
      error?.cause?.output?.statusCode ??
      error?.cause?.statusCode,
  );
}

function classifyProfileFieldError(error) {
  const statusCode = getErrorStatusCode(error);
  const message = getWaQueryErrorMessage(error);
  if (
    statusCode === 401 ||
    statusCode === 403 ||
    /not[ -]?authorized|unauthori[sz]ed|forbidden|privacy|privasi|permission denied/i.test(
      message,
    )
  ) {
    return PROFILE_FIELD_STATE.PRIVATE;
  }
  if (
    statusCode === 404 ||
    /not[ -]?found|item[ -]?not[ -]?found|no profile picture|profile(?: picture)?(?: is)? unavailable/i.test(
      message,
    )
  ) {
    return PROFILE_FIELD_STATE.EMPTY;
  }
  return PROFILE_FIELD_STATE.UNAVAILABLE;
}

function shouldEscalateSessionError(error, isSessionActive) {
  return (
    isTransientWaQueryError(error) &&
    typeof isSessionActive === "function" &&
    isSessionActive() === false
  );
}

async function fetchIsolatedField({
  fetcher,
  normalize = fieldFromValue,
  signal,
  isSessionActive,
  maxAttempts = 2,
}) {
  let lastError;
  for (let attempt = 1; attempt <= Math.max(1, maxAttempts); attempt++) {
    try {
      signal?.throwIfAborted();
      const raw = await fetcher();
      signal?.throwIfAborted();
      return normalize(raw);
    } catch (error) {
      if (signal?.aborted) throw signal.reason || error;
      if (shouldEscalateSessionError(error, isSessionActive)) {
        throw new WaCheckError(`Koneksi WA gagal saat mengambil profil: ${getWaQueryErrorMessage(error)}`, {
          code: "WA_PROFILE_CONNECTION_FAILED",
          retryable: true,
          cause: error,
        });
      }
      lastError = error;
      if (isTransientWaQueryError(error) && attempt < maxAttempts) {
        await abortableDelay(300 * attempt, signal);
        continue;
      }
      return field(classifyProfileFieldError(error));
    }
  }
  return field(classifyProfileFieldError(lastError));
}

function parseStatusPayload(payload) {
  const first = Array.isArray(payload) ? payload[0] : payload;
  const statusObject = first?.status && typeof first.status === "object" ? first.status : null;
  const rawBio =
    statusObject?.status ??
    (typeof first?.status === "string" ? first.status : null) ??
    first?.text ??
    first?.message ??
    null;
  const rawSetAt = statusObject?.setAt ?? first?.setAt ?? first?.t ?? null;
  const bio = fieldFromValue(rawBio);
  const setAt = formatWaTimestamp(rawSetAt);
  return {
    bio,
    bioTimestamp: setAt
      ? field(PROFILE_FIELD_STATE.AVAILABLE, setAt)
      : field(
          bio.status === PROFILE_FIELD_STATE.AVAILABLE
            ? PROFILE_FIELD_STATE.UNAVAILABLE
            : bio.status,
        ),
  };
}

function normalizePresenceName(value) {
  const raw = String(value || "").trim().toLowerCase();
  if (!raw) return "";
  if (raw === "available") return "Online sekarang";
  if (raw === "composing") return "Sedang mengetik";
  if (raw === "recording") return "Merekam audio";
  if (raw === "paused") return "Tidak aktif sekarang";
  if (raw === "unavailable") return "Offline";
  return raw.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
}

async function fetchPresenceFields({
  sock,
  jid,
  timeoutMs = 1500,
  signal,
  isSessionActive,
  attempt = 1,
  maxAttempts = 2,
}) {
  const unavailable = {
    presence: field(PROFILE_FIELD_STATE.UNAVAILABLE),
    lastSeen: field(PROFILE_FIELD_STATE.UNAVAILABLE),
  };
  if (!sock || typeof sock.presenceSubscribe !== "function" || !sock.ev) {
    return unavailable;
  }

  let cleanup = () => {};
  let settled = false;
  const waitForUpdate = new Promise((resolve, reject) => {
    const finish = (value, error) => {
      if (settled) return;
      settled = true;
      cleanup();
      if (error) reject(error);
      else resolve(value);
    };
    const listener = (update) => {
      const payload = readPresencePayload(update, jid);
      if (!payload) return;
      const presenceValue = normalizePresenceName(payload.presence);
      const lastSeenValue = formatWaTimestamp(payload.lastSeen);
      finish({
        presence: presenceValue
          ? field(PROFILE_FIELD_STATE.AVAILABLE, presenceValue)
          : field(PROFILE_FIELD_STATE.UNAVAILABLE),
        lastSeen: lastSeenValue
          ? field(PROFILE_FIELD_STATE.AVAILABLE, lastSeenValue)
          : field(PROFILE_FIELD_STATE.UNAVAILABLE),
      });
    };
    const onAbort = () => finish(unavailable);
    const timer = setTimeout(() => finish(unavailable), Math.max(1, Number(timeoutMs) || 1500));
    cleanup = () => {
      clearTimeout(timer);
      signal?.removeEventListener("abort", onAbort);
      if (typeof sock.ev.off === "function") sock.ev.off("presence.update", listener);
      else if (typeof sock.ev.removeListener === "function") {
        sock.ev.removeListener("presence.update", listener);
      }
    };
    signal?.addEventListener("abort", onAbort, { once: true });
    if (typeof sock.ev.on === "function") sock.ev.on("presence.update", listener);
    else finish(unavailable);
  });

  try {
    signal?.throwIfAborted();
    await sock.presenceSubscribe(jid);
    signal?.throwIfAborted();
    const result = await waitForUpdate;
    signal?.throwIfAborted();
    return result;
  } catch (error) {
    cleanup();
    if (signal?.aborted) throw signal.reason || error;
    if (shouldEscalateSessionError(error, isSessionActive)) {
      throw new WaCheckError(`Koneksi WA gagal saat mengambil presence: ${getWaQueryErrorMessage(error)}`, {
        code: "WA_PRESENCE_CONNECTION_FAILED",
        retryable: true,
        cause: error,
      });
    }
    if (isTransientWaQueryError(error) && attempt < maxAttempts) {
      await abortableDelay(300 * attempt, signal);
      return fetchPresenceFields({
        sock,
        jid,
        timeoutMs,
        signal,
        isSessionActive,
        attempt: attempt + 1,
        maxAttempts,
      });
    }
    const state = classifyProfileFieldError(error);
    return {
      presence: field(state),
      lastSeen: field(state),
    };
  }
}

function normalizeWebsites(value) {
  if (!value) return "";
  if (Array.isArray(value)) {
    return value
      .map((item) => firstValue(item?.url, item?.website, item))
      .filter(Boolean)
      .join(", ");
  }
  return firstValue(value?.url, value?.website, value);
}

function formatBusinessHours(value) {
  if (!value) return "";
  if (typeof value === "string") return value.trim();
  if (Array.isArray(value)) {
    return value
      .map((entry) => formatBusinessHours(entry))
      .filter(Boolean)
      .join("; ");
  }
  if (typeof value !== "object") return cleanValue(value);

  const timezone = firstValue(value.timezone, value.timeZone, value.tz);
  const rows =
    value.business_config ??
    value.businessConfig ??
    value.config ??
    value.schedule ??
    value.hours ??
    value.openingHours ??
    null;
  if (rows) {
    const schedule = formatBusinessHours(rows);
    return [schedule, timezone ? `Zona waktu: ${timezone}` : ""].filter(Boolean).join("; ");
  }

  const day = firstValue(value.day_of_week, value.dayOfWeek, value.day, value.name);
  const mode = firstValue(value.mode, value.status);
  const open = firstValue(value.open_time, value.openTime, value.open);
  const close = firstValue(value.close_time, value.closeTime, value.close);
  const simple = [day, mode, open && close ? `${open}-${close}` : open || close]
    .filter(Boolean)
    .join(" ");
  if (simple) return simple;

  return Object.entries(value)
    .map(([key, nested]) => {
      const formatted = formatBusinessHours(nested);
      return formatted ? `${key}: ${formatted}` : "";
    })
    .filter(Boolean)
    .join("; ");
}

function extractBusinessFields(profile, sourceState) {
  const stateForMissing =
    sourceState === PROFILE_FIELD_STATE.PRIVATE
      ? PROFILE_FIELD_STATE.PRIVATE
      : sourceState === PROFILE_FIELD_STATE.UNAVAILABLE
        ? PROFILE_FIELD_STATE.UNAVAILABLE
        : PROFILE_FIELD_STATE.EMPTY;
  const raw = profile && typeof profile === "object" ? profile : {};
  const businessHours =
    raw.businessHours ?? raw.business_hours ?? raw.openingHours ?? raw.opening_hours ?? raw.hours;
  return {
    businessName: fieldFromValue(
      firstValue(raw.businessName, raw.business_name, raw.name, raw.verifiedName),
      stateForMissing,
    ),
    businessDescription: fieldFromValue(
      firstValue(raw.description, raw.desc, raw.about),
      stateForMissing,
    ),
    businessCategory: fieldFromValue(
      firstValue(raw.category, raw.categoryName, raw.category_name, raw.categoryId),
      stateForMissing,
    ),
    businessVertical: fieldFromValue(
      firstValue(raw.vertical, raw.verticalName, raw.vertical_name, raw.industry),
      stateForMissing,
    ),
    businessEmail: fieldFromValue(firstValue(raw.email, raw.businessEmail), stateForMissing),
    businessWebsite: fieldFromValue(
      normalizeWebsites(raw.website ?? raw.websites ?? raw.businessWebsite),
      stateForMissing,
    ),
    businessAddress: fieldFromValue(
      firstValue(raw.address, raw.businessAddress, raw.location?.address),
      stateForMissing,
    ),
    businessHours: fieldFromValue(formatBusinessHours(businessHours), stateForMissing),
  };
}

function hasBusinessSignal(found, profile) {
  const hasProfileData = Boolean(
    profile && typeof profile === "object" && Object.keys(profile).length > 0,
  );
  return Boolean(
    hasProfileData ||
      found?.isBusiness ||
      found?.business ||
      found?.biz ||
      found?.verifiedName ||
      found?.isVerified,
  );
}

function verificationFrom(found, profile) {
  // Level verifikasi bisnis dari WhatsApp: "high" = terverifikasi (centang biru).
  const levelSignals = [
    profile?.verifiedLevel,
    profile?.verified_level,
    profile?.vlevel,
    profile?.level,
    found?.verifiedLevel,
  ];
  const hasVerifiedLevel = levelSignals.some((v) => {
    if (v === undefined || v === null) return false;
    const t = String(v).toLowerCase().trim();
    if (t === "high" || t === "verified") return true;
    const n = Number(v);
    return Number.isFinite(n) && n > 0;
  });
  // PENTING: verifiedName / display_name TIDAK dijadikan bukti verified,
  // karena semua bisnis punya nama — itu bukan tanda lencana Meta.
  // Verified hanya bila ada flag verified eksplisit ATAU vlevel yang sah.
  return Boolean(
    profile?.verified === true ||
      profile?.isVerified === true ||
      profile?.is_verified === true ||
      found?.verified === true ||
      found?.isVerified === true ||
      hasVerifiedLevel,
  );
}

function createRegisteredProfileResult({ number, waMethod, profile, pushName = "" }) {
  const fields = {
    ...profile.fields,
    verifiedName: fieldFromValue(profile.verifiedName),
    pushName: fieldFromValue(pushName),
  };
  const valueOf = (name, fallback = "-") =>
    fields[name]?.status === PROFILE_FIELD_STATE.AVAILABLE
      ? fields[name].value
      : fallback;
  const verifiedNameValue = valueOf("verifiedName", "");
  const pushNameValue = valueOf("pushName", "");
  const name = firstValue(valueOf("businessName", ""), verifiedNameValue) || "-";
  const verifiedName = verifiedNameValue || "-";
  const safePushName = pushNameValue || "-";
  const category = valueOf("businessCategory");
  const vertical = valueOf("businessVertical");
  const description = valueOf("businessDescription");
  const email = valueOf("businessEmail");
  const website = valueOf("businessWebsite");
  const address = valueOf("businessAddress");
  const businessHours = valueOf("businessHours");
  const bio = valueOf("bio");
  const setAt = valueOf("bioTimestamp");
  const photoUrl = valueOf("photo");
  const hasPhoto = fields.photo?.status === PROFILE_FIELD_STATE.AVAILABLE;
  const isBusiness = profile.accountType === "Business";
  // Model klasifikasi MURNI berdasar vlevel dari biz_identity_info (data asli WhatsApp).
  // Terbukti dari data: personal tidak punya business_profile; bisnis punya vlevel
  // high / low / unknown. Tidak ada "medium" dan tidak pakai quality score buatan.
  const vlevel = String(profile.vlevel || "").toLowerCase();
  const verified = vlevel === "high";
  const klasifikasi = !isBusiness
    ? "WhatsApp Biasa"
    : vlevel === "high"
      ? "Verified Meta Business"
      : vlevel === "low"
        ? "Standard Meta Business"
        : "WA Business Biasa";
  return {
    number,
    exists: true,
    status: "registered",
    klasifikasi,
    vlevel,
    memberSince: profile.memberSince || "",
    automatedType: profile.automatedType || "",
    verifiedRevoked: profile.verifiedRevoked === true,
    accountType: profile.accountType,
    accountTypeState: profile.accountTypeState,
    verified,
    verificationState: profile.verificationState,
    bio,
    setAt,
    name,
    verifiedName,
    pushName: safePushName,
    category,
    vertical,
    description,
    email,
    website,
    address,
    businessHours,
    hasPhoto,
    photoUrl,
    photoState: fields.photo?.status || PROFILE_FIELD_STATE.UNAVAILABLE,
    presence: valueOf("presence", "Tidak tersedia"),
    presenceState: fields.presence?.status || PROFILE_FIELD_STATE.UNAVAILABLE,
    lastSeen: valueOf("lastSeen", "Tidak tersedia"),
    lastSeenState: fields.lastSeen?.status || PROFILE_FIELD_STATE.UNAVAILABLE,
    lastSeenPrivacy:
      fields.lastSeen?.status === PROFILE_FIELD_STATE.PRIVATE
        ? "Privasi"
        : fields.lastSeen?.status === PROFILE_FIELD_STATE.AVAILABLE
          ? "Terbaca"
          : "Tidak tersedia",
    profileFields: fields,
    checkEngine: `combo:onWhatsApp(${waMethod})+public-profile`,
  };
}

// Fungsi bufferToString: ubah node Buffer WhatsApp jadi string.
function nodeBufferToString(content) {
  try {
    if (!content) return "";
    if (typeof content === "string") return content;
    if (content?.type === "Buffer" && Array.isArray(content.data)) {
      return Buffer.from(content.data).toString("utf8");
    }
    if (Buffer.isBuffer(content)) return content.toString("utf8");
    if (content instanceof Uint8Array) return Buffer.from(content).toString("utf8");
  } catch {
    return "";
  }
  return "";
}

// Fungsi fetchBizIdentityInfo: query business_profile MENTAH untuk ambil
// biz_identity_info (vlevel, display_name, is_signed, revoked) + member_since.
// Ini sumber sinyal verifikasi Meta yang tidak diambil getBusinessProfile standar.
async function fetchBizIdentityInfo({ sock, jid, signal, isSessionActive }) {
  if (typeof sock.query !== "function") return null;
  try {
    signal?.throwIfAborted();
    let getBinaryNodeChild;
    try {
      ({ getBinaryNodeChild } = require("@whiskeysockets/baileys"));
    } catch {
      return null;
    }
    const result = await sock.query({
      tag: "iq",
      attrs: { to: "s.whatsapp.net", xmlns: "w:biz", type: "get" },
      content: [
        {
          tag: "business_profile",
          attrs: { v: "244" },
          content: [{ tag: "profile", attrs: { jid } }],
        },
      ],
    });
    if (isSessionActive && !isSessionActive()) return null;
    const bizProfile = getBinaryNodeChild(result, "business_profile");
    const profileNode = getBinaryNodeChild(bizProfile, "profile");
    if (!profileNode) return null;

    const identity = getBinaryNodeChild(profileNode, "biz_identity_info");
    const memberSince = getBinaryNodeChild(profileNode, "member_since_text");
    const automatedNode = getBinaryNodeChild(profileNode, "automated_type");
    const vlevel = identity?.attrs?.vlevel || "";
    const displayName = identity?.attrs?.display_name || "";
    const isSigned = String(identity?.attrs?.is_signed || "") === "true";
    const revoked = String(identity?.attrs?.revoked || "") === "true";
    const memberSinceText = nodeBufferToString(memberSince?.content) || "";
    const automatedType = nodeBufferToString(automatedNode?.content) || "";


    return {
      vlevel: String(vlevel).toLowerCase(),
      displayName,
      isSigned,
      revoked,
      memberSinceText,
      automatedType,
    };
  } catch (error) {
    if (signal?.aborted) throw signal.reason || error;
    return null;
  }
}

async function fetchBusinessProfileField({
  sock,
  jid,
  signal,
  isSessionActive,
}) {
  let businessProfile = null;
  let businessProfileState = PROFILE_FIELD_STATE.EMPTY;

  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      signal?.throwIfAborted();
      if (typeof sock.getBusinessProfile !== "function") {
        businessProfileState = PROFILE_FIELD_STATE.UNAVAILABLE;
      } else {
        businessProfile = await sock.getBusinessProfile(jid);
        signal?.throwIfAborted();
        businessProfileState = businessProfile
          ? PROFILE_FIELD_STATE.AVAILABLE
          : PROFILE_FIELD_STATE.EMPTY;
      }
      break;
    } catch (error) {
      if (signal?.aborted) throw signal.reason || error;
      if (shouldEscalateSessionError(error, isSessionActive)) {
        throw new WaCheckError(
          `Koneksi WA gagal saat mengambil profil bisnis: ${getWaQueryErrorMessage(error)}`,
          {
            code: "WA_BUSINESS_CONNECTION_FAILED",
            retryable: true,
            cause: error,
          },
        );
      }
      if (isTransientWaQueryError(error) && attempt < 2) {
        await abortableDelay(300 * attempt, signal);
        continue;
      }
      businessProfileState = classifyProfileFieldError(error);
      break;
    }
  }

  return { businessProfile, businessProfileState };
}

async function fetchPublicWaProfile({
  sock,
  jid,
  found = {},
  signal,
  presenceTimeoutMs = 1500,
  isSessionActive,
}) {
  // Tahap 9: field profil ini saling independen. Menjalankannya serial membuat
  // latency satu nomor menjadi penjumlahan seluruh query. Promise.all membuat
  // latency mendekati query paling lambat, tetapi tetap hanya satu nomor aktif
  // per Sender karena capacity Sender Pool tetap 1.
  const [statusResult, photo, businessResult, bizIdentity, presenceFields] =
    await Promise.all([
      fetchIsolatedField({
        fetcher: () =>
          typeof sock.fetchStatus === "function"
            ? sock.fetchStatus(jid)
            : Promise.reject(new Error("fetchStatus tidak tersedia")),
        normalize: parseStatusPayload,
        signal,
        isSessionActive,
      }),
      fetchIsolatedField({
        fetcher: () =>
          typeof sock.profilePictureUrl === "function"
            ? sock.profilePictureUrl(jid, "image")
            : Promise.reject(new Error("profilePictureUrl tidak tersedia")),
        normalize: (url) => fieldFromValue(url),
        signal,
        isSessionActive,
      }),
      fetchBusinessProfileField({
        sock,
        jid,
        signal,
        isSessionActive,
      }),
      fetchBizIdentityInfo({
        sock,
        jid,
        signal,
        isSessionActive,
      }),
      fetchPresenceFields({
        sock,
        jid,
        timeoutMs: presenceTimeoutMs,
        signal,
        isSessionActive,
      }),
    ]);

  const statusFields = statusResult?.bio
    ? statusResult
    : {
        bio: field(statusResult.status),
        bioTimestamp: field(statusResult.status),
      };
  const { businessProfile, businessProfileState } = businessResult;

  const isBusiness = hasBusinessSignal(found, businessProfile);
  const accountTypeState =
    isBusiness || businessProfileState === PROFILE_FIELD_STATE.EMPTY
      ? PROFILE_FIELD_STATE.AVAILABLE
      : businessProfileState;
  const accountType = isBusiness
    ? "Business"
    : [PROFILE_FIELD_STATE.EMPTY, PROFILE_FIELD_STATE.AVAILABLE].includes(businessProfileState)
      ? "Personal"
      : "Tidak diketahui";
  // vlevel dari biz_identity_info: "high" = terverifikasi Meta / centang biru
  // (bukan revoked). Nilai "medium" tidak pernah muncul di data nyata.
  const vlevel = bizIdentity?.vlevel || "";
  const vlevelVerified = vlevel === "high" && bizIdentity?.revoked !== true;
  const verified = vlevelVerified || verificationFrom(found, businessProfile);
  const verificationState = verified
    ? PROFILE_FIELD_STATE.AVAILABLE
    : isBusiness && [PROFILE_FIELD_STATE.PRIVATE, PROFILE_FIELD_STATE.UNAVAILABLE].includes(businessProfileState)
      ? businessProfileState
      : PROFILE_FIELD_STATE.AVAILABLE;
  const businessFields = extractBusinessFields(businessProfile, businessProfileState);
  const resolvedVerifiedName = firstValue(
    bizIdentity?.displayName,
    found?.verifiedName,
    businessProfile?.verifiedName,
  );

  return {
    accountType,
    accountTypeState,
    verified,
    verificationState,
    verifiedName: resolvedVerifiedName,
    vlevel,
    memberSince: bizIdentity?.memberSinceText || "",
    automatedType: bizIdentity?.automatedType || "",
    verifiedRevoked: bizIdentity?.revoked === true && Boolean(bizIdentity?.vlevel),
    fields: {
      ...statusFields,
      photo,
      ...presenceFields,
      ...businessFields,
    },
    businessProfile,
  };
}

module.exports = {
  PROFILE_FIELD_STATE,
  classifyProfileFieldError,
  createRegisteredProfileResult,
  extractBusinessFields,
  fetchPresenceFields,
  fetchBusinessProfileField,
  fetchPublicWaProfile,
  field,
  fieldFromValue,
  formatBusinessHours,
  formatWaTimestamp,
};
