const path = require('node:path');
const { readJsonFile, updateJsonFileAtomic } = require('../repositories/json.repository');

const PRICING_PATH = path.join(process.cwd(), 'pricing.json');

function normalizeToken(value) {
  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) throw new Error('Jumlah token harus bilangan bulat lebih dari 0.');
  return n;
}
function normalizePrice(value) {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 0) throw new Error('Harga harus bilangan bulat 0 atau lebih.');
  return n;
}
function defaults() {
  return {
    version: 1,
    packages: [
      { tokens: 5, price: 1000 },
      { tokens: 10, price: 1800 },
      { tokens: 25, price: 4000 },
      { tokens: 50, price: 7000 },
      { tokens: 100, price: 12000 },
    ],
  };
}
async function getPackages() {
  const db = await readJsonFile(PRICING_PATH, defaults());
  return [...(Array.isArray(db.packages) ? db.packages : [])]
    .map((p) => ({ tokens: normalizeToken(p.tokens), price: normalizePrice(p.price) }))
    .sort((a, b) => a.tokens - b.tokens);
}
async function setPackage(tokens, price) {
  tokens = normalizeToken(tokens); price = normalizePrice(price);
  let result;
  await updateJsonFileAtomic(PRICING_PATH, defaults(), (db) => {
    const next = JSON.parse(JSON.stringify(db));
    next.packages = Array.isArray(next.packages) ? next.packages : [];
    const existing = next.packages.find((p) => Number(p.tokens) === tokens);
    if (existing) existing.price = price;
    else next.packages.push({ tokens, price });
    next.packages.sort((a, b) => Number(a.tokens) - Number(b.tokens));
    result = next.packages.find((p) => Number(p.tokens) === tokens);
    return next;
  });
  return result;
}
async function deletePackage(tokens) {
  tokens = normalizeToken(tokens);
  let deleted = false;
  await updateJsonFileAtomic(PRICING_PATH, defaults(), (db) => {
    const next = JSON.parse(JSON.stringify(db));
    const before = next.packages?.length || 0;
    next.packages = (next.packages || []).filter((p) => Number(p.tokens) !== tokens);
    deleted = next.packages.length !== before;
    return next;
  });
  return deleted;
}
async function getPackage(tokens) {
  tokens = normalizeToken(tokens);
  return (await getPackages()).find((p) => p.tokens === tokens) || null;
}
module.exports = { PRICING_PATH, getPackages, getPackage, setPackage, deletePackage };
