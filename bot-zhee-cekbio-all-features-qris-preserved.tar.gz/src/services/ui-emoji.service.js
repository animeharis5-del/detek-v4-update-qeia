const emojiMappings = require("../repositories/emoji-mappings.repository");

// Emoji yang dipakai oleh seluruh UI Telegram bot, termasuk caption file hasil.
// Yang sengaja TIDAK dipremiumkan hanya emoji yang tertulis di dalam isi file .txt
// hasil CEKBIO/CEKBIOTXT, karena file tersebut adalah plain text untuk diekspor.
const UI_EMOJIS = Object.freeze([
  { emoji: "➕", name: "Tambah" },
  { emoji: "📡", name: "Sender" },
  { emoji: "🔢", name: "Pairing Code" },
  { emoji: "📷", name: "QR Code" },
  { emoji: "📊", name: "Status / Statistik" },
  { emoji: "👤", name: "User" },
  { emoji: "🤖", name: "Agent AI / Bot" },
  { emoji: "⭐", name: "Custom Emoji / Favorit" },
  { emoji: "💼", name: "WA Bisnis" },
  { emoji: "🗑", name: "Hapus" },
  { emoji: "🧹", name: "Hapus Semua" },
  { emoji: "📦", name: "Total / Paket" },
  { emoji: "📌", name: "Info" },
  { emoji: "🏢", name: "CEKBIOTXT / Standard" },
  { emoji: "📢", name: "Broadcast" },
  { emoji: "🛠️", name: "Maintenance" },
  { emoji: "👇", name: "Petunjuk" },
  { emoji: "⏹", name: "Stop" },
  { emoji: "🔌", name: "Koneksi" },
  { emoji: "📤", name: "Kirim Hasil" },
  { emoji: "✅", name: "Sukses / Verifikasi" },
  { emoji: "↩️", name: "Batal / Kembali" },
  { emoji: "▶️", name: "Lanjut" },
  { emoji: "📁", name: "Folder / File" },
  { emoji: "🔗", name: "Tautan" },
  { emoji: "🏠", name: "Menu" },
  { emoji: "✖", name: "Tutup / Batalkan" },
  { emoji: "🔎", name: "Cekbio" },
  { emoji: "📖", name: "Bantuan" },
  { emoji: "🔐", name: "Akses" },
  { emoji: "✨", name: "Umum" },
  { emoji: "🟢", name: "Aktif" },
  { emoji: "🔄", name: "Reconnect" },
  { emoji: "⚪", name: "Offline" },
  { emoji: "📄", name: "Simple / TXT" },
  { emoji: "📋", name: "Detail" },
  { emoji: "👉", name: "Arahkan" },
  { emoji: "⚡", name: "Kecepatan" },
  { emoji: "🆔", name: "ID" },
  { emoji: "📱", name: "Nomor" },
  { emoji: "✍️", name: "Input" },
  { emoji: "❌", name: "Gagal" },
  { emoji: "⚠️", name: "Peringatan" },
  { emoji: "📭", name: "Kosong" },
  { emoji: "🌍", name: "Negara" },
  { emoji: "🔒", name: "Privat / Terkunci" },
  { emoji: "⏳", name: "Menunggu" },
  { emoji: "💾", name: "Tersimpan" },
  { emoji: "🕒", name: "Waktu" },
  { emoji: "🚀", name: "Siap" },
  { emoji: "🧩", name: "Rich Text" },
  { emoji: "👥", name: "Target / User" },
  { emoji: "📈", name: "Rasio" },
  { emoji: "👑", name: "Owner" },
  { emoji: "💎", name: "Premium Emoji" },
  { emoji: "🎞", name: "Animasi" },
]);

function normalizeEmoji(value) {
  return emojiMappings.normalizeEmojiKey(value);
}

function getUiEmojiEntry(value) {
  const key = normalizeEmoji(value);
  return UI_EMOJIS.find((entry) => normalizeEmoji(entry.emoji) === key) || null;
}

function isUiEmoji(value) {
  return Boolean(getUiEmojiEntry(value));
}

function getUiEmojiMapping(value) {
  const entry = getUiEmojiEntry(value);
  return entry ? emojiMappings.getMapping(entry.emoji) : null;
}

function getUiEmojiRows() {
  return UI_EMOJIS.map((entry) => ({
    ...entry,
    mapping: getUiEmojiMapping(entry.emoji),
  }));
}

function findLeadingUiEmoji(label) {
  const text = String(label ?? "");
  const candidates = UI_EMOJIS
    .map((entry) => entry.emoji)
    .sort((a, b) => b.length - a.length);
  for (const emoji of candidates) {
    if (text.startsWith(emoji)) return emoji;
    const noVs = emoji.replace(/\uFE0F/g, "");
    if (noVs !== emoji && text.startsWith(noVs)) return noVs;
  }
  return null;
}

function decorateButton(button, { style = "primary" } = {}) {
  if (!button || typeof button !== "object") return button;
  const out = { ...button, style };
  const leading = findLeadingUiEmoji(out.text);
  if (!leading) return out;
  const mapping = getUiEmojiMapping(leading);
  if (!mapping?.customEmojiId) return out;
  out.icon_custom_emoji_id = mapping.customEmojiId;
  out.text = String(out.text).slice(leading.length).trimStart() || "•";
  return out;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function replaceMappedEmojiInHtml(text) {
  const mappings = getUiEmojiRows()
    .filter((entry) => entry.mapping?.customEmojiId)
    .sort((a, b) => b.emoji.length - a.emoji.length);
  if (!mappings.length) return { text: String(text ?? ""), changed: false };

  // Split tag HTML dari isi. Isi tg-emoji yang sudah ada tidak disentuh agar
  // custom emoji bawaan/broadcast tidak menjadi tag bertingkat.
  const parts = String(text ?? "").split(/(<[^>]+>)/g);
  let insideCustomEmoji = false;
  let protectedDepth = 0;
  let changed = false;
  for (let index = 0; index < parts.length; index++) {
    const part = parts[index];
    if (/^<tg-emoji\b/i.test(part)) {
      insideCustomEmoji = true;
      continue;
    }
    if (/^<\/tg-emoji\s*>/i.test(part)) {
      insideCustomEmoji = false;
      continue;
    }
    if (/^<(?:pre|code)\b/i.test(part)) {
      protectedDepth += 1;
      continue;
    }
    if (/^<\/(?:pre|code)\s*>/i.test(part)) {
      protectedDepth = Math.max(0, protectedDepth - 1);
      continue;
    }
    if (/^<[^>]+>$/.test(part) || insideCustomEmoji || protectedDepth > 0) continue;
    let next = part;
    for (const entry of mappings) {
      if (!next.includes(entry.emoji)) continue;
      const tag = `<tg-emoji emoji-id="${entry.mapping.customEmojiId}">${escapeHtml(entry.emoji)}</tg-emoji>`;
      next = next.split(entry.emoji).join(tag);
    }
    if (next !== part) {
      changed = true;
      parts[index] = next;
    }
  }
  return { text: parts.join(""), changed };
}

function applyMappingsToTelegramText(text, options = {}) {
  const source = String(text ?? "");
  const mappedRows = getUiEmojiRows().filter((entry) => entry.mapping?.customEmojiId);
  if (!mappedRows.length) return { text: source, options: { ...options }, changed: false };

  // UI bot saat ini mayoritas HTML. Untuk plain text, escape terlebih dahulu
  // lalu pindahkan ke HTML hanya jika benar-benar ada emoji yang diganti.
  const htmlMode = String(options?.parse_mode || "").toUpperCase() === "HTML";
  if (htmlMode) {
    const applied = replaceMappedEmojiInHtml(source);
    return { text: applied.text, options: { ...options }, changed: applied.changed };
  }

  const hasMappedEmoji = mappedRows.some((entry) => source.includes(entry.emoji));
  if (!hasMappedEmoji || options?.entities) {
    return { text: source, options: { ...options }, changed: false };
  }

  let escaped = escapeHtml(source);
  for (const entry of mappedRows.sort((a, b) => b.emoji.length - a.emoji.length)) {
    if (!source.includes(entry.emoji)) continue;
    const escapedEmoji = escapeHtml(entry.emoji);
    const tag = `<tg-emoji emoji-id="${entry.mapping.customEmojiId}">${escapedEmoji}</tg-emoji>`;
    escaped = escaped.split(escapedEmoji).join(tag);
  }
  return {
    text: escaped,
    options: { ...options, parse_mode: "HTML" },
    changed: true,
  };
}

function removeButtonCustomEmoji(replyMarkup) {
  if (!replyMarkup || typeof replyMarkup !== "object") return replyMarkup;
  const copy = structuredClone(replyMarkup);
  const rows = copy.inline_keyboard || copy.keyboard || [];
  const mappedRows = getUiEmojiRows().filter((entry) => entry.mapping?.customEmojiId);
  for (const row of rows) {
    for (const button of row || []) {
      if (!button || typeof button !== "object" || !button.icon_custom_emoji_id) continue;
      const mapped = mappedRows.find(
        (entry) => entry.mapping.customEmojiId === String(button.icon_custom_emoji_id),
      );
      if (mapped && !String(button.text || "").startsWith(mapped.emoji)) {
        button.text = `${mapped.emoji} ${String(button.text || "").trimStart()}`.trim();
      }
      delete button.icon_custom_emoji_id;
    }
  }
  return copy;
}

function extractEmojiMappingCommand(message = {}) {
  const text = String(message.text || "");
  const equalsIndex = text.indexOf("=");
  if (equalsIndex < 0) {
    return { error: "Format harus /emoji emojiawal=emojigerak" };
  }

  const commandMatch = text.match(/^\/emoji(?:@[A-Za-z0-9_]+)?\s+/i);
  if (!commandMatch) {
    return { error: "Format harus /emoji emojiawal=emojigerak" };
  }
  const left = text.slice(commandMatch[0].length, equalsIndex).trim();
  const entry = getUiEmojiEntry(left);
  if (!entry) {
    return { error: "Emoji awal tidak ditemukan di UI bot. Gunakan /listemoji." };
  }

  const entities = Array.isArray(message.entities) ? message.entities : [];
  const customEntity = entities.find((entity) =>
    entity?.type === "custom_emoji" &&
    entity?.custom_emoji_id &&
    Number(entity.offset) >= equalsIndex + 1,
  );
  if (!customEntity) {
    return { error: "Emoji setelah tanda = harus berupa custom/premium emoji Telegram." };
  }

  const start = Number(customEntity.offset);
  const end = start + Number(customEntity.length);
  const customAlt = text.slice(start, end);
  return {
    emoji: entry.emoji,
    name: entry.name,
    customAlt,
    customEmojiId: String(customEntity.custom_emoji_id),
  };
}

module.exports = {
  UI_EMOJIS,
  applyMappingsToTelegramText,
  decorateButton,
  extractEmojiMappingCommand,
  getUiEmojiEntry,
  getUiEmojiMapping,
  getUiEmojiRows,
  isUiEmoji,
  removeButtonCustomEmoji,
};
