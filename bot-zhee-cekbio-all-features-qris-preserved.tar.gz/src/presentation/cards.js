const CARD_SEPARATOR = "─────────────────────";
const THIN_LINE = "─────────────────";

const ACCENTS = Object.freeze({
  success: "✅",
  standard: "🏢",
  low: "📌",
  user: "👤",
  failed: "❌",
  total: "📦",
  pairing: "🔗",
  status: "📊",
  instruction: "👇",
  disconnect: "🔌",
  warning: "⚠️",
  broadcast: "📢",
  maintenance: "🛠️",
});

const TITLE_ICONS = Object.freeze([
  [/SENDER TERHUBUNG|BOT AKTIF|AKSES TERBUKA|SELESAI|SUKSES/i, "✅"],
  [/SENDER KAMU|KELOLA SENDER|STATUS SENDER/i, "📡"],
  [/TAMBAH SENDER/i, "➕"],
  [/HAPUS SENDER|SENDER DIHAPUS/i, "🗑"],
  [/PAIRING/i, "🔢"],
  [/QR/i, "📷"],
  [/KECEPATAN/i, "⚡"],
  [/CEKBIO TXT|TXT/i, "📄"],
  [/CEKBIO|PENGECEKAN/i, "🔎"],
  [/BANTUAN/i, "📖"],
  [/VERIFIKASI|AKSES/i, "🔐"],
  [/STATISTIK/i, "📊"],
  [/BROADCAST/i, "📢"],
  [/MAINTENANCE|PERBAIKAN/i, "🛠️"],
  [/USER/i, "👤"],
]);

function mapAscii(value, upperStart, lowerStart, digitStart) {
  return Array.from(String(value ?? ""), (char) => {
    const code = char.codePointAt(0);
    if (code >= 65 && code <= 90) return String.fromCodePoint(upperStart + code - 65);
    if (code >= 97 && code <= 122) return String.fromCodePoint(lowerStart + code - 97);
    if (code >= 48 && code <= 57) return String.fromCodePoint(digitStart + code - 48);
    return char;
  }).join("");
}

function toBoldText(value) {
  return mapAscii(value, 0x1d5d4, 0x1d5ee, 0x1d7ec);
}

function toMonospace(value) {
  return mapAscii(value, 0x1d670, 0x1d68a, 0x1d7f6);
}

function cleanTitle(title) {
  return String(title || "")
    .replace(/^[\p{Extended_Pictographic}◈❖⊘⊕×←↩️▶️]+\s*/u, "")
    .trim()
    .toUpperCase();
}

function titleIcon(title, warning = false) {
  if (warning) return "⚠️";
  const clean = cleanTitle(title);
  for (const [pattern, icon] of TITLE_ICONS) {
    if (pattern.test(clean)) return icon;
  }
  return "✨";
}

function normalizeLines(lines) {
  const input = Array.isArray(lines) ? lines : [lines];
  return input
    .filter((line) => line !== null && line !== undefined && String(line).trim() !== "")
    .map((line) => String(line).trimEnd())
    .filter((line) => !/^[─╌—\-]{3,}$/u.test(line.trim()));
}

const WARNING_TITLE_PATTERN = /(?:DITOLAK|GAGAL|BELUM|TIDAK|LIMIT|ERROR|TERTAHAN|DIHENTIKAN|PERINGATAN|TERPUTUS)/i;

function buildTitle(title, { warning = false } = {}) {
  return `${titleIcon(title, warning)} ${toBoldText(cleanTitle(title))}`;
}

function buildFramedTitle(title, { warning = false } = {}) {
  return `╭─ ${buildTitle(title, { warning })}`;
}

function renderTreePanel(title, lines = [], suffix = "", options = {}) {
  const body = normalizeLines(lines);
  const warning =
    options.warning === true ||
    (options.warning !== false && WARNING_TITLE_PATTERN.test(String(title || "")));
  const output = [buildFramedTitle(title, { warning })];
  const finalBody = [...body];
  if (suffix) finalBody.push(String(suffix));
  if (!finalBody.length) {
    output.push("╰─");
    return output.join("\n");
  }
  finalBody.forEach((line, index) => {
    output.push(`${index === finalBody.length - 1 ? "╰─" : "├─"} ${line}`);
  });
  return output.join("\n");
}

function boxPanel(title, lines = [], suffix = "", options = {}) {
  return renderTreePanel(title, lines, suffix, options);
}

function boxPanelFramed(title, lines = [], suffix = "", options = {}) {
  return renderTreePanel(title, lines, suffix, options);
}

function warningPanel(title, lines = [], suffix = "") {
  return renderTreePanel(title, lines, suffix, { warning: true });
}

function formatStatNumber(value) {
  return new Intl.NumberFormat("id-ID").format(Number(value) || 0);
}

function formatAlignedSummaryRow(icon, label, value, labelWidth, valueWidth) {
  const normalizedLabel = String(label).padEnd(labelWidth, " ");
  const normalizedValue = formatStatNumber(value).padStart(valueWidth, " ");
  return `${icon} ${toMonospace(normalizedLabel)}  ${toMonospace(normalizedValue)}`;
}

function buildSummaryCard(counts = {}, total = 0, label = "Selesai") {
  const rows = [
    [ACCENTS.success, "Verified", counts.verified],
    [ACCENTS.standard, "Standard", counts.standard],
    ["💼", "WA Bisnis", counts.wabiz],
    [ACCENTS.user, "WA Biasa", counts.wa],
    [ACCENTS.failed, "Tidak Terdaftar", counts.not],
    [ACCENTS.total, "Total", total],
  ];
  const labelWidth = Math.max(...rows.map(([, rowLabel]) => rowLabel.length));
  const valueWidth = Math.max(...rows.map(([, , value]) => formatStatNumber(value).length));
  return boxPanel(
    `CEKBIO ${String(label || "Selesai").toUpperCase()}`,
    rows.map(([icon, rowLabel, value]) =>
      formatAlignedSummaryRow(icon, rowLabel, value, labelWidth, valueWidth),
    ),
  );
}

function buildFriendlyIssueCard(title, message, action = "Buka menu lalu coba lagi.") {
  return warningPanel(title, [`${message}`, `👉 ${action}`]);
}

function buildMainMenuCard({
  name,
  userId,
  directLimit,
  txtLimit,
  group = false,
  senderCount = 0,
  speed = 100,
}) {
  if (group) {
    return boxPanel("MOCI WS CHECKER", [
      `👤 ${name}`,
      `🔎 /cekbio · maks. ${formatStatNumber(directLimit)} nomor`,
      `📄 /cekbiotxt · maks. ${formatStatNumber(txtLimit)} nomor`,
      `📡 /senderku · kelola Sender di grup ini`,
    ]);
  }
  return boxPanel("MOCI WS CHECKER", [
    `👤 User   : ${name}`,
    `🆔 ID     : ${userId}`,
    `📡 Sender : ${Math.max(0, Number(senderCount) || 0)} aktif`,
    `⚡ Speed  : ${Math.max(1, Number(speed) || 100)} / Sender`,
    `🟢 Status : Siap`,
    `🔎 /cekbio · maks. ${formatStatNumber(directLimit)} nomor`,
    `📄 /cekbiotxt · maks. ${formatStatNumber(txtLimit)} nomor`,
  ]);
}

function buildWaPairingCard() {
  return boxPanel("PAIRING CODE", [
    "📱 Masukkan nomor WhatsApp dengan kode negara.",
    "✍️ Contoh: 628123456789",
  ]);
}

function buildWaConnectedCard(extraLine = "") {
  const lines = ["✅ Sender berhasil terhubung."];
  if (extraLine) lines.push(`👉 ${extraLine}`);
  return boxPanel("SENDER TERHUBUNG", lines);
}

function buildWaDisconnectedCard(message = "Sender sudah dihapus.") {
  return boxPanel("SENDER DIHAPUS", [
    `🗑 ${message}`,
    "✅ Auth dan sesi Sender sudah dibersihkan.",
  ]);
}

function buildWaStatusCard(connected) {
  return boxPanel("STATUS SENDER", [
    `${connected ? "🟢 Terhubung" : "⚪ Belum terhubung"}`,
  ]);
}

function buildWaConnectionCard() {
  return boxPanel("KELOLA SENDER", [
    "📡 Hubungkan Sender untuk mulai digunakan.",
    "👇 Pilih aksi di bawah.",
  ]);
}

function formatSenderUptime(connectedAt, now = Date.now()) {
  const started = Number(connectedAt || 0);
  if (!started || started > now) return "baru";
  const totalMinutes = Math.max(0, Math.floor((now - started) / 60000));
  if (totalMinutes < 1) return "<1m";
  if (totalMinutes < 60) return `${totalMinutes}m`;
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours < 24) return minutes ? `${hours}j ${minutes}m` : `${hours}j`;
  const days = Math.floor(hours / 24);
  const restHours = hours % 24;
  return restHours ? `${days}h ${restHours}j` : `${days}h`;
}

function buildSenderManagerCard({ senders = [], now = Date.now(), notice = "" } = {}) {
  const knownSenders = (Array.isArray(senders) ? senders : []).filter(Boolean);
  const active = knownSenders.filter((sender) => sender?.connected === true).length;
  const reconnecting = knownSenders.filter(
    (sender) => sender?.connected !== true && sender?.connectivityState === "reconnecting",
  ).length;
  const lines = [];
  for (const sender of knownSenders) {
    const number = String(sender?.number || "").replace(/\D/g, "");
    const label = number ? `+${number}` : "Sender tersimpan";
    if (sender?.connected === true) {
      lines.push(`🟢 ${label} · ${formatSenderUptime(sender?.connectedAt, now)}`);
    } else if (sender?.connectivityState === "reconnecting") {
      lines.push(`🔄 ${label} · reconnect`);
    } else {
      lines.push(`⚪ ${label} · offline`);
    }
  }
  if (!knownSenders.length) lines.push("📭 Belum ada Sender yang terhubung.");
  lines.push(`📊 ${active} aktif${reconnecting ? ` · ${reconnecting} reconnect` : ""}`);
  const panel = boxPanel("SENDER KAMU", lines);
  return notice ? `${String(notice).trim()}\n\n${panel}` : panel;
}

function buildSenderMethodCard() {
  return boxPanel("TAMBAH SENDER", [
    "📷 QR Code",
    "🔢 Pairing Code",
    "👇 Pilih metode koneksi.",
  ]);
}

function buildSenderPairingPromptCard({ group = false } = {}) {
  return boxPanel("PAIRING CODE", [
    group
      ? "📱 Balas pesan ini dengan nomor WhatsApp + kode negara, tanpa spasi."
      : "📱 Kirim nomor WhatsApp dengan kode negara, tanpa spasi.",
    "🌍 Contoh: <code>6281234567890</code>",
    group ? "🔒 Input hanya dipakai untuk sesi pairing milik kamu di grup ini." : null,
  ].filter(Boolean));
}

function escapeTelegramHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function buildSenderPairingCodeCard(phoneNumberDigits, code) {
  const phone = String(phoneNumberDigits || "").replace(/\D/g, "");
  const safeCode = escapeTelegramHtml(String(code || "-").trim());
  return boxPanel("PAIRING CODE SIAP", [
    `📱 Nomor : +${phone || "-"}`,
    `🔐 Kode  : <code>${safeCode}</code>`,
    "⏳ Berlaku ±2 menit",
  ]);
}

function buildSenderQrWaitCard() {
  return boxPanel("SCAN QR", ["⏳ Menunggu QR dari WhatsApp..."]);
}

function buildSenderQrCaption() {
  return [
    "📷 <b>SCAN QR SENDER</b>",
    "",
    "Buka WhatsApp → <code>Perangkat Tertaut</code> → <code>Tautkan Perangkat</code> → scan QR ini.",
    "",
    "⏳ QR berlaku sekitar 60 detik.",
  ].join("\n");
}

function buildSenderConnectedNotice({ number = "", activeCount = 1 } = {}) {
  const digits = String(number || "").replace(/\D/g, "");
  return boxPanel("SENDER TERHUBUNG", [
    `📱 ${digits ? `+${digits}` : "Sender aktif"}`,
    `📡 ${Math.max(1, Number(activeCount) || 1)} Sender aktif`,
  ]);
}

function buildSenderDisconnectMenuCard() {
  return boxPanel("HAPUS SENDER", ["👇 Pilih Sender yang ingin dihapus."]);
}

function buildSenderDisconnectedNotice(number = "") {
  const digits = String(number || "").replace(/\D/g, "");
  return `✅ Sender ${digits ? `+${digits} ` : ""}dihapus.`;
}

function buildSenderUnexpectedDisconnectNotice(number = "") {
  const digits = String(number || "").replace(/\D/g, "");
  return warningPanel("SENDER TERPUTUS", [
    `📱 ${digits ? `+${digits}` : "Sender"}`,
    "Sender otomatis dihapus karena sesi sudah tidak valid.",
    "Kemungkinan diputus manual, logout, atau tidak lagi dapat digunakan.",
    "👉 Hubungkan kembali bila masih ingin digunakan.",
  ]);
}

function buildAllSendersDisconnectedNotice(total = 0) {
  const count = Math.max(0, Number(total) || 0);
  return count > 0 ? `✅ ${count} Sender berhasil dihapus.` : "📭 Tidak ada Sender yang perlu dihapus.";
}

function buildSenderPairingCancelledCard() {
  return "↩️ Proses koneksi dibatalkan.";
}

function buildMultiSenderBackendPendingCard() {
  return boxPanel("MULTI SENDER", [
    "✅ Multi-Sender aktif.",
    "➕ Tambahkan Sender berikutnya dari menu Senderku.",
  ]);
}

function buildHelpCard({ directLimit, txtLimit }) {
  return boxPanel("BANTUAN", [
    `🔎 /cekbio · cek nomor langsung · maks. ${formatStatNumber(directLimit)}`,
    `📄 /cekbiotxt · cek file TXT · maks. ${formatStatNumber(txtLimit)}`,
    "📡 /senderku · kelola Sender WhatsApp",
    "➕ Senderku → Add Sender → QR / Pairing Code",
    "⚡ Atur kecepatan dari panel sebelum memulai cek.",
    "📦 Hasil dikirim dalam format TXT.",
  ]);
}

function buildForceJoinWelcomeCard({ folderMode = false, targetCount = 0 } = {}) {
  if (folderMode) {
    return boxPanel("VERIFIKASI AKSES", [
      "🔒 Bergabung dulu ke grup & channel MOCI.",
      "📁 Tekan Tambahkan Folder lalu pilih Tambah Semua.",
      "✅ Setelah itu tekan Verifikasi.",
    ]);
  }
  return boxPanel("VERIFIKASI AKSES", [
    `🔒 Bergabung ke ${targetCount} grup/channel untuk membuka bot.`,
    "🔗 Buka tombol grup di bawah.",
    "✅ Setelah lengkap, tekan Verifikasi.",
  ]);
}

function buildForceJoinFailedCard({ folderMode = false, joinStatus = null } = {}) {
  const missing = joinStatus?.missingTargets || [];
  const doneCount = (joinStatus?.targets?.length || 0) - missing.length;
  const totalCount = joinStatus?.targets?.length || 0;
  const lines = [
    `📊 Bergabung : ${doneCount}/${totalCount}`,
    `❌ Kurang    : ${missing.length}`,
    ...missing.map((target, index) => `❌ ${target.title || `Grup ${index + 1}`}`),
    folderMode ? "👉 Tambahkan Folder lalu Verifikasi ulang." : "👉 Lengkapi lalu tekan Verifikasi.",
  ];
  return warningPanel("VERIFIKASI BELUM LENGKAP", lines);
}

function buildTelegramDownloadFailedCard() {
  return buildFriendlyIssueCard(
    "DOWNLOAD FILE GAGAL",
    "File belum dapat diunduh dari Telegram.",
    "Kirim ulang file beberapa saat lagi.",
  );
}

function buildPausedCheckCard({ checked = 0, pending = 0, total = 0 } = {}) {
  return boxPanel("CEK DIJEDA", [
    `✅ Selesai : ${formatStatNumber(checked)} / ${formatStatNumber(total)}`,
    `📦 Sisa    : ${formatStatNumber(pending)}`,
    "📡 Menunggu Sender aktif.",
    "💾 Hasil sementara tetap aman.",
  ]);
}

function buildPausedCheckSendConfirmationCard({ remaining = 0 } = {}) {
  return warningPanel("KIRIM HASIL SEKARANG", [
    "Jika dikirim sekarang, job tidak bisa dilanjutkan.",
    `📦 Sisa ${formatStatNumber(remaining)} nomor akan dicek ulang bila memulai lagi.`,
  ]);
}

function buildResumeNeedsConnectionCard() {
  return warningPanel("SENDER BELUM SIAP", [
    "📡 Tidak ada Sender aktif.",
    "👉 Hubungkan Sender lewat /senderku. Cek akan lanjut saat Sender siap.",
  ]);
}

function buildActiveJobCard(activeJob = {}) {
  const startedAt = activeJob.startedAt
    ? new Date(activeJob.startedAt).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
    : "-";
  const type = String(activeJob.type || "cekbio").replace(/^cekbio/i, "CEKBIO");
  return warningPanel("PENGECEKAN MASIH JALAN", [
    `🔎 ${type} masih berjalan.`,
    `🕒 Mulai: ${startedAt}`,
    "👉 Gunakan tombol Stop bila ingin membatalkan.",
  ]);
}

module.exports = {
  ACCENTS,
  CARD_SEPARATOR,
  THIN_LINE,
  boxPanel,
  boxPanelFramed,
  buildActiveJobCard,
  buildFriendlyIssueCard,
  buildForceJoinFailedCard,
  buildForceJoinWelcomeCard,
  buildHelpCard,
  buildMainMenuCard,
  buildPausedCheckCard,
  buildPausedCheckSendConfirmationCard,
  buildResumeNeedsConnectionCard,
  buildSummaryCard,
  buildTelegramDownloadFailedCard,
  buildWaConnectionCard,
  buildWaConnectedCard,
  buildWaDisconnectedCard,
  buildWaPairingCard,
  buildWaStatusCard,
  buildSenderManagerCard,
  buildSenderMethodCard,
  buildSenderPairingPromptCard,
  buildSenderPairingCodeCard,
  buildSenderQrWaitCard,
  buildSenderQrCaption,
  buildSenderConnectedNotice,
  buildSenderDisconnectMenuCard,
  buildSenderDisconnectedNotice,
  buildSenderUnexpectedDisconnectNotice,
  buildAllSendersDisconnectedNotice,
  buildSenderPairingCancelledCard,
  buildMultiSenderBackendPendingCard,
  formatStatNumber,
  formatSenderUptime,
  toBoldText,
  warningPanel,
};
