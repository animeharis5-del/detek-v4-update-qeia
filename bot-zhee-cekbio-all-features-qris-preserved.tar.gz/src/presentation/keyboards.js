const { decorateButton } = require("../services/ui-emoji.service");

const BUTTON_LABELS = Object.freeze({
  pairing: "➕ Add Sender",
  senderMenu: "📡 Senderku",
  addSender: "➕ Add Sender",
  addSenderAgain: "➕ Add Sender Lagi",
  pairCode: "🔢 Pairing Code",
  pairQr: "📷 QR Code",
  status: "📊 Status Sender",
  disconnect: "🗑 Hapus Sender",
  disconnectAll: "🧹 Hapus Semua",
  broadcast: "📢 Broadcast",
  maintenanceActive: "🛠️ Maintenance: Aktif",
  maintenanceInactive: "🛠️ Maintenance: Nonaktif",
  abortCheck: "⏹ Stop",
  sendPartial: "📤 Kirim Hasil",
  confirmSendPartial: "✅ Ya, Kirim",
  cancelSendPartial: "↩️ Batal",
  resumeCheck: "▶️ Lanjutkan Cek",
  addFolder: "📁 Tambahkan Folder",
  verify: "✅ Verifikasi",
  privateChat: "🔗 Chat Privat",
  menu: "🏠 Menu",
  back: "← Kembali",
  cancel: "✖ Batalkan",
  close: "✖ Tutup",
});

function chunkButtons(buttons, size = 2) {
  const rows = [];
  for (let index = 0; index < buttons.length; index += size) {
    rows.push(buttons.slice(index, index + size));
  }
  return rows;
}

function createKeyboardPresentation(Markup) {
  function callback(label, data, style = "primary") {
    return decorateButton(Markup.button.callback(label, data), { style });
  }

  function url(label, targetUrl, style = "primary") {
    return decorateButton(Markup.button.url(label, targetUrl), { style });
  }

  function grid(buttons, { columns = 2, closeButton = null } = {}) {
    const ordered = buttons.filter(Boolean);
    if (closeButton) ordered.push(closeButton);
    return Markup.inlineKeyboard(chunkButtons(ordered, columns));
  }

  function maintenanceLabel(enabled) {
    return enabled
      ? BUTTON_LABELS.maintenanceActive
      : BUTTON_LABELS.maintenanceInactive;
  }

  return {
    emptyKeyboard() {
      return Markup.inlineKeyboard([]);
    },

    mainKeyboard({ isOwner, maintenanceEnabled = false, callbacks }) {
      const buttons = [callback(BUTTON_LABELS.senderMenu, callbacks.WA_MENU, "primary")];
      if (isOwner) {
        buttons.push(
          callback(BUTTON_LABELS.broadcast, callbacks.OWN_BROADCAST, "primary"),
          callback(
            maintenanceLabel(maintenanceEnabled),
            callbacks.OWN_MAINTENANCE,
            maintenanceEnabled ? "success" : "danger",
          ),
        );
      }
      return grid(buttons);
    },

    activeCheckKeyboard({ callbacks }) {
      return grid([callback(BUTTON_LABELS.abortCheck, callbacks.ABORT_CHECK, "danger")]);
    },

    pausedCheckKeyboard({ callbacks }) {
      return grid([
        callback(BUTTON_LABELS.sendPartial, callbacks.SEND_PARTIAL_CHECK, "primary"),
        callback(BUTTON_LABELS.resumeCheck, callbacks.RESUME_CHECK, "success"),
      ]);
    },

    pausedCheckConfirmationKeyboard({ callbacks }) {
      return grid([
        callback(BUTTON_LABELS.confirmSendPartial, callbacks.CONFIRM_SEND_PARTIAL_CHECK, "danger"),
        callback(BUTTON_LABELS.cancelSendPartial, callbacks.CANCEL_SEND_PARTIAL_CHECK, "primary"),
      ]);
    },

    resumeNeedsConnectionKeyboard({ callbacks }) {
      return grid([callback(BUTTON_LABELS.pairing, callbacks.PAIR, "success")], { columns: 1 });
    },

    waMenuKeyboard({ callbacks, connected = false }) {
      if (connected) {
        return Markup.inlineKeyboard([
          [
            callback(BUTTON_LABELS.addSender, callbacks.PAIR, "success"),
            callback(BUTTON_LABELS.disconnect, callbacks.DISCONNECT_MENU, "danger"),
          ],
          [callback(BUTTON_LABELS.disconnectAll, callbacks.DISCONNECT_ALL, "danger")],
          [callback(BUTTON_LABELS.back, callbacks.CLOSE_WA_MENU, "primary")],
        ]);
      }
      return Markup.inlineKeyboard([
        [callback(BUTTON_LABELS.addSender, callbacks.PAIR, "success")],
        [callback(BUTTON_LABELS.back, callbacks.CLOSE_WA_MENU, "primary")],
      ]);
    },

    connectedSenderKeyboard({ callbacks }) {
      return Markup.inlineKeyboard([
        [
          callback(BUTTON_LABELS.addSenderAgain, callbacks.PAIR, "success"),
          callback(BUTTON_LABELS.senderMenu, callbacks.WA_MENU, "primary"),
        ],
      ]);
    },

    disconnectSenderKeyboard({ callbacks, senders = [], number = "" }) {
      const source = Array.isArray(senders) && senders.length
        ? senders
        : [{ senderId: "default", number }];
      const prefix = String(callbacks.DISCONNECT_SENDER_PREFIX || "DS:");
      const rows = source.map((sender, index) => {
        const senderId = String(sender?.senderId || "default");
        const digits = String(sender?.number || "").replace(/\D/g, "");
        const status = sender?.connected === true
          ? "🟢"
          : sender?.connectivityState === "reconnecting"
            ? "🔄"
            : "⚪";
        const label = digits
          ? `${status} +${digits}`
          : `${status} Sender ${index + 1}`;
        return [callback(label, `${prefix}${senderId}`, "danger")];
      });
      rows.push([callback(BUTTON_LABELS.back, callbacks.WA_MENU, "primary")]);
      return Markup.inlineKeyboard(rows);
    },

    formatChoiceKeyboard({ callbacks, speed = 100 }) {
      const selectedSpeed = Number.parseInt(String(speed ?? 100), 10) || 100;
      return Markup.inlineKeyboard([
        [
          callback("📄 Simple", callbacks.FORMAT_SIMPLE, "success"),
          callback("📋 Detail", callbacks.FORMAT_DETAIL, "success"),
        ],
        [
          callback(
            `⚡ Kecepatan・${selectedSpeed}`,
            callbacks.CHECK_SPEED_MENU,
            "primary",
          ),
        ],
        [callback(BUTTON_LABELS.cancel, callbacks.CANCEL_STATE, "danger")],
      ]);
    },

    checkSpeedKeyboard({ callbacks, speed = 100, speedOptions = [] }) {
      const selectedSpeed = Number.parseInt(String(speed ?? 100), 10) || 100;
      const options = Array.isArray(speedOptions) && speedOptions.length
        ? speedOptions
        : [5, 25, 50, 100, 200, 500, 1000];
      const prefix = String(callbacks.CHECK_SPEED_PREFIX || "SPD:");
      const speedButtons = options.map((value) => {
        const numeric = Number.parseInt(String(value), 10);
        const active = numeric === selectedSpeed;
        return callback(
          `${active ? "• " : ""}${numeric}`,
          `${prefix}${numeric}`,
          active ? "success" : "primary",
        );
      });

      return Markup.inlineKeyboard([
        speedButtons.slice(0, 4),
        speedButtons.slice(4),
        [callback("← Kembali", callbacks.CHECK_SPEED_BACK, "primary")],
      ]);
    },

    pairMethodKeyboard({ callbacks }) {
      return Markup.inlineKeyboard([
        [
          callback(BUTTON_LABELS.pairQr, callbacks.PAIR_QR, "primary"),
          callback(BUTTON_LABELS.pairCode, callbacks.PAIR_CODE, "primary"),
        ],
        [callback(BUTTON_LABELS.back, callbacks.WA_MENU, "primary")],
      ]);
    },

    cancelKeyboard({ callbacks }) {
      return grid([callback(BUTTON_LABELS.cancel, callbacks.CANCEL_STATE, "danger")]);
    },

    menuOnlyKeyboard({ callbacks }) {
      return grid([callback(BUTTON_LABELS.menu, callbacks.MENU, "primary")]);
    },

    privateKeyboard(targetUrl) {
      if (!targetUrl) return {};
      return grid([url(BUTTON_LABELS.privateChat, targetUrl, "primary")]);
    },

    groupHelperKeyboard({ targetUrl, callbacks }) {
      return grid([
        callbacks?.WA_MENU ? callback(BUTTON_LABELS.senderMenu, callbacks.WA_MENU, "primary") : null,
        targetUrl ? url(BUTTON_LABELS.privateChat, targetUrl, "primary") : null,
      ]);
    },

    forceJoinKeyboard({
      targets,
      callbacks,
      folderUrl = "",
      withStatus = false,
    }) {
      const normalizedFolderUrl = String(folderUrl || "").trim();
      if (normalizedFolderUrl) {
        return Markup.inlineKeyboard([
          [url(BUTTON_LABELS.addFolder, normalizedFolderUrl, "primary")],
          [callback(BUTTON_LABELS.verify, callbacks.JOIN_VERIFY, "success")],
        ]);
      }

      const buttons = targets.map((target, index) => {
        const number = index + 1;
        const icon = withStatus ? (target.joined ? "✅" : "❌") : "🔗";
        const label = `${icon} Grup ${number}`;
        const style = withStatus ? (target.joined ? "success" : "danger") : "primary";
        return target.url
          ? url(label, target.url, style)
          : callback(label, `noop_${target.index}`, style);
      });
      buttons.push(callback(BUTTON_LABELS.verify, callbacks.JOIN_VERIFY, "success"));
      return grid(buttons);
    },

    officialGroupKeyboard({ targets, targetUrl }) {
      const buttons = targets.map((target, index) =>
        target.url
          ? url(`🔗 Grup ${index + 1}`, target.url, "primary")
          : callback(`⚠️ Grup ${index + 1}`, `noop_${target.index}`, "danger"),
      );
      if (targetUrl) buttons.push(url(BUTTON_LABELS.privateChat, targetUrl, "primary"));
      return grid(buttons);
    },
  };
}

module.exports = {
  createKeyboardPresentation,
};
