const REPORT_WIDTH = 32;
const REPORT_LINE = "─".repeat(REPORT_WIDTH);
const REPORT_DOUBLE = "═".repeat(REPORT_WIDTH);
const CAPTION_WIDTH = 28;

function formatReportNumber(value) {
  return new Intl.NumberFormat("id-ID").format(Math.max(0, Number(value) || 0));
}

function reportPercent(part, total) {
  const denominator = Math.max(0, Number(total) || 0);
  if (!denominator) return "0.0%";
  return `${(((Number(part) || 0) / denominator) * 100).toFixed(1)}%`;
}

function getReportCounts(summary = {}) {
  const groupCounts = summary.groupCounts || {};
  const groups = summary.groups || {};
  const readGroup = (name, countKey) => {
    if (Object.prototype.hasOwnProperty.call(groupCounts, name)) {
      return Number(groupCounts[name]) || 0;
    }
    if (Array.isArray(groups[name])) return groups[name].length;
    if (countKey && summary.counts) return Number(summary.counts[countKey]) || 0;
    return 0;
  };
  return {
    total: Number(summary.total) || 0,
    registered: Number(summary.registered) || 0,
    notRegistered: Number(summary.notRegistered) || 0,
    failed: Number(summary.failedChecks) || 0,
    businessMeta: Number(summary.businessMetaCount) || 0,
    verified: readGroup("Verified Meta Business", "verified"),
    standard: readGroup("Standard Meta Business", "standard"),
    waBusiness: readGroup("WA Business Biasa", "wabiz"),
    regular: readGroup("WhatsApp Biasa", "wa"),
    agentAi: Number(summary.agentAiCount) || 0,
  };
}

function centerText(text, width = REPORT_WIDTH) {
  const value = String(text || "");
  if (value.length >= width) return value.slice(0, width);
  const left = Math.floor((width - value.length) / 2);
  const right = width - value.length - left;
  return `${" ".repeat(left)}${value}${" ".repeat(right)}`;
}

function wrapWords(value, width = REPORT_WIDTH - 4) {
  const text = String(value ?? "").replace(/\s+/g, " ").trim();
  if (!text) return [""];
  if (text.length <= width) return [text];
  const words = text.split(" ");
  const lines = [];
  let line = "";
  for (const word of words) {
    if (!line) {
      if (word.length <= width) {
        line = word;
      } else {
        for (let i = 0; i < word.length; i += width) lines.push(word.slice(i, i + width));
      }
      continue;
    }
    if (`${line} ${word}`.length <= width) line = `${line} ${word}`;
    else {
      lines.push(line);
      if (word.length <= width) line = word;
      else {
        for (let i = 0; i < word.length; i += width) lines.push(word.slice(i, i + width));
        line = "";
      }
    }
  }
  if (line) lines.push(line);
  return lines.length ? lines : [""];
}

function infoField(label, value) {
  const prefix = `${String(label || "-")} : `;
  const available = Math.max(12, REPORT_WIDTH - prefix.length);
  const chunks = wrapWords(value, available);
  const lines = [`${prefix}${chunks[0]}`];
  const indent = " ".repeat(prefix.length);
  for (const chunk of chunks.slice(1)) lines.push(`${indent}${chunk}`);
  return lines;
}

function buildRegistrationYearsBlock(years = {}) {
  const entries = Object.entries(years || {}).sort((a, b) => a[0].localeCompare(b[0]));
  if (!entries.length) return "";
  const lines = ["REGISTRATION TIMELINE", REPORT_LINE, ""];
  for (const [year, count] of entries) {
    lines.push(`${year} │ ${formatReportNumber(count)}`);
  }
  return lines.join("\n");
}

function buildReportHeader(summary = {}, titleName = "MOCI", format = "DETAIL", options = {}) {
  const c = getReportCounts(summary);
  const normalizedFormat = String(format || "DETAIL").toUpperCase();
  const withBio = Number(summary.bioDetected) || 0;
  const withoutBio = Math.max(0, c.registered - withBio);
  const sourceName = String(options.sourceName || "").trim();
  const lines = [
    `╭${REPORT_LINE}╮`,
    `│${centerText("MOCI WS CHECKER")}│`,
    `│${centerText(`${normalizedFormat} SCAN REPORT`)}│`,
    `╰${REPORT_LINE}╯`,
    "",
    "01 / SCAN SUMMARY",
    REPORT_LINE,
    "",
  ];

  if (sourceName) lines.push(...infoField("Source", sourceName));
  lines.push(
    ...infoField("Mode", normalizedFormat),
    ...infoField("Total", formatReportNumber(c.total)),
    ...infoField("Status", "COMPLETE"),
    "",
    "ACCOUNT SUMMARY",
    REPORT_LINE,
    "",
    ...infoField("Registered", `${formatReportNumber(c.registered)}  · ${reportPercent(c.registered, c.total)}`),
    ...infoField("Not Registered", `${formatReportNumber(c.notRegistered)}  · ${reportPercent(c.notRegistered, c.total)}`),
    ...infoField("Failed", `${formatReportNumber(c.failed)}  · ${reportPercent(c.failed, c.total)}`),
    "",
    ...infoField("Business Meta", formatReportNumber(c.businessMeta)),
    ...infoField("Verified", formatReportNumber(c.verified)),
    ...infoField("Standard", formatReportNumber(c.standard)),
    ...infoField("WA Business", formatReportNumber(c.waBusiness)),
    ...infoField("Agent AI", formatReportNumber(c.agentAi)),
    ...infoField("WA Biasa", formatReportNumber(c.regular)),
  );

  if (normalizedFormat === "DETAIL") {
    lines.push(
      "",
      "PROFILE DATA",
      REPORT_LINE,
      "",
      ...infoField("With Bio", formatReportNumber(withBio)),
      ...infoField("Without Bio", formatReportNumber(withoutBio)),
      ...infoField("Profile Photo", formatReportNumber(summary.photoDetected)),
      ...infoField("Business Email", formatReportNumber(summary.emailDetected)),
      ...infoField("Business Website", formatReportNumber(summary.websiteDetected)),
    );
  }

  const years = buildRegistrationYearsBlock(summary.registrationYears);
  if (years) lines.push("", years);

  return `${lines.join("\n")}\n\n`;
}

function buildMajorSectionHeader(index, title) {
  return `${String(index).padStart(2, "0")} / ${String(title || "").toUpperCase()}\n${REPORT_DOUBLE}\n\n`;
}

function buildSectionHeader(_icon, title, count) {
  const label = String(title || "").toUpperCase();
  const compact = `${label} · ${formatReportNumber(count)}`;
  if (compact.length <= REPORT_WIDTH - 3) {
    const ruleWidth = Math.max(10, Math.min(REPORT_WIDTH - 1, compact.length + 2));
    return `┌─ ${compact}\n└${"─".repeat(ruleWidth)}\n\n`;
  }
  const countText = `${formatReportNumber(count)} akun`;
  const ruleWidth = Math.max(10, Math.min(REPORT_WIDTH - 1, Math.max(label.length, countText.length) + 2));
  return `┌─ ${label}\n│  ${countText}\n└${"─".repeat(ruleWidth)}\n\n`;
}

function buildReportFooter(producer, format = "DETAIL", total = null) {
  const lines = [
    REPORT_DOUBLE,
    centerText("END OF REPORT"),
    REPORT_DOUBLE,
    "",
  ];
  if (total !== null && total !== undefined) {
    lines.push(...infoField("Total", formatReportNumber(total)));
  }
  lines.push(
    ...infoField("Report", String(format || "DETAIL").toUpperCase()),
    ...infoField("Status", "COMPLETE"),
    "",
    ...wrapWords(`MOCI WS CHECKER${producer ? ` · ${String(producer)}` : ""}`, REPORT_WIDTH),
    "",
  );
  return lines.join("\n");
}

function captionHeader(formatLabel) {
  const inner = "─".repeat(CAPTION_WIDTH);
  return [
    `╭${inner}╮`,
    `│${centerText("MOCI · SCAN RESULT", CAPTION_WIDTH)}│`,
    `│${centerText(formatLabel, CAPTION_WIDTH)}│`,
    `╰${inner}╯`,
  ];
}

function buildResultCaption(summary = {}, format = null) {
  const c = getReportCounts(summary);
  const formatLabel = String(format || "hasil").toUpperCase();
  const isDetail = formatLabel === "DETAIL";
  const withBio = Number(summary.bioDetected) || 0;
  const withoutBio = Math.max(0, c.registered - withBio);
  const lines = [
    ...captionHeader(formatLabel),
    "",
    "┌─ ACCOUNT STATUS",
    `├ Total : ${formatReportNumber(c.total)}`,
    `├ Terdaftar : ${formatReportNumber(c.registered)} · ${reportPercent(c.registered, c.total)}`,
    `├ Tidak terdaftar : ${formatReportNumber(c.notRegistered)}`,
    `│  ${reportPercent(c.notRegistered, c.total)}`,
    `└ Gagal : ${formatReportNumber(c.failed)}`,
    "",
    isDetail ? "┌─ PROFILE DATA" : "┌─ CLASSIFICATION",
  ];

  if (isDetail) {
    lines.push(
      `├ Punya bio : ${formatReportNumber(withBio)}`,
      `├ Tanpa bio : ${formatReportNumber(withoutBio)}`,
      `├ Business Meta : ${formatReportNumber(c.businessMeta)}`,
      `├ Agent AI : ${formatReportNumber(c.agentAi)}`,
      `└ WA Biasa : ${formatReportNumber(c.regular)}`,
      "",
      "────── DETAIL READY ──────",
    );
  } else {
    lines.push(
      `├ Business Meta : ${formatReportNumber(c.businessMeta)}`,
      `│  ├ Verified : ${formatReportNumber(c.verified)}`,
      `│  ├ Standard : ${formatReportNumber(c.standard)}`,
      `│  └ WA Business : ${formatReportNumber(c.waBusiness)}`,
      `├ Agent AI : ${formatReportNumber(c.agentAi)}`,
      `└ WA Biasa : ${formatReportNumber(c.regular)}`,
      "",
      "───── SCAN COMPLETE ─────",
    );
  }
  lines.push("MOCI WS CHECKER");
  return lines.join("\n");
}

module.exports = {
  REPORT_WIDTH,
  REPORT_LINE,
  REPORT_DOUBLE,
  buildRegistrationYearsBlock,
  buildReportHeader,
  buildMajorSectionHeader,
  buildSectionHeader,
  buildReportFooter,
  buildResultCaption,
  formatReportNumber,
  reportPercent,
};
