const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const { once } = require("node:events");
const { finished } = require("node:stream/promises");
const {
  classifyResult,
  formatDetailedResultItem,
  formatQuickResultItem,
  isFilled,
} = require("./txt-report");
const { reportFooterName } = require("../../checkbio_utils");
const {
  buildReportHeader,
  buildMajorSectionHeader,
  buildSectionHeader,
  buildReportFooter,
} = require("./report-ui");
const { createTempWorkspace } = require("../services/temp-dir.service");
const { sanitizeFileStem } = require("../utils/file-name");

const QUICK_SECTIONS = [
  ["Verified Meta Business", "VERIFIED", "quick-verified.part"],
  ["Standard Meta Business", "STANDARD", "quick-standard.part"],
  ["WA Business Biasa", "WA BUSINESS", "quick-wabiz.part"],
  ["WhatsApp Biasa", "WA BIASA", "quick-regular.part"],
  ["Tidak Terdaftar", "NOT REGISTERED", "quick-not-registered.part"],
  ["Gagal Dicek", "FAILED", "quick-failed.part"],
];

const DETAIL_SECTIONS = [
  ["businessWithBio", "BUSINESS · WITH BIO", true, "detail-business-bio.part"],
  ["businessNoBio", "BUSINESS · NO BIO", true, "detail-business-no-bio.part"],
  ["normalWithBio", "WA BIASA · WITH BIO", true, "detail-normal-bio.part"],
  ["normalNoBio", "WA BIASA · NO BIO", false, "detail-normal-no-bio.part"],
  ["notRegistered", "NOT REGISTERED", false, "detail-not-registered.part"],
  ["failed", "FAILED", false, "detail-failed.part"],
];

async function writeWithBackpressure(stream, content) {
  if (stream.write(content)) return;
  await once(stream, "drain");
}

async function copyFileIntoStream(filePath, output) {
  for await (const chunk of fs.createReadStream(filePath)) {
    await writeWithBackpressure(output, chunk);
  }
}

function createSummaryAccumulator() {
  return {
    total: 0,
    registered: 0,
    bioDetected: 0,
    photoDetected: 0,
    businessDetected: 0,
    emailDetected: 0,
    websiteDetected: 0,
    lastSeenDetected: 0,
    notRegistered: 0,
    failedChecks: 0,
    counts: { verified: 0, standard: 0, wabiz: 0, wa: 0, not: 0, failed: 0 },
    groupCounts: Object.fromEntries(QUICK_SECTIONS.map(([classification]) => [classification, 0])),
    hasBioCount: 0,
    noBioCount: 0,
    newAccountCount: 0,
    flaggedCount: 0,
    businessMetaCount: 0,
    agentAiCount: 0,
    registrationYears: {},
  };
}

function extractRegYear(result) {
  const text = String(result?.memberSince || "");
  const m = text.match(/(20\d{2})/);
  return m ? m[1] : null;
}

function accumulateSummary(summary, result) {
  const classification = classifyResult(result);
  summary.total++;
  summary.groupCounts[classification]++;

  if (result.exists === true) summary.registered++;
  if (result.exists && isFilled(result.bio)) summary.bioDetected++;
  if (result.exists && result.hasPhoto) summary.photoDetected++;
  if (result.exists && result.klasifikasi !== "WhatsApp Biasa" && classification !== "WhatsApp Biasa") {
    summary.businessDetected++;
  }
  if (result.exists && isFilled(result.email)) summary.emailDetected++;
  if (result.exists && isFilled(result.website)) summary.websiteDetected++;
  if (result.exists && isFilled(result.lastSeen)) summary.lastSeenDetected++;

  const businessMetaClasses = [
    "Verified Meta Business",
    "Standard Meta Business",
    "WA Business Biasa",
  ];
  if (result.exists && businessMetaClasses.includes(classification)) {
    summary.businessMetaCount++;
    if (isFilled(result.bio)) summary.hasBioCount++;
    else summary.noBioCount++;
    const ms = String(result.memberSince || "").toLowerCase();
    if (ms.includes("last month") || ms.includes("this month")) summary.newAccountCount++;
    if (result.verifiedRevoked === true) summary.flaggedCount++;
    const at = String(result.automatedType || "").toLowerCase();
    if (at && at !== "unknown") summary.agentAiCount++;
    const year = extractRegYear(result);
    if (year) summary.registrationYears[year] = (summary.registrationYears[year] || 0) + 1;
  }

  if (classification === "Verified Meta Business") summary.counts.verified++;
  else if (classification === "Standard Meta Business") summary.counts.standard++;
  else if (classification === "WA Business Biasa") summary.counts.wabiz++;
  else if (classification === "WhatsApp Biasa") summary.counts.wa++;
  else if (classification === "Gagal Dicek") {
    summary.counts.failed++;
    summary.failedChecks++;
  } else {
    summary.counts.not++;
    summary.notRegistered++;
  }
  return classification;
}

function detailSectionKey(result, classification) {
  if (classification === "Tidak Terdaftar") return "notRegistered";
  if (classification === "Gagal Dicek") return "failed";
  const isBusiness = [
    "Verified Meta Business",
    "Standard Meta Business",
    "WA Business Biasa",
  ].includes(classification);
  if (isBusiness) return isFilled(result.bio) ? "businessWithBio" : "businessNoBio";
  return isFilled(result.bio) ? "normalWithBio" : "normalNoBio";
}

async function createStreamingTxtReport(baseName, titleName = "MOCI", options = {}) {
  const tempDir = await createTempWorkspace("cekbio-report-");
  const summary = createSummaryAccumulator();
  const quickIndexes = new Map();
  const detailIndexes = new Map();
  const quickSections = new Map();
  const detailSections = new Map();

  for (const [classification, title, filename] of QUICK_SECTIONS) {
    const filePath = path.join(tempDir, filename);
    quickSections.set(classification, {
      classification,
      title,
      filePath,
      stream: fs.createWriteStream(filePath, { flags: "wx", mode: 0o600 }),
    });
  }
  for (const [key, title, verbose, filename] of DETAIL_SECTIONS) {
    const filePath = path.join(tempDir, filename);
    detailSections.set(key, {
      key,
      title,
      verbose,
      count: 0,
      filePath,
      stream: fs.createWriteStream(filePath, { flags: "wx", mode: 0o600 }),
    });
  }

  let finalized = false;

  return {
    summary,
    async append(result) {
      if (finalized) throw new Error("Report sudah difinalisasi.");
      const classification = accumulateSummary(summary, result);

      const quick = quickSections.get(classification);
      const quickIndex = (quickIndexes.get(classification) || 0) + 1;
      quickIndexes.set(classification, quickIndex);
      await writeWithBackpressure(quick.stream, formatQuickResultItem(result, quickIndex));

      const detailKey = detailSectionKey(result, classification);
      const detail = detailSections.get(detailKey);
      const detailIndex = (detailIndexes.get(detailKey) || 0) + 1;
      detailIndexes.set(detailKey, detailIndex);
      detail.count++;
      await writeWithBackpressure(
        detail.stream,
        detail.verbose
          ? formatDetailedResultItem(result, detailIndex)
          : formatQuickResultItem(result, detailIndex),
      );
    },
    async finalize() {
      if (finalized) throw new Error("Report sudah difinalisasi.");
      finalized = true;
      for (const section of [...quickSections.values(), ...detailSections.values()]) {
        section.stream.end();
        await finished(section.stream);
      }

      const rawBaseName = path.basename(
        String(baseName || "cekbio-report"),
        path.extname(String(baseName || "")),
      );
      const safeBaseName = sanitizeFileStem(rawBaseName, {
        fallback: "cekbio-report",
        maxLength: 160,
      });
      const finalPath = path.join(tempDir, `${safeBaseName}.txt`);
      const output = fs.createWriteStream(finalPath, { flags: "wx", mode: 0o600 });
      try {
        await writeWithBackpressure(output, buildReportHeader(summary, titleName, "DETAIL", options));
        await writeWithBackpressure(output, buildMajorSectionHeader(2, "QUICK RESULT"));
        for (const section of quickSections.values()) {
          const count = summary.groupCounts[section.classification];
          await writeWithBackpressure(output, buildSectionHeader("", section.title, count));
          if (!count) await writeWithBackpressure(output, "(Tidak ada)\n\n");
          else {
            await copyFileIntoStream(section.filePath, output);
            await writeWithBackpressure(output, "\n");
          }
        }

        await writeWithBackpressure(output, buildMajorSectionHeader(3, "ACCOUNT DETAILS"));
        for (const section of detailSections.values()) {
          await writeWithBackpressure(output, buildSectionHeader("", section.title, section.count));
          if (!section.count) await writeWithBackpressure(output, "(Tidak ada)\n\n");
          else {
            await copyFileIntoStream(section.filePath, output);
            await writeWithBackpressure(output, "\n");
          }
        }

        await writeWithBackpressure(
          output,
          buildReportFooter(reportFooterName(titleName), "DETAIL", summary.total),
        );
        output.end();
        await finished(output);
        return { filePath: finalPath, summary };
      } catch (error) {
        output.destroy();
        throw error;
      }
    },
    async cleanup() {
      for (const section of [...quickSections.values(), ...detailSections.values()]) {
        section.stream.destroy();
      }
      await fsp.rm(tempDir, { recursive: true, force: true });
    },
  };
}

module.exports = {
  createStreamingTxtReport,
};
