const reportUtils = require("../../checkbio_utils");

// Wrapper laporan non-streaming yang dipakai alur /cekbio.
// Jangan meneruskan variabel emoji eksternal: buildTxtReport sudah memiliki
// seluruh badge/ikon default yang diperlukan.
function buildTXT(results, titleName = "MOCI") {
  return reportUtils.buildTxtReport(results, titleName);
}

module.exports = {
  buildTXT,
  classifyResult: reportUtils.classifyResult,
  filled: reportUtils.filled,
  formatDetailedResultItem: reportUtils.formatDetailedResultItem,
  formatQuickResultItem: reportUtils.formatQuickResultItem,
  isFilled: reportUtils.isFilled,
};
