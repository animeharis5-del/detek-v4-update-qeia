const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const { once } = require("node:events");
const { finished } = require("node:stream/promises");
const { classifyResult, formatQuickResultItem } = require("./txt-report");
const { reportFooterName } = require("../../checkbio_utils");
const {
  buildReportHeader,
  buildMajorSectionHeader,
  buildSectionHeader,
  buildReportFooter,
} = require("./report-ui");
const { createTempWorkspace } = require("../services/temp-dir.service");
const { sanitizeFileStem } = require("../utils/file-name");

const SUMMARY_REPORT_SECTIONS = [
  ["Verified Meta Business", "VERIFIED", "verified.part"],
  ["Standard Meta Business", "STANDARD", "standard.part"],
  ["WA Business Biasa", "WA BUSINESS", "wabiz.part"],
  ["WhatsApp Biasa", "WA BIASA", "regular.part"],
  ["Tidak Terdaftar", "NOT REGISTERED", "not-registered.part"],
  ["Gagal Dicek", "FAILED", "failed.part"],
];

async function writeWithBackpressure(stream, content) {
  if (stream.write(content)) return;
  await once(stream, "drain");
}

async function copyFileIntoStream(filePath, output) {
  for await (const chunk of fs.createReadStream(filePath)) {
    await writeWithBackpressure(output, chunk);
  }
}

function deriveSummaryReportBaseName(baseName) {
  const safeInput = sanitizeFileStem(baseName, { fallback: "cekbio", maxLength: 140 });
  const suffix = safeInput
    .replace(/^cekbio_detail_/iu, "")
    .replace(/^cekbio(?:txt)?_/iu, "")
    .replace(/^ringkas_/iu, "");
  return sanitizeFileStem(`cekbio_simple_${suffix || Date.now()}`, {
    fallback: `cekbio_simple_${Date.now()}`,
    maxLength: 160,
  });
}

function createSummaryAccumulator() {
  return {
    total: 0,
    registered: 0,
    notRegistered: 0,
    failedChecks: 0,
    businessMetaCount: 0,
    agentAiCount: 0,
    registrationYears: {},
    groupCounts: Object.fromEntries(
      SUMMARY_REPORT_SECTIONS.map(([classification]) => [classification, 0]),
    ),
  };
}

function accumulateSummary(summary, result) {
  const classification = classifyResult(result);
  summary.total++;
  summary.groupCounts[classification]++;
  if (result?.exists === true && !result?.error) summary.registered++;
  if (classification === "Tidak Terdaftar") summary.notRegistered++;
  if (classification === "Gagal Dicek") summary.failedChecks++;
  const businessMetaClasses = [
    "Verified Meta Business",
    "Standard Meta Business",
    "WA Business Biasa",
  ];
  if (result?.exists && businessMetaClasses.includes(classification)) {
    summary.businessMetaCount++;
    const at = String(result.automatedType || "").toLowerCase();
    if (at && at !== "unknown") summary.agentAiCount++;
    const ym = String(result.memberSince || "").match(/(20\d{2})/);
    if (ym) summary.registrationYears[ym[1]] = (summary.registrationYears[ym[1]] || 0) + 1;
  }
  return classification;
}

async function createStreamingSummaryOnlyReport(baseName, titleName = "MOCI", options = {}) {
  const tempDir = await createTempWorkspace("cekbio-summary-report-");
  const summary = createSummaryAccumulator();
  const indexes = new Map();
  const sections = new Map();

  for (const [classification, title, filename] of SUMMARY_REPORT_SECTIONS) {
    const filePath = path.join(tempDir, filename);
    sections.set(classification, {
      classification,
      title,
      filePath,
      stream: fs.createWriteStream(filePath, { flags: "wx", mode: 0o600 }),
    });
  }

  let finalized = false;

  return {
    summary,
    async append(result) {
      if (finalized) throw new Error("Report ringkas sudah difinalisasi.");
      const classification = accumulateSummary(summary, result);
      const section = sections.get(classification);
      const index = (indexes.get(classification) || 0) + 1;
      indexes.set(classification, index);
      await writeWithBackpressure(section.stream, formatQuickResultItem(result, index));
    },
    async finalize() {
      if (finalized) throw new Error("Report ringkas sudah difinalisasi.");
      finalized = true;
      for (const section of sections.values()) {
        section.stream.end();
        await finished(section.stream);
      }

      const finalBaseName = deriveSummaryReportBaseName(baseName);
      const finalPath = path.join(tempDir, `${finalBaseName}.txt`);
      const output = fs.createWriteStream(finalPath, { flags: "wx", mode: 0o600 });
      try {
        await writeWithBackpressure(output, buildReportHeader(summary, titleName, "SIMPLE", options));
        await writeWithBackpressure(output, buildMajorSectionHeader(2, "QUICK RESULT"));
        for (const section of sections.values()) {
          const count = summary.groupCounts[section.classification];
          await writeWithBackpressure(output, buildSectionHeader("", section.title, count));
          if (!count) await writeWithBackpressure(output, "(Tidak ada)\n\n");
          else {
            await copyFileIntoStream(section.filePath, output);
            await writeWithBackpressure(output, "\n");
          }
        }
        await writeWithBackpressure(
          output,
          buildReportFooter(reportFooterName(titleName), "SIMPLE", summary.total),
        );
        output.end();
        await finished(output);
        return { filePath: finalPath, summary };
      } catch (error) {
        output.destroy();
        throw error;
      }
    },
    async cleanup() {
      for (const section of sections.values()) section.stream.destroy();
      await fsp.rm(tempDir, { recursive: true, force: true });
    },
  };
}

module.exports = {
  createStreamingSummaryOnlyReport,
  deriveSummaryReportBaseName,
};
