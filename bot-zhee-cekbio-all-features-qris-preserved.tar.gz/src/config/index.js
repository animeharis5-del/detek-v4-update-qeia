const { applyPrivateUmask } = require("../services/file-permissions.service");

applyPrivateUmask();

require("dotenv").config();

const { resolveTempDirPath } = require("../services/temp-dir.service");

function requiredEnv(name) {
  const value = String(process.env[name] || "").trim();
  if (!value) throw new Error(`Environment variable ${name} wajib diisi.`);
  return value;
}

function parseCsv(value) {
  return String(value || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

function parsePositiveIntegers(value) {
  return parseCsv(value)
    .map(Number)
    .filter((item) => Number.isSafeInteger(item) && item > 0);
}

function parseIntegerEnv(name, fallback, { min, max } = {}) {
  const parsed = Number(process.env[name] ?? fallback);
  if (!Number.isInteger(parsed)) throw new Error(`${name} harus berupa integer.`);
  if (min !== undefined && parsed < min) throw new Error(`${name} minimal ${min}.`);
  if (max !== undefined && parsed > max) throw new Error(`${name} maksimal ${max}.`);
  return parsed;
}

function buildForceJoinTargets() {
  return Array.from({ length: 10 }, (_, index) => {
    const number = index + 1;
    return {
      chat: String(process.env[`FORCE_JOIN_${number}_CHAT`] || "").trim(),
      title: String(process.env[`FORCE_JOIN_${number}_TITLE`] || "").trim(),
      url: String(process.env[`FORCE_JOIN_${number}_URL`] || "").trim(),
    };
  }).filter((target) => target.chat);
}

module.exports = {
  BOT_TOKEN: requiredEnv("BOT_TOKEN"),
  OWNERS: parsePositiveIntegers(process.env.OWNERS),
  PAIRING_CODE: requiredEnv("PAIRING_CODE").toUpperCase(),

  CHUNK_SIZE: parseIntegerEnv("CHUNK_SIZE", 200, { min: 1, max: 5000 }),
  CHECK_DELAY_MS: parseIntegerEnv("CHECK_DELAY_MS", 250, { min: 0, max: 10000 }),
  PROFILE_FETCH_DELAY_MS: parseIntegerEnv("PROFILE_FETCH_DELAY_MS", 750, {
    min: 0,
    max: 10000,
  }),
  PROFILE_PRESENCE_TIMEOUT_MS: parseIntegerEnv("PROFILE_PRESENCE_TIMEOUT_MS", 1500, {
    min: 250,
    max: 15000,
  }),
  MAX_CONCURRENCY: parseIntegerEnv("MAX_CONCURRENCY", 3, { min: 1, max: 10 }),
  // Tahap 9: worker multi-Sender boleh menskalakan concurrency mengikuti jumlah
  // Sender sehat. Ini tetap bounded per user agar banyak user aktif tidak membuat
  // satu job memonopoli event loop/socket.
  MAX_MULTI_SENDER_CONCURRENCY: parseIntegerEnv("MAX_MULTI_SENDER_CONCURRENCY", 12, {
    min: 1,
    max: 64,
  }),
  WA_QUERY_TIMEOUT_MS: parseIntegerEnv("WA_QUERY_TIMEOUT_MS", 25000, {
    min: 5000,
    max: 120000,
  }),
  CHECK_JOB_TIMEOUT_MS: parseIntegerEnv(
    "CHECK_JOB_TIMEOUT_MS",
    12 * 60 * 60 * 1000,
    { min: 60000, max: 24 * 60 * 60 * 1000 },
  ),
  DOWNLOAD_TIMEOUT_MS: parseIntegerEnv("DOWNLOAD_TIMEOUT_MS", 60000, {
    min: 5000,
    max: 300000,
  }),
  DOWNLOAD_RETRY_ATTEMPTS: parseIntegerEnv("DOWNLOAD_RETRY_ATTEMPTS", 4, {
    min: 1,
    max: 10,
  }),
  DOWNLOAD_RETRY_BASE_MS: parseIntegerEnv("DOWNLOAD_RETRY_BASE_MS", 1000, {
    min: 0,
    max: 30000,
  }),
  ALLOWED_GROUP_CHATS: parseCsv(process.env.ALLOWED_GROUP_CHATS),
  FORCE_JOIN_TARGETS: buildForceJoinTargets(),
  FORCE_JOIN_FOLDER_URL: String(process.env.FORCE_JOIN_FOLDER_URL || "").trim(),
  CHECKS_PER_TOKEN: parseIntegerEnv("CHECKS_PER_TOKEN", 50, { min: 1, max: 100000 }),
  ADMIN_CHECKS_PER_TOKEN: parseIntegerEnv("ADMIN_CHECKS_PER_TOKEN", 50, { min: 1, max: 100000 }),
  BUATQRIS_BASE_URL: String(process.env.BUATQRIS_BASE_URL || "https://api.buatqris.site").trim(),
  BUATQRIS_ACCOUNT_ID: String(process.env.BUATQRIS_ACCOUNT_ID || "").trim(),
  BUATQRIS_SECRET_TOKEN: String(process.env.BUATQRIS_SECRET_TOKEN || "").trim(),
  BUATQRIS_SIGNING_SECRET: String(process.env.BUATQRIS_SIGNING_SECRET || "").trim(),
  WEBHOOK_HOST: String(process.env.WEBHOOK_HOST || "0.0.0.0").trim(),
  WEBHOOK_PORT: parseIntegerEnv("WEBHOOK_PORT", 8080, { min: 1, max: 65535 }),
  OWNER_CONTACT_USERNAME: String(process.env.OWNER_CONTACT_USERNAME || "").trim().replace(/^@/, ""),
  TRANSACTION_NOTIFY_CHAT: String(process.env.TRANSACTION_NOTIFY_CHAT || "").trim(),
  TEMP_DIR: resolveTempDirPath(process.env.TEMP_DIR),
};
