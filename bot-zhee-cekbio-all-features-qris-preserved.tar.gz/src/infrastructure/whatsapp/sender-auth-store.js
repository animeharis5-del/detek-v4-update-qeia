const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");

const AUTH_ROOT = path.join(process.cwd(), "wa_auth");
const SENDERS_DIR_NAME = "senders";
const DEFAULT_SENDER_ID = "default";

function normalizeUserId(userId) {
  const id = String(userId ?? "").trim();
  if (!/^\d+$/.test(id)) throw new Error("Telegram user id tidak valid.");
  return id;
}

function normalizeSenderId(senderId) {
  const id = String(senderId ?? "").trim();
  if (!/^[A-Za-z0-9_-]{1,64}$/.test(id)) {
    throw new Error("Sender id tidak valid.");
  }
  return id;
}

function getUserAuthPath(userId) {
  return path.join(AUTH_ROOT, normalizeUserId(userId));
}

function getSendersRootPath(userId) {
  return path.join(getUserAuthPath(userId), SENDERS_DIR_NAME);
}

function getSenderAuthPath(userId, senderId = DEFAULT_SENDER_ID) {
  return path.join(
    getSendersRootPath(userId),
    normalizeSenderId(senderId),
  );
}

function getSenderCredsPath(userId, senderId = DEFAULT_SENDER_ID) {
  return path.join(getSenderAuthPath(userId, senderId), "creds.json");
}

function ensurePrivateDirectorySync(targetPath) {
  fs.mkdirSync(targetPath, { recursive: true, mode: 0o700 });
  try {
    fs.chmodSync(targetPath, 0o700);
  } catch {
    // Best effort untuk platform yang tidak menerapkan permission POSIX.
  }
}

/**
 * Migrasi layout single-sender lama tanpa kehilangan sesi:
 *
 *   wa_auth/<userId>/creds.json
 *   wa_auth/<userId>/pre-key-*.json
 *
 * menjadi:
 *
 *   wa_auth/<userId>/senders/default/creds.json
 *   wa_auth/<userId>/senders/default/pre-key-*.json
 *
 * Folder `default` sengaja dipakai sebagai compatibility slot. Tahap backend
 * berikutnya dapat membuat sender tambahan tanpa menimpa auth sender ini.
 */
function migrateLegacyAuthIfNeeded(userId) {
  const safeUserId = normalizeUserId(userId);
  const userRoot = getUserAuthPath(safeUserId);
  if (!fs.existsSync(userRoot)) return false;

  const entries = fs.readdirSync(userRoot, { withFileTypes: true });
  const legacyEntries = entries.filter(
    (entry) => entry.name !== SENDERS_DIR_NAME,
  );
  if (!legacyEntries.length) return false;

  const defaultPath = getSenderAuthPath(safeUserId, DEFAULT_SENDER_ID);
  ensurePrivateDirectorySync(defaultPath);

  for (const entry of legacyEntries) {
    const source = path.join(userRoot, entry.name);
    const target = path.join(defaultPath, entry.name);

    // Jangan pernah menimpa auth yang sudah berada di slot baru. Jika migrasi
    // pernah terhenti di tengah jalan, data baru tetap menjadi sumber utama.
    if (fs.existsSync(target)) continue;
    fs.renameSync(source, target);
  }

  return true;
}

function listSenderIds(userId) {
  const safeUserId = normalizeUserId(userId);
  migrateLegacyAuthIfNeeded(safeUserId);
  const sendersRoot = getSendersRootPath(safeUserId);
  if (!fs.existsSync(sendersRoot)) return [];

  return fs
    .readdirSync(sendersRoot, { withFileTypes: true })
    .filter(
      (entry) =>
        entry.isDirectory() && /^[A-Za-z0-9_-]{1,64}$/.test(entry.name),
    )
    .map((entry) => entry.name)
    .sort();
}

function createSenderId(userId) {
  const existing = new Set(listSenderIds(userId));
  for (let attempt = 0; attempt < 20; attempt += 1) {
    const stamp = Date.now().toString(36);
    const random = crypto.randomBytes(4).toString("hex");
    const candidate = `sender_${stamp}_${random}`;
    if (!existing.has(candidate)) return candidate;
  }
  throw new Error("Gagal membuat sender id unik.");
}

/**
 * Menyediakan ruang auth independen untuk satu sender. Fungsi ini belum
 * menyalakan socket Baileys; tujuan Tahap 1 hanya membangun fondasi storage.
 */
function createSenderSlot(userId, senderId = null) {
  const safeUserId = normalizeUserId(userId);
  migrateLegacyAuthIfNeeded(safeUserId);
  const safeSenderId = senderId
    ? normalizeSenderId(senderId)
    : createSenderId(safeUserId);
  const authPath = getSenderAuthPath(safeUserId, safeSenderId);
  ensurePrivateDirectorySync(authPath);
  return {
    userId: safeUserId,
    senderId: safeSenderId,
    authPath,
  };
}

function ensureDefaultSenderSlot(userId) {
  return createSenderSlot(userId, DEFAULT_SENDER_ID);
}

function pruneEmptySenderContainers(userId) {
  const safeUserId = normalizeUserId(userId);
  const sendersRoot = getSendersRootPath(safeUserId);
  const userRoot = getUserAuthPath(safeUserId);

  try {
    if (fs.existsSync(sendersRoot) && fs.readdirSync(sendersRoot).length === 0) {
      fs.rmdirSync(sendersRoot);
    }
  } catch {
    // Best effort. Folder non-empty harus tetap dipertahankan.
  }

  try {
    if (fs.existsSync(userRoot) && fs.readdirSync(userRoot).length === 0) {
      fs.rmdirSync(userRoot);
    }
  } catch {
    // Best effort. Sender lain tidak boleh ikut terhapus.
  }
}

module.exports = {
  AUTH_ROOT,
  SENDERS_DIR_NAME,
  DEFAULT_SENDER_ID,
  normalizeUserId,
  normalizeSenderId,
  getUserAuthPath,
  getSendersRootPath,
  getSenderAuthPath,
  getSenderCredsPath,
  migrateLegacyAuthIfNeeded,
  listSenderIds,
  createSenderId,
  createSenderSlot,
  ensureDefaultSenderSlot,
  pruneEmptySenderContainers,
};
