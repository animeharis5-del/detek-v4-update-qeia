const fsp = require("node:fs/promises");
const path = require("node:path");

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function inspectAuthPath(authPath) {
  try {
    const stats = await fsp.lstat(authPath);
    if (!stats.isDirectory()) {
      return {
        exists: true,
        clean: false,
        entries: [path.basename(authPath)],
      };
    }

    const entries = [];
    async function walk(currentPath, relativeBase = "") {
      const children = await fsp.readdir(currentPath, { withFileTypes: true });
      for (const child of children) {
        const relativePath = path.join(relativeBase, child.name);
        entries.push(relativePath);
        if (child.isDirectory()) {
          await walk(path.join(currentPath, child.name), relativePath);
        }
      }
    }

    await walk(authPath);
    return {
      exists: true,
      clean: entries.length === 0,
      entries,
    };
  } catch (error) {
    if (error?.code === "ENOENT") {
      return { exists: false, clean: true, entries: [] };
    }
    throw error;
  }
}

async function verifyAuthPathClean(authPath) {
  const inspection = await inspectAuthPath(authPath);
  if (!inspection.clean) {
    const error = new Error(
      `Folder auth WA belum bersih: ${inspection.entries.slice(0, 10).join(", ")}`,
    );
    error.code = "WA_AUTH_NOT_CLEAN";
    error.authPath = authPath;
    error.remainingEntries = inspection.entries;
    throw error;
  }
  return inspection;
}

async function removeAuthPathCompletely(
  authPath,
  {
    attempts = 4,
    retryDelayMs = 100,
    onAttempt = null,
  } = {},
) {
  const maxAttempts = Math.max(1, Number(attempts) || 1);
  let lastInspection = null;
  let lastError = null;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      if (typeof onAttempt === "function") {
        await onAttempt({ attempt, maxAttempts, authPath });
      }
      await fsp.rm(authPath, {
        recursive: true,
        force: true,
        maxRetries: 3,
        retryDelay: 50,
      });
      lastInspection = await inspectAuthPath(authPath);
      if (!lastInspection.exists) {
        return {
          clean: true,
          attempts: attempt,
          removed: true,
          remainingEntries: [],
        };
      }

      if (lastInspection.clean) {
        await fsp.rm(authPath, { recursive: true, force: true });
        lastInspection = await inspectAuthPath(authPath);
        if (!lastInspection.exists) {
          return {
            clean: true,
            attempts: attempt,
            removed: true,
            remainingEntries: [],
          };
        }
      }
    } catch (error) {
      lastError = error;
    }

    if (attempt < maxAttempts) {
      await sleep(retryDelayMs * attempt);
    }
  }

  const remainingEntries = lastInspection?.entries || [];
  const error = new Error(
    remainingEntries.length
      ? `Gagal membersihkan auth WA; masih tersisa: ${remainingEntries
          .slice(0, 10)
          .join(", ")}`
      : `Gagal membersihkan auth WA: ${lastError?.message || "alasan tidak diketahui"}`,
  );
  error.code = "WA_AUTH_CLEANUP_FAILED";
  error.authPath = authPath;
  error.remainingEntries = remainingEntries;
  error.cause = lastError || undefined;
  throw error;
}

module.exports = {
  inspectAuthPath,
  verifyAuthPathClean,
  removeAuthPathCompletely,
};
