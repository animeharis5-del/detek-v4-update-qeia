const makeWASocket = require("@whiskeysockets/baileys").default;
const {
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  Browsers,
} = require("@whiskeysockets/baileys");
const P = require("pino");
const fs = require("fs");
const fsp = require("node:fs/promises");
const path = require("path");
const config = require("../../../config");
const { ensurePrivateDirectory } = require("../../repositories/json.repository");
const { chmodBestEffort } = require("../../services/file-permissions.service");
const {
  WaCheckError,
  isRetryableWaCheckError,
  queryOnWhatsAppCombo,
} = require("../../services/wa-query.service");
const {
  createRegisteredProfileResult,
  fetchPublicWaProfile,
} = require("../../services/wa-profile.service");
const {
  isTerminalSessionDisconnect,
} = require("../../services/wa-disconnect-policy");
const {
  verifyAuthPathClean,
  removeAuthPathCompletely,
} = require("./auth-store-cleaner");
const {
  AUTH_ROOT,
  DEFAULT_SENDER_ID,
  getSenderAuthPath,
  getSenderCredsPath,
  migrateLegacyAuthIfNeeded,
  listSenderIds,
  createSenderSlot,
  pruneEmptySenderContainers,
  normalizeSenderId,
} = require("./sender-auth-store");
const VERSION_CACHE_MS = 5 * 60 * 1000;
const CUSTOM_PAIRING_CODE = String(config.PAIRING_CODE || "")
  .trim()
  .toUpperCase();

const sessions = new Map();
// Runtime sender tambahan (selain compatibility sender `default`).
// Tahap 2 sengaja dipisahkan dari map `sessions` lama supaya /cekbio tetap
// memakai sender default sampai scheduler multi-sender diaktifkan pada tahap berikutnya.
const additionalSenderSessions = new Map();
const additionalSenderConnectedAt = new Map();
const additionalSenderLifecycleOperations = new Map();
// Menyimpan preferensi mode QR per user agar bertahan lintas reconnect (515).
const qrModeUsers = new Set();
const sessionConnectedAt = new Map();
const authLifecycleOperations = new Map();
const AUTO_DISCONNECT_AFTER_MS = 24 * 60 * 60 * 1000;
const AUTO_DISCONNECT_CHECK_INTERVAL_MS = 60 * 60 * 1000;
const MAX_REGISTERED_RECONNECT_ATTEMPTS = 5;
const MAX_AUTH_FLOW_RECONNECT_ATTEMPTS = 3;
let autoDisconnectNotifier = null;
let terminalDisconnectNotifier = null;
const sessionConnectivitySubscribers = new Map();
const sessionReadySubscribers = new Map();
// Subscriber generik per Telegram user untuk lifecycle semua Sender.
// API lama sessionConnectivitySubscribers tetap khusus sender `default`.
const senderConnectivitySubscribers = new Map();

async function hardenAuthTree(rootPath) {
  await ensurePrivateDirectory(rootPath);
  const entries = await fsp.readdir(rootPath, { withFileTypes: true }).catch((error) => {
    if (error.code === "ENOENT") return [];
    throw error;
  });
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = path.join(rootPath, entry.name);
      if (entry.isDirectory()) return hardenAuthTree(entryPath);
      if (entry.isFile()) await chmodBestEffort(entryPath, 0o600);
    }),
  );
}

const autoDisconnectTimer = setInterval(async () => {
  const now = Date.now();
  for (const userId of listAuthUserIds()) {
    const connectedAt = sessionConnectedAt.get(userId);
    const session = sessions.get(userId);
    if (!connectedAt || !session?.connected) {
      sessionConnectedAt.delete(userId);
      continue;
    }
    if (now - connectedAt >= AUTO_DISCONNECT_AFTER_MS) {
      sessionConnectedAt.delete(userId);
      logWa(
        "INFO",
        userId,
        "SESSION",
        "AUTO_DISCONNECT",
        "membersihkan auth WA otomatis setelah 24 jam",
      );
      try {
        const result = await reloadWA(userId, {
          skipIfNotConnected: true,
          source: "scheduled_24h",
        });
        if (!result?.skipped && typeof autoDisconnectNotifier === "function") {
          await Promise.resolve(
            autoDisconnectNotifier(userId, {
              reason: "scheduled_24h",
              result,
            }),
          );
        }
      } catch (err) {
        logWa("ERROR", userId, "SESSION", "AUTO_DISCONNECT_FAIL", err.message);
      }
    }
  }
}, AUTO_DISCONNECT_CHECK_INTERVAL_MS);
autoDisconnectTimer.unref?.();

let cachedVersion = null;
let versionFetchedAt = 0;
let versionFetchPromise = null;

// Fungsi sleep: menjalankan bagian sleep pada bot.
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
// Fungsi formatLogExtra: merapikan data tambahan untuk log sistem.
function formatLogExtra(extra) {
  return Object.entries(extra)
    .filter(([, v]) => v !== undefined && v !== null && v !== "")
    .map(([k, v]) => `${k}=${String(v)}`)
    .join(" | ");
}
// Fungsi logWa: menjalankan bagian log wa pada bot.
function logWa(level, userId, scope, stage, message, extra = {}) {
  const prefix = `[${level}][TG ${userId ?? "-"}][${scope}][${stage}]`;
  const details = formatLogExtra(extra);
  const line = details
    ? `${prefix} ${message} | ${details}`
    : `${prefix} ${message}`;
  if (level === "ERROR") console.error(line);
  else if (level === "WARN") console.warn(line);
  else console.log(line);
}
// Fungsi normalizeUserId: menjalankan bagian normalize user id pada bot.
function normalizeUserId(userId) {
  const id = String(userId ?? "").trim();
  if (!/^\d+$/.test(id)) throw new Error("Telegram user id tidak valid.");
  return id;
}

function runAuthLifecycleExclusive(userId, task) {
  const safeId = normalizeUserId(userId);
  const previous = authLifecycleOperations.get(safeId) || Promise.resolve();
  const run = previous.then(task, task);
  const settledGate = run.then(
    () => undefined,
    () => undefined,
  );
  let tracked = null;
  tracked = settledGate.finally(() => {
    if (authLifecycleOperations.get(safeId) === tracked) {
      authLifecycleOperations.delete(safeId);
    }
  });
  authLifecycleOperations.set(safeId, tracked);
  return run;
}

function trackAuthWrite(session, promise) {
  if (!session?.pendingAuthWrites) session.pendingAuthWrites = new Set();
  const tracked = Promise.resolve(promise);
  session.pendingAuthWrites.add(tracked);
  tracked.finally(() => session.pendingAuthWrites.delete(tracked)).catch(() => {});
  return tracked;
}

async function waitForPendingAuthWrites(session) {
  if (!session?.pendingAuthWrites?.size) return;
  await Promise.allSettled([...session.pendingAuthWrites]);
}

function getRegisteredPhoneNumber(userId) {
  const creds = readCredsFile(userId);
  const rawId = String(creds?.me?.id || "").trim();
  if (!rawId) return "";
  return rawId.split("@")[0].split(":")[0].replace(/\D/g, "");
}

// Fungsi setAutoDisconnectNotifier: menjalankan bagian set auto disconnect notifier pada bot.
function setAutoDisconnectNotifier(fn) {
  autoDisconnectNotifier = typeof fn === "function" ? fn : null;
}

let qrNotifier = null;
// Fungsi setQrNotifier: mendaftarkan callback saat QR code baru tersedia.
function setQrNotifier(fn) {
  qrNotifier = typeof fn === "function" ? fn : null;
}
// Fungsi emitQr: mengirim QR string ke layer atas (app) bila ada notifier.
function emitQr(userId, qr) {
  if (qrNotifier) {
    try {
      qrNotifier(userId, qr);
    } catch (error) {
      logWa("WARN", userId, "PAIR", "QR_NOTIFY_FAIL", "gagal mengirim QR ke handler", {
        error: error?.message || String(error),
      });
    }
  }
}
// Fungsi setTerminalDisconnectNotifier: mendaftarkan callback disconnect terminal.
function setTerminalDisconnectNotifier(fn) {
  terminalDisconnectNotifier = typeof fn === "function" ? fn : null;
}

function subscribeSessionConnectivity(userId, listener) {
  if (typeof listener !== "function") {
    throw new TypeError("listener status konektivitas WA wajib berupa fungsi.");
  }
  const key = normalizeUserId(userId);
  let listeners = sessionConnectivitySubscribers.get(key);
  if (!listeners) {
    listeners = new Set();
    sessionConnectivitySubscribers.set(key, listeners);
  }
  listeners.add(listener);
  let active = true;
  return () => {
    if (!active) return false;
    active = false;
    const current = sessionConnectivitySubscribers.get(key);
    if (!current) return false;
    current.delete(listener);
    if (current.size === 0) sessionConnectivitySubscribers.delete(key);
    return true;
  };
}

function notifySessionConnectivity(userId, state, event = {}) {
  const key = String(userId ?? "").trim();
  const listeners = sessionConnectivitySubscribers.get(key);
  if (!listeners?.size) return;
  for (const listener of [...listeners]) {
    Promise.resolve(
      listener({
        userId: key,
        state,
        status: state,
        ...event,
      }),
    ).catch((error) => {
      logWa(
        "WARN",
        key,
        "SOCKET",
        "CONNECTIVITY_LISTENER_FAIL",
        "listener status konektivitas WA gagal",
        { error: error?.message || String(error) },
      );
    });
  }
}

function subscribeSenderConnectivity(userId, listener) {
  if (typeof listener !== "function") {
    throw new TypeError("listener status konektivitas Sender wajib berupa fungsi.");
  }
  const key = normalizeUserId(userId);
  let listeners = senderConnectivitySubscribers.get(key);
  if (!listeners) {
    listeners = new Set();
    senderConnectivitySubscribers.set(key, listeners);
  }
  listeners.add(listener);
  let active = true;
  return () => {
    if (!active) return false;
    active = false;
    const current = senderConnectivitySubscribers.get(key);
    if (!current) return false;
    current.delete(listener);
    if (current.size === 0) senderConnectivitySubscribers.delete(key);
    return true;
  };
}

function notifySenderConnectivity(userId, senderId, state, event = {}) {
  const key = String(userId ?? "").trim();
  const listeners = senderConnectivitySubscribers.get(key);
  if (!listeners?.size) return;
  for (const listener of [...listeners]) {
    Promise.resolve(
      listener({
        userId: key,
        senderId: normalizeSenderId(senderId || DEFAULT_SENDER_ID),
        state,
        status: state,
        ...event,
      }),
    ).catch((error) => {
      logWa(
        "WARN",
        key,
        "SENDER",
        "CONNECTIVITY_LISTENER_FAIL",
        "listener status konektivitas Sender gagal",
        { senderId, error: error?.message || String(error) },
      );
    });
  }
}

function setSessionConnectivityState(session, state, event = {}) {
  if (!session) return false;
  if (!["ready", "reconnecting", "dead"].includes(state)) {
    throw new Error(`Status konektivitas WA tidak valid: ${state}`);
  }
  const previousState = session.connectivityState || "dead";
  session.connectivityState = state;
  if (previousState === state && event.force !== true) return false;
  const payload = {
    previousState,
    ...event,
  };
  notifySessionConnectivity(session.userId, state, payload);
  notifySenderConnectivity(
    session.userId,
    DEFAULT_SENDER_ID,
    state,
    payload,
  );
  return true;
}

function getSessionConnectivityState(userId) {
  const key = normalizeUserId(userId);
  const session = sessions.get(key);
  if (!session) return "dead";
  if (session.connected === true && session.ready === true) return "ready";
  if (["ready", "reconnecting", "dead"].includes(session.connectivityState)) {
    return session.connectivityState;
  }
  if (
    session.startingPromise ||
    session.reconnectTimer ||
    session.sock ||
    session.connected
  ) {
    return "reconnecting";
  }
  return "dead";
}

function getSenderConnectivityState(userId, senderId = DEFAULT_SENDER_ID) {
  const safeUserId = normalizeUserId(userId);
  const safeSenderId = normalizeSenderId(senderId || DEFAULT_SENDER_ID);
  if (safeSenderId === DEFAULT_SENDER_ID) {
    return getSessionConnectivityState(safeUserId);
  }
  const key = getAdditionalSenderKey(safeUserId, safeSenderId);
  const session = additionalSenderSessions.get(key);
  if (!session) return "dead";
  if (session.connected === true && session.ready === true) return "ready";
  if (["ready", "reconnecting", "dead"].includes(session.connectivityState)) {
    return session.connectivityState;
  }
  if (
    session.startingPromise ||
    session.reconnectTimer ||
    session.sock ||
    session.connected
  ) {
    return "reconnecting";
  }
  return "dead";
}

function subscribeSessionReady(userId, listener) {
  if (typeof listener !== "function") {
    throw new TypeError("listener ready WA wajib berupa fungsi.");
  }
  const key = normalizeUserId(userId);
  let listeners = sessionReadySubscribers.get(key);
  if (!listeners) {
    listeners = new Set();
    sessionReadySubscribers.set(key, listeners);
  }
  listeners.add(listener);
  let active = true;
  return () => {
    if (!active) return false;
    active = false;
    const current = sessionReadySubscribers.get(key);
    if (!current) return false;
    current.delete(listener);
    if (current.size === 0) sessionReadySubscribers.delete(key);
    return true;
  };
}

function notifySessionReady(userId, event = {}) {
  const key = String(userId ?? "").trim();
  const listeners = sessionReadySubscribers.get(key);
  if (!listeners?.size) return;
  for (const listener of [...listeners]) {
    Promise.resolve(
      listener({
        userId: key,
        status: "ready",
        ready: true,
        connected: true,
        ...event,
      }),
    ).catch((error) => {
      logWa(
        "WARN",
        key,
        "SOCKET",
        "READY_LISTENER_FAIL",
        "listener status ready WA gagal",
        { error: error?.message || String(error) },
      );
    });
  }
}

function markSessionReady(userId, event = {}) {
  const key = normalizeUserId(userId);
  const session = sessions.get(key);
  if (!session?.connected) return false;
  session.ready = true;
  setSessionConnectivityState(session, "ready", event);
  notifySessionReady(key, event);
  return true;
}

function isSessionReady(userId) {
  const key = normalizeUserId(userId);
  const session = sessions.get(key);
  return session?.connected === true && session?.ready === true;
}

function notifyTerminalDisconnect(userId, meta = {}) {
  if (typeof terminalDisconnectNotifier !== "function") return;
  const payload = {
    ...meta,
    senderId: normalizeSenderId(meta.senderId || DEFAULT_SENDER_ID),
  };
  Promise.resolve(terminalDisconnectNotifier(userId, payload)).catch((error) => {
    logWa(
      "WARN",
      userId,
      "SOCKET",
      "TERMINAL_NOTIFY_FAIL",
      "gagal meneruskan status disconnect terminal",
      { error: error?.message || String(error) },
    );
  });
}
// Fungsi getAuthPath: menjalankan bagian get auth path pada bot.
function getAuthPath(userId) {
  const safeId = normalizeUserId(userId);
  migrateLegacyAuthIfNeeded(safeId);
  return getSenderAuthPath(safeId, DEFAULT_SENDER_ID);
}
// Fungsi getCredsPath: menjalankan bagian get creds path pada bot.
function getCredsPath(userId) {
  const safeId = normalizeUserId(userId);
  migrateLegacyAuthIfNeeded(safeId);
  return getSenderCredsPath(safeId, DEFAULT_SENDER_ID);
}
// Fungsi listCorruptAuthJsonFiles: menjalankan bagian list corrupt auth json files pada bot.
function listCorruptAuthJsonFiles(targetPath, basePath = targetPath) {
  const corrupt = [];
  if (!fs.existsSync(targetPath)) return corrupt;
  for (const entry of fs.readdirSync(targetPath, { withFileTypes: true })) {
    const fullPath = path.join(targetPath, entry.name);
    if (entry.isDirectory()) {
      corrupt.push(...listCorruptAuthJsonFiles(fullPath, basePath));
      continue;
    }
    if (!entry.isFile() || !entry.name.endsWith(".json")) continue;
    try {
      JSON.parse(fs.readFileSync(fullPath, "utf-8"));
    } catch {
      corrupt.push(path.relative(basePath, fullPath));
    }
  }
  return corrupt;
}
// Fungsi assertAuthDirectoryReadable: menjalankan bagian assert auth directory readable pada bot.
function assertAuthDirectoryReadable(userId) {
  const safeId = normalizeUserId(userId);
  const authPath = getAuthPath(safeId);
  const corruptFiles = listCorruptAuthJsonFiles(authPath);
  if (!corruptFiles.length) return;
  logWa(
    "ERROR",
    safeId,
    "AUTH",
    "CORRUPT_FILES",
    "file auth WA corrupt terdeteksi sebelum start",
    { files: corruptFiles.join(",") },
  );
  throw new Error(`Auth WA corrupt: ${corruptFiles.join(", ")}`);
}
// Fungsi listAuthUserIds: menjalankan bagian list auth user ids pada bot.
function listAuthUserIds() {
  try {
    if (!fs.existsSync(AUTH_ROOT)) return [];
    return fs
      .readdirSync(AUTH_ROOT, { withFileTypes: true })
      .filter((entry) => entry.isDirectory() && /^\d+$/.test(entry.name))
      .map((entry) => entry.name);
  } catch (error) {
    logWa("WARN", "SYSTEM", "AUTH", "LIST_FAIL", "gagal membaca folder wa_auth", {
      error: error?.message || String(error),
    });
    return [];
  }
}
// Fungsi hasAnyAuthData: menjalankan bagian has any auth data pada bot.
function hasAnyAuthData(userId) {
  const safeId = normalizeUserId(userId);
  const authPath = getAuthPath(safeId);
  try {
    if (!fs.existsSync(authPath)) return false;
    return fs.readdirSync(authPath).length > 0;
  } catch (error) {
    logWa("WARN", safeId, "AUTH", "READ_DIR_FAIL", "gagal membaca isi folder auth", {
      error: error?.message || String(error),
    });
    return false;
  }
}
// Fungsi readCredsFile: menjalankan bagian read creds file pada bot.
function readCredsFile(userId) {
  const safeId = normalizeUserId(userId);
  const credsPath = getCredsPath(safeId);
  try {
    if (!fs.existsSync(credsPath)) return null;
    return JSON.parse(fs.readFileSync(credsPath, "utf-8"));
  } catch (error) {
    logWa("WARN", safeId, "AUTH", "CREDS_READ_FAIL", "gagal membaca creds.json", {
      error: error?.message || String(error),
    });
    return null;
  }
}
// Fungsi getAuthStateLabel: menjalankan bagian get auth state label pada bot.
function getAuthStateLabel(userId) {
  const creds = readCredsFile(userId);
  if (!creds) return "no-auth";
  if (creds?.registered && creds?.me?.id) return "registered-auth";
  return "partial-auth";
}
// Fungsi isAccessDeniedClose: menjalankan bagian is access denied close pada bot.
function isAccessDeniedClose(code, reason = "") {
  return (
    code === DisconnectReason.forbidden ||
    /forbidden|access denied|not authorized/i.test(String(reason || ""))
  );
}

// Fungsi shouldReconnectSession: menjalankan bagian should reconnect session pada bot.
function shouldReconnectSession(session, code, reason = "") {
  const authState = getAuthStateLabel(session.userId);
  const attempts = Number(session.reconnectAttempts || 0);
  if (session.stopRequested) return false;
  if (code === DisconnectReason.loggedOut) return false;
  if (isExpectedAuthTimeout(code, authState, reason)) return false;
  if (isAccessDeniedClose(code, reason)) return false;
  if (hasAuthSession(session.userId)) {
    return attempts < MAX_REGISTERED_RECONNECT_ATTEMPTS;
  }
  if (authState !== "registered-auth") {
    const authFlowClose =
      code === DisconnectReason.connectionClosed ||
      code === DisconnectReason.timedOut ||
      code === DisconnectReason.restartRequired ||
      /Connection Terminated|Connection Closed|Connection Failure|WebSocket Error/i.test(
        String(reason || ""),
      );
    if (authFlowClose && attempts < MAX_AUTH_FLOW_RECONNECT_ATTEMPTS) return true;
  }
  return (
    code === DisconnectReason.restartRequired &&
    authState === "partial-auth" &&
    attempts < MAX_AUTH_FLOW_RECONNECT_ATTEMPTS
  );
}
// Fungsi isExpectedAuthTimeout: menjalankan bagian is expected auth timeout pada bot.
function isExpectedAuthTimeout(code, authState, reason) {
  return (
    code === DisconnectReason.timedOut &&
    authState !== "registered-auth" &&
    /(?:Q)R refs attempts ended/i.test(String(reason || ""))
  );
}
// Fungsi shouldClearAuthOnClose: menjalankan bagian should clear auth on close pada bot.
function shouldClearAuthOnClose(code, authState, reason) {
  if (code === DisconnectReason.loggedOut) return true;
  if (isAccessDeniedClose(code, reason) && authState === "registered-auth") return true;
  return isExpectedAuthTimeout(code, authState, reason);
}
// Fungsi clearAuthAfterClose: membersihkan auth terminal dengan reset total terverifikasi.
async function clearAuthAfterClose(userId, reasonLabel) {
  try {
    // Sudah tidak ada auth juga berarti target terminal sudah bersih; caller
    // tetap harus membuang runtime map agar Sender tidak muncul/terpakai lagi.
    if (!hasAnyAuthData(userId)) return true;
    const result = await forceResetWA(userId, {
      source: `terminal_${reasonLabel}`,
    });
    logWa(
      "INFO",
      userId,
      "AUTH",
      "CLEANED",
      "folder auth WA dibersihkan otomatis",
      { reason: reasonLabel },
    );
    return result?.authDeleted === true;
  } catch (err) {
    logWa(
      "WARN",
      userId,
      "AUTH",
      "CLEAN_FAIL",
      "gagal membersihkan folder auth WA otomatis",
      { reason: reasonLabel, error: err.message },
    );
    return false;
  }
}
// Fungsi isLikelyNetworkFailure: menjalankan bagian is likely network failure pada bot.
function isLikelyNetworkFailure(code, reason) {
  const text = String(reason || "");
  return (
    code === DisconnectReason.timedOut ||
    code === DisconnectReason.connectionClosed ||
    /ENOTFOUND|EAI_AGAIN|ETIMEDOUT|ECONNRESET|Connection Terminated|Connection Failure|WebSocket Error/i.test(
      text,
    )
  );
}
// Fungsi getReconnectDelayMs: menjalankan bagian get reconnect delay ms pada bot.
function getReconnectDelayMs(session, code, reason) {
  if (isLikelyNetworkFailure(code, reason)) {
    const attempt = Math.max(1, Number(session.reconnectAttempts) || 1);
    return Math.min(60000, 1500 * Math.pow(2, Math.min(attempt - 1, 5)));
  }
  return 1500;
}
// Fungsi hasAuthSession: menjalankan bagian has auth session pada bot.
function hasAuthSession(userId) {
  const creds = readCredsFile(normalizeUserId(userId));
  return Boolean(creds?.registered && creds?.me?.id);
}
// Fungsi getOrCreateSession: menjalankan bagian get or create session pada bot.
function getOrCreateSession(userId) {
  const safeId = normalizeUserId(userId);
  let session = sessions.get(safeId);
  if (!session) {
    session = {
      userId: safeId,
      authPath: getAuthPath(safeId),
      sock: null,
      connected: false,
      ready: false,
      startingPromise: null,
      reconnectTimer: null,
      reconnectAttempts: 0,
      terminalCleanupStarted: false,
      stopRequested: false,
      connectivityState: "dead",
      pendingAuthWrites: new Set(),
    };
    sessions.set(safeId, session);
  }
  return session;
}
// Fungsi getPairingBrowser: konfigurasi browser untuk pairing code.
// Aman terhadap lingkungan/mock di mana Browsers tidak tersedia.
function getPairingBrowser() {
  if (Browsers && typeof Browsers.ubuntu === "function") {
    return Browsers.ubuntu("Chrome");
  }
  // Fallback manual berformat sama seperti Browsers.ubuntu("Chrome").
  return ["Ubuntu", "Chrome", "22.04.4"];
}
// Fungsi getBaileysVersion: menjalankan bagian get baileys version pada bot.
async function getBaileysVersion() {
  const now = Date.now();
  if (cachedVersion && now - versionFetchedAt < VERSION_CACHE_MS)
    return cachedVersion;
  if (versionFetchPromise) return versionFetchPromise;
  versionFetchPromise = (async () => {
    // Versi protokol WA cadangan bila fetch gagal/timeout,
    // supaya pairing tidak gagal hanya karena versi tak terambil.
    const FALLBACK_VERSION = [2, 3000, 1023223821];
    try {
      const result = await Promise.race([
        fetchLatestBaileysVersion(),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error("version fetch timeout")), 8000),
        ),
      ]);
      if (!result || !Array.isArray(result.version)) {
        throw new Error("versi tidak valid");
      }
      if (!result.isLatest)
        logWa(
          "WARN",
          "SYSTEM",
          "AUTH",
          "VERSION_FALLBACK",
          "gagal mengambil versi terbaru",
          { error: result.error?.message || "-" },
        );
      cachedVersion = result.version;
      versionFetchedAt = Date.now();
      return cachedVersion;
    } catch (error) {
      logWa(
        "WARN",
        "SYSTEM",
        "AUTH",
        "VERSION_HARDCODED_FALLBACK",
        "pakai versi WA cadangan karena fetch gagal",
        { error: error?.message || String(error), version: FALLBACK_VERSION.join(".") },
      );
      cachedVersion = FALLBACK_VERSION;
      versionFetchedAt = Date.now();
      return cachedVersion;
    } finally {
      versionFetchPromise = null;
    }
  })();
  return versionFetchPromise;
}
// Fungsi clearReconnectTimer: menjalankan bagian clear reconnect timer pada bot.
function clearReconnectTimer(session) {
  if (session?.reconnectTimer) {
    clearTimeout(session.reconnectTimer);
    session.reconnectTimer = null;
  }
}
// Fungsi closeSocket: menjalankan bagian close socket pada bot.
function closeSocket(sock) {
  try {
    if (!sock) return;
    if (typeof sock.end === "function") sock.end();
    else if (sock.ws && typeof sock.ws.close === "function") sock.ws.close();
  } catch (error) {
    logWa("WARN", "SYSTEM", "SOCKET", "CLOSE_FAIL", "gagal menutup socket WA", {
      error: error?.message || String(error),
    });
  }
}
// Fungsi getCustomPairingCode: menjalankan bagian get custom pairing code pada bot.
function getCustomPairingCode() {
  if (!CUSTOM_PAIRING_CODE) return undefined;
  if (CUSTOM_PAIRING_CODE.length !== 8)
    throw new Error("PAIRING_CODE harus tepat 8 karakter.");
  return CUSTOM_PAIRING_CODE;
}
// Fungsi startWAUnlocked: menginisialisasi socket di dalam lifecycle lock.
async function startWAUnlocked(userId, options = {}) {
  const session = getOrCreateSession(userId);
  // qrMode aktif bila diminta eksplisit ATAU user memang sedang memilih mode QR.
  session.qrMode =
    options.qrMode === true || qrModeUsers.has(normalizeUserId(userId));
  const requireCleanAuth = options.requireCleanAuth === true;
  const qrMode = options.qrMode === true;
  const pairingPhone = String(options.pairingPhone || "").replace(/\D/g, "");
  if (session.connected && session.sock) return session;
  if (session.startingPromise) {
    logWa(
      "INFO",
      session.userId,
      "AUTH",
      "START_WAIT",
      "inisialisasi sesi WA sedang berjalan, menunggu proses yang sama",
      { authState: getAuthStateLabel(session.userId) },
    );
    await session.startingPromise;
    return session;
  }
  if (session.sock) return session;
  logWa(
    "INFO",
    session.userId,
    "AUTH",
    "START",
    "memulai inisialisasi sesi WA",
    { authState: getAuthStateLabel(session.userId) },
  );
  session.stopRequested = false;
  clearReconnectTimer(session);
  setSessionConnectivityState(session, "reconnecting", { source: "start" });
  session.startingPromise = (async () => {
    await ensurePrivateDirectory(AUTH_ROOT);
    if (requireCleanAuth) {
      await verifyAuthPathClean(session.authPath);
    }
    await ensurePrivateDirectory(session.authPath);
    if (requireCleanAuth) {
      await verifyAuthPathClean(session.authPath);
      logWa(
        "INFO",
        session.userId,
        "PAIR",
        "AUTH_CLEAN_VERIFIED",
        "auth bersih terverifikasi",
        { phone: pairingPhone || "-" },
      );
    }
    assertAuthDirectoryReadable(session.userId);
    const { state, saveCreds } = await useMultiFileAuthState(session.authPath);
    await hardenAuthTree(session.authPath);
    const version = await getBaileysVersion();
    logWa(
      "INFO",
      session.userId,
      "AUTH",
      "STATE_READY",
      "auth state berhasil dimuat",
      {
        authState: getAuthStateLabel(session.userId),
        version: Array.isArray(version) ? version.join(".") : version,
      },
    );
    const sock = makeWASocket({
      version,
      auth: state,
      logger: P({ level: "silent" }),
      markOnlineOnConnect: false,
      defaultQueryTimeoutMs: config.WA_QUERY_TIMEOUT_MS,
      // Browser wajib diset untuk metode PAIRING CODE agar diterima WhatsApp.
      browser: getPairingBrowser(),
      // Tidak sinkronkan riwayat penuh: lebih ringan & lebih stabil untuk bot.
      syncFullHistory: false,
      qrTimeout: 60000,
    });
    session.sock = sock;
    session.connected = false;
    session.ready = false;
    sock.ev.on("creds.update", (creds) => {
      if (
        session.stopRequested ||
        sessions.get(session.userId) !== session ||
        session.sock !== sock
      ) {
        logWa(
          "INFO",
          session.userId,
          "AUTH",
          "CREDS_SAVE_SKIPPED",
          "update credentials lama diabaikan setelah sesi dihentikan",
        );
        return;
      }
      const writePromise = Promise.resolve()
        .then(async () => {
          if (
            session.stopRequested ||
            sessions.get(session.userId) !== session ||
            session.sock !== sock
          )
            return;
          await saveCreds(creds);
          if (
            session.stopRequested ||
            sessions.get(session.userId) !== session ||
            session.sock !== sock
          )
            return;
          await hardenAuthTree(session.authPath);
        })
        .catch((error) => {
          logWa(
            "ERROR",
            session.userId,
            "AUTH",
            "CREDS_SAVE_FAIL",
            "gagal menyimpan update credentials WA",
            { error: error?.message || String(error) },
          );
        });
      trackAuthWrite(session, writePromise);
    });
    sock.ev.on("connection.update", (update) => {
      const { connection, lastDisconnect, qr } = update;
      logWa("INFO", session.userId, "SOCKET", "UPDATE", "connection.update diterima", {
        connection: connection || "-",
        hasQr: qr ? "yes" : "no",
        qrMode: session.qrMode ? "yes" : "no",
      });
      if (qr) {
        if (session.qrMode) {
          logWa("INFO", session.userId, "PAIR", "QR_RECEIVED", "QR code baru diterima", {});
          emitQr(session.userId, qr);
        } else {
          logWa("INFO", session.userId, "PAIR", "QR_IGNORED", "QR datang tapi bukan mode QR", {});
        }
      }
      if (connection === "open") {
        session.connected = true;
        qrModeUsers.delete(session.userId);
        // A raw Baileys open is not yet the application-level ready signal.
        // Ready is marked only after the bot successfully shows WA TERSAMBUNG.
        session.ready = false;
        setSessionConnectivityState(session, "reconnecting", {
          source: "socket_open",
          connection: "open",
        });
        sessionConnectedAt.set(session.userId, Date.now());
        session.reconnectAttempts = 0;
        session.terminalCleanupStarted = false;
        clearReconnectTimer(session);
        logWa(
          "INFO",
          session.userId,
          "SOCKET",
          "OPEN",
          "sesi WA berhasil connected",
          { authState: getAuthStateLabel(session.userId) },
        );
        console.log(`✅ WA CONNECTED [TG ${session.userId}]`);
        return;
      }
      if (connection === "close") {
        const code = lastDisconnect?.error?.output?.statusCode;
        const authState = getAuthStateLabel(session.userId);
        const reason =
          lastDisconnect?.error?.message ||
          lastDisconnect?.error?.data ||
          lastDisconnect?.error?.output?.payload?.message ||
          "-";
        const shouldReconnect = shouldReconnectSession(session, code, reason);
        const networkFailure = isLikelyNetworkFailure(code, reason);
        session.connected = false;
        session.ready = false;
        if (session.sock === sock) session.sock = null;
        const expectedAuthTimeout = isExpectedAuthTimeout(code, authState, reason);
        const codeLabel = code ?? "-";
        const codeName =
          typeof code === "number" ? DisconnectReason[code] || "-" : "-";
        const routineRestart =
          code === DisconnectReason.restartRequired && shouldReconnect;
        const closeLogLevel = routineRestart
          ? "INFO"
          : shouldReconnect || expectedAuthTimeout
            ? "WARN"
            : "ERROR";
        logWa(
          closeLogLevel,
          session.userId,
          "SOCKET",
          "CLOSE",
          routineRestart
            ? "sesi WA meminta restart normal dan akan reconnect"
            : "sesi WA terputus",
          {
            code: codeLabel,
            codeName,
            reconnect: shouldReconnect ? "yes" : "no",
            authState,
            reason,
          },
        );
        console.log(
          routineRestart
            ? `🔄 WA RECONNECT [TG ${session.userId}] code=${codeLabel} (${codeName})`
            : `❌ WA DISCONNECTED [TG ${session.userId}] code=${codeLabel} (${codeName})`,
        );
        setSessionConnectivityState(
          session,
          shouldReconnect ? "reconnecting" : "dead",
          {
            source: "socket_close",
            connection: "close",
            connected: false,
            code: code ?? null,
            codeName,
            reason: String(reason || "-"),
            authState,
            shouldReconnect,
          },
        );
        if (!shouldReconnect) {
          const terminalDisconnect = isTerminalSessionDisconnect({
            stopRequested: session.stopRequested,
            authState,
            shouldReconnect,
          });
          clearReconnectTimer(session);
          session.reconnectAttempts = 0;
          const cleanupTerminalSender =
            terminalDisconnect && session.terminalCleanupStarted !== true;
          if (cleanupTerminalSender) {
            session.terminalCleanupStarted = true;
            notifyTerminalDisconnect(session.userId, {
              senderId: DEFAULT_SENDER_ID,
              number: getRegisteredPhoneNumber(session.userId),
              code: code ?? null,
              codeName,
              reason: String(reason || "-"),
              authState,
              loggedOut: code === DisconnectReason.loggedOut,
              accessDenied: isAccessDeniedClose(code, reason),
              reconnectExhausted:
                code !== DisconnectReason.loggedOut &&
                !isAccessDeniedClose(code, reason),
              autoRemoved: true,
            });
          }
          const shouldAutoRemove =
            cleanupTerminalSender || shouldClearAuthOnClose(code, authState, reason);
          if (shouldAutoRemove) {
            const cleanupReason = cleanupTerminalSender
              ? code === DisconnectReason.loggedOut
                ? "logged_out"
                : isAccessDeniedClose(code, reason)
                  ? "access_denied"
                  : "terminal_disconnect"
              : "auth_timeout";
            void clearAuthAfterClose(session.userId, cleanupReason).then((cleared) => {
              if (cleared) {
                sessions.delete(session.userId);
                sessionConnectedAt.delete(session.userId);
              }
            });
          }
          if (code === DisconnectReason.loggedOut)
            console.log(
              `⚠️ Session WA [TG ${session.userId}] logout. Auth lama sudah dibersihkan, login ulang lewat Pairing.`,
            );
          if (isAccessDeniedClose(code, reason))
            console.log(
              `⚠️ Session WA [TG ${session.userId}] ditolak WhatsApp. Auth lama sudah dibersihkan, login ulang lewat Pairing.`,
            );
          return;
        }
        clearReconnectTimer(session);
        session.reconnectAttempts = (session.reconnectAttempts || 0) + 1;
        const delayMs = getReconnectDelayMs(session, code, reason);
        if (
          code === DisconnectReason.restartRequired &&
          authState === "partial-auth"
        )
          logWa(
            "INFO",
            session.userId,
            "AUTH",
            "RESTART_REQUIRED",
            "stream meminta restart dan bot akan menyambung ulang",
          );
        if (networkFailure && /ENOTFOUND/i.test(String(reason || "")))
          logWa(
            "WARN",
            session.userId,
            "NETWORK",
            "DNS_FAIL",
            "DNS gagal resolve web.whatsapp.com",
            { attempt: session.reconnectAttempts },
          );
        logWa(
          "INFO",
          session.userId,
          "SOCKET",
          "RECONNECT_SCHEDULED",
          "menjadwalkan reconnect otomatis",
          {
            delayMs,
            attempt: session.reconnectAttempts,
            networkFailure: networkFailure ? "yes" : "no",
          },
        );
        session.reconnectTimer = setTimeout(() => {
          session.reconnectTimer = null;
          startWA(session.userId).catch((err) =>
            logWa(
              "ERROR",
              session.userId,
              "SOCKET",
              "RECONNECT_FAIL",
              "reconnect otomatis gagal",
              { error: err.message },
            ),
          );
        }, delayMs);
      }
    });
  })()
    .catch((error) => {
      if (!session.connected && !session.reconnectTimer && !session.stopRequested) {
        setSessionConnectivityState(session, "dead", {
          source: "start_failed",
          error: error?.message || String(error),
        });
      }
      throw error;
    })
    .finally(() => {
      session.startingPromise = null;
    });
  await session.startingPromise;
  return session;
}

// Fungsi startWA: menyerialkan start dengan reset/pairing agar auth tidak balapan.
async function startWA(userId) {
  return runAuthLifecycleExclusive(userId, () => startWAUnlocked(userId));
}
// Fungsi stopWA: menjalankan bagian stop wa pada bot.
async function stopWA(userId) {
  const safeId = normalizeUserId(userId);
  const session = sessions.get(safeId);
  if (!session) return;
  logWa("INFO", safeId, "AUTH", "STOP", "menghentikan sesi WA");
  session.stopRequested = true;
  session.connected = false;
  session.ready = false;
  session.reconnectAttempts = 0;
  clearReconnectTimer(session);
  setSessionConnectivityState(session, "dead", { source: "stop" });
  const sock = session.sock;
  session.sock = null;
  closeSocket(sock);
  await waitForPendingAuthWrites(session);
  await sleep(300);
  await waitForPendingAuthWrites(session);
  sessions.delete(safeId);
  sessionConnectedAt.delete(safeId);
  logWa("INFO", safeId, "AUTH", "STOPPED", "sesi WA berhasil dihentikan");
}
// Fungsi stopAllWA: menjalankan bagian stop all wa pada bot.
async function stopAllWA() {
  const sessionIds = [...sessions.keys()];
  await Promise.allSettled(sessionIds.map(stopWA));
  await stopAllAdditionalSenders();
}
// Fungsi forceResetWA: menghapus total auth user dan memverifikasi tidak ada state lama.
async function forceResetWA(userId, options = {}) {
  qrModeUsers.delete(normalizeUserId(userId));
  const safeId = normalizeUserId(userId);
  const authPath = getAuthPath(safeId);
  const skipIfNotConnected = options.skipIfNotConnected === true;
  const source = String(options.source || "force_reset");

  return runAuthLifecycleExclusive(safeId, async () => {
    const hadAuthBefore = hasAnyAuthData(safeId);
    const hadRegisteredAuthBefore = hasAuthSession(safeId);
    const previousPhone = getRegisteredPhoneNumber(safeId);
    const wasConnectedBefore = isConnected(safeId);

    logWa("INFO", safeId, "RESET", "START", "memulai reset sesi WA", {
      authState: getAuthStateLabel(safeId),
      hadAuthBefore,
      hadRegisteredAuthBefore,
      wasConnectedBefore,
      previousPhone: previousPhone || "-",
      source,
    });

    if (skipIfNotConnected && !wasConnectedBefore) {
      logWa(
        "INFO",
        safeId,
        "RESET",
        "SKIPPED",
        "reset auth dilewati karena sesi WA tidak sedang connected",
        { source, hadAuthBefore },
      );
      return {
        skipped: true,
        skipReason: "not_connected",
        hadAuthBefore,
        hadRegisteredAuthBefore,
        wasConnectedBefore,
        authDeleted: false,
        hasAuthAfterReset: hadAuthBefore,
        autoRestarted: false,
        deleteError: null,
      };
    }

    logWa(
      "INFO",
      safeId,
      "RESET",
      "AUTH_DELETE_START",
      "menghapus auth lama",
      { authPath, source },
    );
    await stopWA(safeId);
    sessions.delete(safeId);
    sessionConnectedAt.delete(safeId);

    let cleanupMeta;
    try {
      cleanupMeta = await removeAuthPathCompletely(authPath, {
        attempts: 4,
        retryDelayMs: 100,
        onAttempt: ({ attempt, maxAttempts }) => {
          if (attempt > 1) {
            logWa(
              "WARN",
              safeId,
              "RESET",
              "AUTH_DELETE_RETRY",
              "mengulangi penghapusan auth lama",
              { attempt, maxAttempts },
            );
          }
        },
      });
      await verifyAuthPathClean(authPath);
      pruneEmptySenderContainers(safeId);
    } catch (error) {
      logWa(
        "ERROR",
        safeId,
        "RESET",
        "AUTH_DELETE_FAIL",
        "gagal menghapus total auth WA",
        {
          source,
          error: error?.message || String(error),
          remaining: Array.isArray(error?.remainingEntries)
            ? error.remainingEntries.join(",")
            : "-",
        },
      );
      throw error;
    }

    const hasAuthAfterReset = hasAnyAuthData(safeId);
    if (hasAuthAfterReset) {
      const error = new Error("Auth WA masih tersisa setelah reset paksa.");
      error.code = "WA_AUTH_STILL_PRESENT";
      logWa(
        "ERROR",
        safeId,
        "RESET",
        "AUTH_VERIFY_FAIL",
        "verifikasi auth bersih gagal",
        { source },
      );
      throw error;
    }

    logWa(
      "INFO",
      safeId,
      "RESET",
      "AUTH_CLEAN_VERIFIED",
      "auth bersih terverifikasi",
      { attempts: cleanupMeta?.attempts || 1, source },
    );
    logWa("INFO", safeId, "RESET", "DONE", "reset sesi WA selesai", {
      hadAuthBefore,
      hadRegisteredAuthBefore,
      wasConnectedBefore,
      authDeleted: true,
      hasAuthAfterReset: false,
      autoRestarted: false,
      skipped: "no",
      source,
    });

    return {
      skipped: false,
      hadAuthBefore,
      hadRegisteredAuthBefore,
      wasConnectedBefore,
      previousPhone,
      authDeleted: true,
      hasAuthAfterReset: false,
      autoRestarted: false,
      deleteError: null,
    };
  });
}

// Fungsi reloadWA: kompatibilitas tombol Putus; sekarang selalu memakai reset total.
async function reloadWA(userId, options = {}) {
  return forceResetWA(userId, {
    ...options,
    source: String(options.source || "manual_disconnect"),
  });
}
// Fungsi isConnected: menjalankan bagian is connected pada bot.
function isConnected(userId) {
  const safeId = normalizeUserId(userId);
  return sessions.get(safeId)?.connected === true;
}

// Snapshot read-only untuk layer UI. Ini sengaja tidak mengubah lifecycle
// sesi dan tetap merepresentasikan backend single-sender saat ini.
function getSenderSnapshot(userId) {
  const safeId = normalizeUserId(userId);
  const session = sessions.get(safeId);
  const connected = session?.connected === true;
  const socketPhone = String(session?.sock?.user?.id || "")
    .split("@")[0]
    .split(":")[0]
    .replace(/\D/g, "");
  const number = socketPhone || getRegisteredPhoneNumber(safeId) || "";
  const connectedAt = Number(sessionConnectedAt.get(safeId) || 0) || null;

  return {
    connected,
    ready: session?.ready === true,
    registered: hasAuthSession(safeId),
    connectivityState: getSessionConnectivityState(safeId),
    reconnectAttempts: Number(session?.reconnectAttempts || 0),
    number,
    connectedAt,
  };
}
// Fungsi ensureConnectedSession: menjalankan bagian ensure connected session pada bot.
async function ensureConnectedSession(userId, timeoutMs = 10000) {
  const session = await startWA(userId);
  if (session.connected) return true;
  const until = Date.now() + timeoutMs;
  while (Date.now() < until) {
    if (session.connected) return true;
    await sleep(400);
  }
  return session.connected;
}
// Fungsi waitForPairingSocketReady: menjalankan bagian wait for pairing socket ready pada bot.
async function waitForPairingSocketReady(session) {
  if (!session?.sock)
    throw new Error("WA socket belum siap. Coba ulang beberapa detik lagi.");
  if (typeof session.sock.waitForSocketOpen === "function") {
    try {
      await session.sock.waitForSocketOpen();
    } catch (error) {
      // Socket belum terbuka: beri kesempatan sebentar, pemanggil akan retry.
      logWa(
        "WARN",
        session.userId,
        "PAIR",
        "SOCKET_OPEN_WAIT",
        "menunggu socket terbuka sebelum minta kode pairing",
        { error: error?.message || String(error) },
      );
    }
  }
  // Jeda singkat agar handshake awal siap sebelum requestPairingCode.
  await sleep(800);
}
// Fungsi prepareFreshPairingSession: memastikan pairing selalu dimulai dari auth kosong.
async function prepareFreshPairingSession(userId, phoneNumberDigits, source) {
  const safeId = normalizeUserId(userId);
  const requestedPhone = String(phoneNumberDigits || "").replace(/\D/g, "");
  const authPath = getAuthPath(safeId);

  return runAuthLifecycleExclusive(safeId, async () => {
    const currentSession = sessions.get(safeId);
    if (currentSession?.connected && currentSession.sock) return currentSession;

    const previousPhone = getRegisteredPhoneNumber(safeId);
    logWa(
      "INFO",
      safeId,
      "PAIR",
      "AUTH_DELETE_START",
      "menghapus auth lama",
      {
        previousPhone: previousPhone || "-",
        requestedPhone: requestedPhone || "-",
        differentNumber:
          previousPhone && requestedPhone && previousPhone !== requestedPhone
            ? "yes"
            : "no",
        source,
      },
    );

    await stopWA(safeId);
    sessions.delete(safeId);
    sessionConnectedAt.delete(safeId);
    await removeAuthPathCompletely(authPath, {
      attempts: 4,
      retryDelayMs: 100,
      onAttempt: ({ attempt, maxAttempts }) => {
        if (attempt > 1) {
          logWa(
            "WARN",
            safeId,
            "PAIR",
            "AUTH_DELETE_RETRY",
            "mengulangi penghapusan auth lama sebelum pairing",
            { attempt, maxAttempts },
          );
        }
      },
    });
    await verifyAuthPathClean(authPath);
    logWa(
      "INFO",
      safeId,
      "PAIR",
      "AUTH_CLEAN_VERIFIED",
      "auth bersih terverifikasi",
      { requestedPhone: requestedPhone || "-", source },
    );
    logWa(
      "INFO",
      safeId,
      "PAIR",
      "START_NEW_NUMBER",
      "memulai pairing nomor baru",
      {
        previousPhone: previousPhone || "-",
        requestedPhone: requestedPhone || "-",
        source,
      },
    );

    return startWAUnlocked(safeId, {
      requireCleanAuth: true,
      pairingPhone: requestedPhone,
    });
  });
}

// Fungsi requestPairingCode: membuat kode pairing dari auth baru yang benar-benar bersih.
async function requestPairingCode(userId, phoneNumberDigits) {
  const safeUserId = normalizeUserId(userId);
  qrModeUsers.delete(safeUserId);
  if (isConnected(safeUserId)) return { alreadyConnected: true };

  let session = await prepareFreshPairingSession(
    safeUserId,
    phoneNumberDigits,
    "pairing_request",
  );
  if (session.connected) return { alreadyConnected: true };
  if (!session.sock)
    throw new Error("WA socket belum siap. Coba ulang beberapa detik lagi.");
  if (typeof session.sock.requestPairingCode !== "function")
    throw new Error(
      "Baileys kamu belum support pairing code. Coba update @whiskeysockets/baileys.",
    );

  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      await waitForPairingSocketReady(session);
      const code = await session.sock.requestPairingCode(
        phoneNumberDigits,
        getCustomPairingCode(),
      );
      return { alreadyConnected: false, code };
    } catch (error) {
      const statusCode = error?.output?.statusCode;
      const errorMessage = error?.message || String(error);
      logWa(
        attempt === 1 ? "WARN" : "ERROR",
        safeUserId,
        "PAIR",
        attempt === 1 ? "ATTEMPT_FAIL" : "FAIL",
        "permintaan pairing code gagal",
        { attempt, code: statusCode ?? "-", error: errorMessage },
      );
      const shouldRetry =
        attempt === 1 &&
        (/Connection Closed/i.test(errorMessage) ||
          statusCode === DisconnectReason.connectionClosed ||
          statusCode === DisconnectReason.restartRequired ||
          statusCode === DisconnectReason.loggedOut);
      if (!shouldRetry) throw error;
      await sleep(1000);
      session = await prepareFreshPairingSession(
        safeUserId,
        phoneNumberDigits,
        "pairing_retry",
      );
    }
  }
  throw new Error("Pairing gagal setelah percobaan ulang.");
}
function firstFilled(...values) {
  for (const value of values) {
    if (Array.isArray(value)) {
      const joined = value.filter(Boolean).join(", ").trim();
      if (joined) return joined;
      continue;
    }
    if (value !== undefined && value !== null && String(value).trim()) {
      return String(value).trim();
    }
  }
  return "";
}

function getContactName(sock, jid) {
  return firstFilled(
    sock?.contacts?.[jid]?.notify,
    sock?.contacts?.[jid]?.name,
    sock?.contacts?.[jid]?.verifiedName,
  );
}

// Mengambil runtime Sender yang benar-benar dimiliki user untuk satu operasi
// pengecekan. Sender default memakai map legacy, sedangkan Sender tambahan
// memakai runtime terisolasi Tahap 2/3.
function getSenderCheckRuntime(userId, senderId = DEFAULT_SENDER_ID) {
  const safeUserId = normalizeUserId(userId);
  const safeSenderId = normalizeSenderId(senderId || DEFAULT_SENDER_ID);
  if (safeSenderId === DEFAULT_SENDER_ID) {
    return {
      userId: safeUserId,
      senderId: DEFAULT_SENDER_ID,
      session: sessions.get(safeUserId) || null,
      getCurrentSession: () => sessions.get(safeUserId) || null,
    };
  }
  const key = getAdditionalSenderKey(safeUserId, safeSenderId);
  return {
    userId: safeUserId,
    senderId: safeSenderId,
    session: additionalSenderSessions.get(key) || null,
    getCurrentSession: () => additionalSenderSessions.get(key) || null,
  };
}

// Pengecekan profil melalui Sender spesifik. Fungsi ini adalah jembatan
// backend Tahap 5: scheduler memilih senderId milik user, lalu seluruh query
// WhatsApp dilakukan hanya melalui socket Sender tersebut.
async function cekBioEnhancedForSender(
  userId,
  senderId,
  numberDigits,
  { signal } = {},
) {
  const runtime = getSenderCheckRuntime(userId, senderId);
  const { userId: safeId, senderId: safeSenderId, session } = runtime;
  if (!session?.connected || !session.sock) {
    const error = new WaCheckError("Sender belum CONNECTED", {
      code: "WA_SENDER_NOT_CONNECTED",
      retryable: true,
    });
    error.senderId = safeSenderId;
    throw error;
  }

  const activeSocket = session.sock;
  const jid = `${numberDigits}@s.whatsapp.net`;
  try {
    signal?.throwIfAborted();
    const waInfo = await queryOnWhatsAppCombo(activeSocket, numberDigits);
    signal?.throwIfAborted();
    if (waInfo.status === "not_registered") {
      return {
        number: numberDigits,
        exists: false,
        status: "not_registered",
        checkEngine: `onWhatsApp:${waInfo.method}`,
      };
    }
    if (waInfo.status !== "registered") {
      throw new WaCheckError("Status pemeriksaan WhatsApp tidak dikenal.", {
        code: "WA_UNKNOWN_CHECK_STATUS",
        retryable: false,
      });
    }

    const found = waInfo.found || {};
    const profile = await fetchPublicWaProfile({
      sock: activeSocket,
      jid,
      found,
      signal,
      presenceTimeoutMs: config.PROFILE_PRESENCE_TIMEOUT_MS,
      isSessionActive: () => {
        const current = runtime.getCurrentSession();
        return Boolean(current?.connected && current.sock === activeSocket);
      },
    });
    signal?.throwIfAborted();

    return createRegisteredProfileResult({
      number: numberDigits,
      waMethod: waInfo.method,
      profile,
      pushName: getContactName(activeSocket, jid),
    });
  } catch (error) {
    logWa("ERROR", safeId, "CHECK", "FAIL", "cek bio gagal di layer WA", {
      senderId: safeSenderId,
      phone: numberDigits,
      error: error.message,
    });
    throw error;
  }
}

// API compatibility lama tetap memakai Sender default. Flow /cekbio dan
// /cekbiotxt multi-Sender menggunakan cekBioEnhancedForSender melalui Sender
// Check Router.
async function cekBioEnhanced(userId, numberDigits, { signal } = {}) {
  return cekBioEnhancedForSender(
    userId,
    DEFAULT_SENDER_ID,
    numberDigits,
    { signal },
  );
}

// Fungsi startQrPairingSession: memulai sesi bersih dengan mode QR.
// QR akan dikirim ke atas via qrNotifier (setQrNotifier) saat event qr datang.
async function startQrPairingSession(userId) {
  const safeUserId = normalizeUserId(userId);
  if (isConnected(safeUserId)) return { alreadyConnected: true };

  await runAuthLifecycleExclusive(safeUserId, async () => {
    const authPath = getAuthPath(safeUserId);
    await stopWA(safeUserId);
    sessions.delete(safeUserId);
    sessionConnectedAt.delete(safeUserId);
    await removeAuthPathCompletely(authPath, { attempts: 4, retryDelayMs: 100 });
    await verifyAuthPathClean(authPath);
    logWa("INFO", safeUserId, "PAIR", "QR_CLEAN_VERIFIED", "auth bersih untuk mode QR", {});
    qrModeUsers.add(safeUserId);
    return startWAUnlocked(safeUserId, { requireCleanAuth: true, qrMode: true });
  });

  return { alreadyConnected: false, qrMode: true };
}


// ===== MULTI-SENDER RUNTIME — TAHAP 2 =====
// API lama di atas tetap merepresentasikan sender `default` supaya jalur /cekbio
// tidak berubah. Fungsi di bawah menyalakan sender tambahan secara independen.
function getAdditionalSenderKey(userId, senderId) {
  return `${normalizeUserId(userId)}:${normalizeSenderId(senderId)}`;
}

function readSenderCredsFile(userId, senderId) {
  const safeUserId = normalizeUserId(userId);
  const safeSenderId = normalizeSenderId(senderId);
  const credsPath = getSenderCredsPath(safeUserId, safeSenderId);
  try {
    if (!fs.existsSync(credsPath)) return null;
    return JSON.parse(fs.readFileSync(credsPath, "utf-8"));
  } catch (error) {
    logWa("WARN", safeUserId, "AUTH", "SENDER_CREDS_READ_FAIL", "gagal membaca creds sender", {
      senderId: safeSenderId,
      error: error?.message || String(error),
    });
    return null;
  }
}

function getSenderRegisteredPhoneNumber(userId, senderId) {
  if (normalizeSenderId(senderId) === DEFAULT_SENDER_ID) {
    return getRegisteredPhoneNumber(userId);
  }
  const creds = readSenderCredsFile(userId, senderId);
  const rawId = String(creds?.me?.id || "").trim();
  if (!rawId) return "";
  return rawId.split("@")[0].split(":")[0].replace(/\D/g, "");
}

function hasSenderAuthSession(userId, senderId) {
  if (normalizeSenderId(senderId) === DEFAULT_SENDER_ID) return hasAuthSession(userId);
  const creds = readSenderCredsFile(userId, senderId);
  return Boolean(creds?.registered && creds?.me?.id);
}

function getSenderAuthStateLabel(userId, senderId) {
  if (normalizeSenderId(senderId) === DEFAULT_SENDER_ID) return getAuthStateLabel(userId);
  const creds = readSenderCredsFile(userId, senderId);
  if (!creds) return "no-auth";
  if (creds?.registered && creds?.me?.id) return "registered-auth";
  return "partial-auth";
}

function hasAnySenderAuthData(userId, senderId) {
  const authPath = getSenderAuthPath(userId, senderId);
  try {
    if (!fs.existsSync(authPath)) return false;
    return fs.readdirSync(authPath).length > 0;
  } catch {
    return false;
  }
}

function runAdditionalSenderLifecycleExclusive(userId, senderId, task) {
  const safeUserId = normalizeUserId(userId);
  const safeSenderId = normalizeSenderId(senderId);
  const key = getAdditionalSenderKey(safeUserId, safeSenderId);
  const previous = additionalSenderLifecycleOperations.get(key) || Promise.resolve();
  const run = previous.then(task, task);
  const settledGate = run.then(() => undefined, () => undefined);
  let tracked = null;
  tracked = settledGate.finally(() => {
    if (additionalSenderLifecycleOperations.get(key) === tracked) {
      additionalSenderLifecycleOperations.delete(key);
    }
  });
  additionalSenderLifecycleOperations.set(key, tracked);
  return run;
}

function getOrCreateAdditionalSenderSession(userId, senderId) {
  const safeUserId = normalizeUserId(userId);
  const safeSenderId = normalizeSenderId(senderId);
  if (safeSenderId === DEFAULT_SENDER_ID) {
    throw new Error("Sender default harus memakai runtime compatibility.");
  }
  const key = getAdditionalSenderKey(safeUserId, safeSenderId);
  let session = additionalSenderSessions.get(key);
  if (!session) {
    session = {
      userId: safeUserId,
      senderId: safeSenderId,
      key,
      authPath: getSenderAuthPath(safeUserId, safeSenderId),
      sock: null,
      connected: false,
      ready: false,
      qrMode: false,
      startingPromise: null,
      reconnectTimer: null,
      reconnectAttempts: 0,
      terminalCleanupStarted: false,
      stopRequested: false,
      connectivityState: "dead",
      pendingAuthWrites: new Set(),
    };
    additionalSenderSessions.set(key, session);
  }
  return session;
}

function setAdditionalSenderConnectivityState(session, state, event = {}) {
  if (!session) return false;
  if (!["ready", "reconnecting", "dead"].includes(state)) {
    throw new Error(`Status konektivitas Sender tidak valid: ${state}`);
  }
  const previousState = session.connectivityState || "dead";
  session.connectivityState = state;
  if (previousState === state && event.force !== true) return false;
  notifySenderConnectivity(session.userId, session.senderId, state, {
    previousState,
    ...event,
  });
  return true;
}

function shouldReconnectAdditionalSender(session, code, reason = "") {
  const authState = getSenderAuthStateLabel(session.userId, session.senderId);
  const attempts = Number(session.reconnectAttempts || 0);
  if (session.stopRequested) return false;
  if (code === DisconnectReason.loggedOut) return false;
  if (isExpectedAuthTimeout(code, authState, reason)) return false;
  if (isAccessDeniedClose(code, reason)) return false;
  if (hasSenderAuthSession(session.userId, session.senderId)) {
    return attempts < MAX_REGISTERED_RECONNECT_ATTEMPTS;
  }

  // Pada flow QR sender tambahan, Baileys kadang menutup socket sebelum auth
  // terbentuk tanpa lastDisconnect/statusCode. Jangan langsung mematikan slot:
  // beri kesempatan reconnect terbatas agar QR baru dapat diterbitkan lagi.
  const silentQrClose =
    session.qrMode === true &&
    authState !== "registered-auth" &&
    (code === undefined || code === null) &&
    (!reason || String(reason) === "-");
  if (silentQrClose) {
    return attempts < MAX_AUTH_FLOW_RECONNECT_ATTEMPTS;
  }

  const authFlowClose =
    code === DisconnectReason.connectionClosed ||
    code === DisconnectReason.timedOut ||
    code === DisconnectReason.restartRequired ||
    /Connection Terminated|Connection Closed|Connection Failure|WebSocket Error/i.test(
      String(reason || ""),
    );
  return authFlowClose && attempts < MAX_AUTH_FLOW_RECONNECT_ATTEMPTS;
}

function emitAdditionalSenderQr(userId, senderId, qr) {
  if (!qrNotifier) return;
  try {
    // Argumen kedua tetap QR agar kompatibel dengan notifier lama; senderId
    // ditambahkan sebagai argumen ketiga. Promise notifier juga ditangkap agar
    // kegagalan Telegram tidak berubah menjadi rejection yang tidak terlihat.
    Promise.resolve(qrNotifier(userId, qr, senderId)).catch((error) => {
      logWa("WARN", userId, "PAIR", "QR_NOTIFY_FAIL", "gagal mengirim QR sender", {
        senderId,
        error: error?.message || String(error),
      });
    });
  } catch (error) {
    logWa("WARN", userId, "PAIR", "QR_NOTIFY_FAIL", "gagal mengirim QR sender", {
      senderId,
      error: error?.message || String(error),
    });
  }
}

async function startAdditionalSenderUnlocked(userId, senderId, options = {}) {
  const session = getOrCreateAdditionalSenderSession(userId, senderId);
  const requireCleanAuth = options.requireCleanAuth === true;
  const pairingPhone = String(options.pairingPhone || "").replace(/\D/g, "");
  // Jangan reset qrMode hanya karena caller melakukan ensure/get dengan options
  // kosong. Flow UI QR memulai socket dengan qrMode=true lalu watcher langsung
  // memanggil ensureSenderConnectedSession(); sebelumnya panggilan ensure ini
  // mengubah qrMode menjadi false tepat sebelum event QR datang. Hanya ubah mode
  // bila caller memang mengirim opsi qrMode secara eksplisit.
  if (Object.prototype.hasOwnProperty.call(options, "qrMode")) {
    session.qrMode = options.qrMode === true;
  }
  if (session.connected && session.sock) return session;
  if (session.startingPromise) {
    await session.startingPromise;
    return session;
  }
  if (session.sock) return session;

  session.stopRequested = false;
  clearReconnectTimer(session);
  setAdditionalSenderConnectivityState(session, "reconnecting", { source: "start" });
  session.startingPromise = (async () => {
    await ensurePrivateDirectory(AUTH_ROOT);
    if (requireCleanAuth) await verifyAuthPathClean(session.authPath);
    await ensurePrivateDirectory(session.authPath);
    if (requireCleanAuth) await verifyAuthPathClean(session.authPath);

    const corruptFiles = listCorruptAuthJsonFiles(session.authPath);
    if (corruptFiles.length) {
      throw new Error(`Auth WA corrupt: ${corruptFiles.join(", ")}`);
    }

    const { state, saveCreds } = await useMultiFileAuthState(session.authPath);
    await hardenAuthTree(session.authPath);
    const version = await getBaileysVersion();
    const sock = makeWASocket({
      version,
      auth: state,
      logger: P({ level: "silent" }),
      markOnlineOnConnect: false,
      defaultQueryTimeoutMs: config.WA_QUERY_TIMEOUT_MS,
      browser: getPairingBrowser(),
      syncFullHistory: false,
      qrTimeout: 60000,
    });

    session.sock = sock;
    session.connected = false;
    session.ready = false;

    sock.ev.on("creds.update", (creds) => {
      if (
        session.stopRequested ||
        additionalSenderSessions.get(session.key) !== session ||
        session.sock !== sock
      ) return;
      const writePromise = Promise.resolve()
        .then(async () => {
          if (session.stopRequested || session.sock !== sock) return;
          await saveCreds(creds);
          if (session.stopRequested || session.sock !== sock) return;
          await hardenAuthTree(session.authPath);
        })
        .catch((error) => {
          logWa("ERROR", session.userId, "AUTH", "SENDER_CREDS_SAVE_FAIL", "gagal menyimpan credentials sender", {
            senderId: session.senderId,
            error: error?.message || String(error),
          });
        });
      trackAuthWrite(session, writePromise);
    });

    sock.ev.on("connection.update", (update) => {
      const { connection, lastDisconnect, qr } = update;
      logWa("INFO", session.userId, "SOCKET", "SENDER_UPDATE", "connection.update sender diterima", {
        senderId: session.senderId,
        connection: connection || "-",
        hasQr: qr ? "yes" : "no",
        qrMode: session.qrMode ? "yes" : "no",
      });
      if (qr && session.qrMode) {
        logWa("INFO", session.userId, "PAIR", "SENDER_QR_RECEIVED", "QR sender tambahan diterima", {
          senderId: session.senderId,
        });
        emitAdditionalSenderQr(session.userId, session.senderId, qr);
      }
      if (connection === "open") {
        session.connected = true;
        session.ready = false;
        setAdditionalSenderConnectivityState(session, "reconnecting", {
          source: "socket_open",
          connection: "open",
        });
        session.qrMode = false;
        session.reconnectAttempts = 0;
        session.terminalCleanupStarted = false;
        additionalSenderConnectedAt.set(session.key, Date.now());
        clearReconnectTimer(session);
        logWa("INFO", session.userId, "SOCKET", "SENDER_OPEN", "sender tambahan connected", {
          senderId: session.senderId,
          phone: getSenderRegisteredPhoneNumber(session.userId, session.senderId) || pairingPhone || "-",
        });
        return;
      }
      if (connection !== "close") return;

      const code = lastDisconnect?.error?.output?.statusCode;
      const reason =
        lastDisconnect?.error?.message ||
        lastDisconnect?.error?.data ||
        lastDisconnect?.error?.output?.payload?.message ||
        "-";
      const authState = getSenderAuthStateLabel(session.userId, session.senderId);
      const shouldReconnect = shouldReconnectAdditionalSender(session, code, reason);
      session.connected = false;
      session.ready = false;
      if (session.sock === sock) session.sock = null;
      setAdditionalSenderConnectivityState(
        session,
        shouldReconnect ? "reconnecting" : "dead",
        {
          source: "socket_close",
          connection: "close",
          connected: false,
          code: code ?? null,
          reason: String(reason || "-"),
          authState,
          shouldReconnect,
        },
      );

      logWa(shouldReconnect ? "WARN" : "INFO", session.userId, "SOCKET", "SENDER_CLOSE", "sender tambahan terputus", {
        senderId: session.senderId,
        code: code ?? "-",
        authState,
        reconnect: shouldReconnect ? "yes" : "no",
        reason,
      });

      if (!shouldReconnect) {
        clearReconnectTimer(session);
        session.reconnectAttempts = 0;
        const terminalDisconnect = isTerminalSessionDisconnect({
          stopRequested: session.stopRequested,
          authState,
          shouldReconnect,
        });
        const cleanupTerminalSender =
          terminalDisconnect && session.terminalCleanupStarted !== true;
        if (cleanupTerminalSender) {
          session.terminalCleanupStarted = true;
          notifyTerminalDisconnect(session.userId, {
            senderId: session.senderId,
            number: getSenderRegisteredPhoneNumber(session.userId, session.senderId),
            code: code ?? null,
            codeName:
              typeof code === "number" ? DisconnectReason[code] || "-" : "-",
            reason: String(reason || "-"),
            authState,
            loggedOut: code === DisconnectReason.loggedOut,
            accessDenied: isAccessDeniedClose(code, reason),
            reconnectExhausted:
              code !== DisconnectReason.loggedOut &&
              !isAccessDeniedClose(code, reason),
            autoRemoved: true,
          });
        }
        const abandonedPairing =
          authState !== "registered-auth" && session.qrMode === true;
        const shouldAutoRemove =
          cleanupTerminalSender ||
          abandonedPairing ||
          shouldClearAuthOnClose(code, authState, reason);
        if (shouldAutoRemove) {
          const cleanupSource = cleanupTerminalSender
            ? code === DisconnectReason.loggedOut
              ? "logged_out"
              : isAccessDeniedClose(code, reason)
                ? "access_denied"
                : "terminal_disconnect"
            : abandonedPairing
              ? "abandoned_qr_pairing"
              : "auth_timeout";
          void resetAdditionalSender(session.userId, session.senderId, {
            source: cleanupSource,
          }).catch((error) => {
            logWa("WARN", session.userId, "AUTH", "SENDER_AUTO_CLEAN_FAIL", "gagal membersihkan auth sender tambahan", {
              senderId: session.senderId,
              error: error?.message || String(error),
            });
          });
        }
        return;
      }

      session.reconnectAttempts = (session.reconnectAttempts || 0) + 1;
      const delayMs = getReconnectDelayMs(session, code, reason);
      // Simpan mode QR sebelum socket lama diganti. Tanpa ini reconnect auth-flow
      // memanggil startAdditionalSender() dengan options kosong dan qrMode
      // berubah false, sehingga QR sender kedua tidak pernah diterbitkan lagi.
      const continueQrMode =
        session.qrMode === true &&
        !hasSenderAuthSession(session.userId, session.senderId);
      clearReconnectTimer(session);
      session.reconnectTimer = setTimeout(() => {
        session.reconnectTimer = null;
        startAdditionalSender(session.userId, session.senderId, {
          qrMode: continueQrMode,
        }).catch((error) => {
          logWa("ERROR", session.userId, "SOCKET", "SENDER_RECONNECT_FAIL", "reconnect sender tambahan gagal", {
            senderId: session.senderId,
            error: error?.message || String(error),
          });
        });
      }, delayMs);
    });
  })()
    .catch((error) => {
      if (!session.connected && !session.reconnectTimer && !session.stopRequested) {
        setAdditionalSenderConnectivityState(session, "dead", {
          source: "start_failed",
          error: error?.message || String(error),
        });
      }
      throw error;
    })
    .finally(() => {
      session.startingPromise = null;
    });

  await session.startingPromise;
  return session;
}

async function startAdditionalSender(userId, senderId, options = {}) {
  const safeSenderId = normalizeSenderId(senderId);
  return runAdditionalSenderLifecycleExclusive(userId, safeSenderId, () =>
    startAdditionalSenderUnlocked(userId, safeSenderId, options),
  );
}

async function stopAdditionalSender(userId, senderId) {
  const safeUserId = normalizeUserId(userId);
  const safeSenderId = normalizeSenderId(senderId);
  const key = getAdditionalSenderKey(safeUserId, safeSenderId);
  const session = additionalSenderSessions.get(key);
  if (!session) return;
  session.stopRequested = true;
  session.connected = false;
  session.ready = false;
  session.reconnectAttempts = 0;
  setAdditionalSenderConnectivityState(session, "dead", { source: "stop" });
  clearReconnectTimer(session);
  const sock = session.sock;
  session.sock = null;
  closeSocket(sock);
  await waitForPendingAuthWrites(session);
  await sleep(100);
  await waitForPendingAuthWrites(session);
  additionalSenderSessions.delete(key);
  additionalSenderConnectedAt.delete(key);
}

async function resetAdditionalSender(userId, senderId, options = {}) {
  const safeUserId = normalizeUserId(userId);
  const safeSenderId = normalizeSenderId(senderId);
  if (safeSenderId === DEFAULT_SENDER_ID) {
    return forceResetWA(safeUserId, options);
  }
  const authPath = getSenderAuthPath(safeUserId, safeSenderId);
  return runAdditionalSenderLifecycleExclusive(safeUserId, safeSenderId, async () => {
    const previousPhone = getSenderRegisteredPhoneNumber(safeUserId, safeSenderId);
    const hadAuthBefore = hasAnySenderAuthData(safeUserId, safeSenderId);
    await stopAdditionalSender(safeUserId, safeSenderId);
    await removeAuthPathCompletely(authPath, { attempts: 4, retryDelayMs: 100 });
    await verifyAuthPathClean(authPath);
    pruneEmptySenderContainers(safeUserId);
    return {
      skipped: false,
      senderId: safeSenderId,
      previousPhone,
      hadAuthBefore,
      authDeleted: true,
      hasAuthAfterReset: false,
      autoRestarted: false,
      source: String(options.source || "sender_reset"),
    };
  });
}

function shouldUseDefaultForNewSender(userId) {
  const safeUserId = normalizeUserId(userId);
  return !isConnected(safeUserId) && !hasAuthSession(safeUserId);
}

function allocateSenderSlotForPairing(userId) {
  const safeUserId = normalizeUserId(userId);
  if (shouldUseDefaultForNewSender(safeUserId)) {
    createSenderSlot(safeUserId, DEFAULT_SENDER_ID);
    return { userId: safeUserId, senderId: DEFAULT_SENDER_ID, authPath: getAuthPath(safeUserId) };
  }
  return createSenderSlot(safeUserId);
}

async function prepareFreshAdditionalPairingSession(userId, senderId, phoneNumberDigits, source) {
  const safeUserId = normalizeUserId(userId);
  const safeSenderId = normalizeSenderId(senderId);
  const requestedPhone = String(phoneNumberDigits || "").replace(/\D/g, "");
  const authPath = getSenderAuthPath(safeUserId, safeSenderId);
  return runAdditionalSenderLifecycleExclusive(safeUserId, safeSenderId, async () => {
    await stopAdditionalSender(safeUserId, safeSenderId);
    await removeAuthPathCompletely(authPath, { attempts: 4, retryDelayMs: 100 });
    await verifyAuthPathClean(authPath);
    createSenderSlot(safeUserId, safeSenderId);
    logWa("INFO", safeUserId, "PAIR", "SENDER_START_NEW_NUMBER", "memulai pairing sender tambahan", {
      senderId: safeSenderId,
      requestedPhone: requestedPhone || "-",
      source,
    });
    return startAdditionalSenderUnlocked(safeUserId, safeSenderId, {
      requireCleanAuth: true,
      pairingPhone: requestedPhone,
    });
  });
}

async function requestNewSenderPairingCode(userId, phoneNumberDigits) {
  const safeUserId = normalizeUserId(userId);
  const slot = allocateSenderSlotForPairing(safeUserId);
  if (slot.senderId === DEFAULT_SENDER_ID) {
    try {
      const result = await requestPairingCode(safeUserId, phoneNumberDigits);
      return { ...result, senderId: DEFAULT_SENDER_ID };
    } catch (error) {
      throw error;
    }
  }

  const senderId = slot.senderId;
  let session = await prepareFreshAdditionalPairingSession(
    safeUserId,
    senderId,
    phoneNumberDigits,
    "multi_sender_pairing_request",
  );
  if (!session.sock || typeof session.sock.requestPairingCode !== "function") {
    await resetAdditionalSender(safeUserId, senderId, { source: "pairing_unsupported" }).catch(() => {});
    throw new Error("Baileys kamu belum support pairing code. Coba update @whiskeysockets/baileys.");
  }

  for (let attempt = 1; attempt <= 2; attempt += 1) {
    try {
      await waitForPairingSocketReady(session);
      const code = await session.sock.requestPairingCode(
        phoneNumberDigits,
        getCustomPairingCode(),
      );
      return { alreadyConnected: false, code, senderId };
    } catch (error) {
      const statusCode = error?.output?.statusCode;
      const errorMessage = error?.message || String(error);
      const shouldRetry =
        attempt === 1 &&
        (/Connection Closed/i.test(errorMessage) ||
          statusCode === DisconnectReason.connectionClosed ||
          statusCode === DisconnectReason.restartRequired ||
          statusCode === DisconnectReason.loggedOut);
      if (!shouldRetry) {
        await resetAdditionalSender(safeUserId, senderId, { source: "pairing_failed" }).catch(() => {});
        throw error;
      }
      await sleep(1000);
      session = await prepareFreshAdditionalPairingSession(
        safeUserId,
        senderId,
        phoneNumberDigits,
        "multi_sender_pairing_retry",
      );
    }
  }
  throw new Error("Pairing gagal setelah percobaan ulang.");
}

async function startNewQrPairingSession(userId, options = {}) {
  const safeUserId = normalizeUserId(userId);
  const slot = allocateSenderSlotForPairing(safeUserId);
  const onSenderAllocated =
    typeof options.onSenderAllocated === "function"
      ? options.onSenderAllocated
      : null;

  // Penting untuk UI multi-sender: beritahu senderId SEBELUM socket dinyalakan.
  // Event QR bisa datang sangat cepat; tanpa binding awal, QR lama dari sender
  // lain dapat merebut panel user dan QR sender kedua kemudian terfilter.
  if (onSenderAllocated) onSenderAllocated(slot.senderId);

  if (slot.senderId === DEFAULT_SENDER_ID) {
    const result = await startQrPairingSession(safeUserId);
    return { ...result, senderId: DEFAULT_SENDER_ID };
  }

  const senderId = slot.senderId;
  const authPath = getSenderAuthPath(safeUserId, senderId);
  await runAdditionalSenderLifecycleExclusive(safeUserId, senderId, async () => {
    await stopAdditionalSender(safeUserId, senderId);
    await removeAuthPathCompletely(authPath, { attempts: 4, retryDelayMs: 100 });
    await verifyAuthPathClean(authPath);
    createSenderSlot(safeUserId, senderId);
    return startAdditionalSenderUnlocked(safeUserId, senderId, {
      requireCleanAuth: true,
      qrMode: true,
    });
  });
  return { alreadyConnected: false, qrMode: true, senderId };
}

async function ensureSenderConnectedSession(userId, senderId, timeoutMs = 10000) {
  const safeSenderId = normalizeSenderId(senderId || DEFAULT_SENDER_ID);
  if (safeSenderId === DEFAULT_SENDER_ID) return ensureConnectedSession(userId, timeoutMs);
  const session = await startAdditionalSender(userId, safeSenderId);
  if (session.connected) return true;
  const until = Date.now() + timeoutMs;
  while (Date.now() < until) {
    if (session.connected) return true;
    await sleep(400);
  }
  return session.connected;
}

function isSenderConnected(userId, senderId = DEFAULT_SENDER_ID) {
  const safeSenderId = normalizeSenderId(senderId);
  if (safeSenderId === DEFAULT_SENDER_ID) return isConnected(userId);
  const key = getAdditionalSenderKey(userId, safeSenderId);
  return additionalSenderSessions.get(key)?.connected === true;
}

function markSenderReady(userId, senderId = DEFAULT_SENDER_ID, event = {}) {
  const safeSenderId = normalizeSenderId(senderId);
  if (safeSenderId === DEFAULT_SENDER_ID) return markSessionReady(userId, event);
  const key = getAdditionalSenderKey(userId, safeSenderId);
  const session = additionalSenderSessions.get(key);
  if (!session?.connected) return false;
  session.ready = true;
  setAdditionalSenderConnectivityState(session, "ready", event);
  return true;
}

function isSenderReady(userId, senderId = DEFAULT_SENDER_ID) {
  const safeSenderId = normalizeSenderId(senderId);
  if (safeSenderId === DEFAULT_SENDER_ID) return isSessionReady(userId);
  const key = getAdditionalSenderKey(userId, safeSenderId);
  const session = additionalSenderSessions.get(key);
  return session?.connected === true && session?.ready === true;
}

function getSenderSnapshotById(userId, senderId = DEFAULT_SENDER_ID) {
  const safeUserId = normalizeUserId(userId);
  const safeSenderId = normalizeSenderId(senderId);
  if (safeSenderId === DEFAULT_SENDER_ID) {
    return { senderId: DEFAULT_SENDER_ID, ...getSenderSnapshot(safeUserId) };
  }
  const key = getAdditionalSenderKey(safeUserId, safeSenderId);
  const session = additionalSenderSessions.get(key);
  const socketPhone = String(session?.sock?.user?.id || "")
    .split("@")[0]
    .split(":")[0]
    .replace(/\D/g, "");
  const number = socketPhone || getSenderRegisteredPhoneNumber(safeUserId, safeSenderId) || "";
  return {
    senderId: safeSenderId,
    connected: session?.connected === true,
    ready: session?.ready === true,
    registered: hasSenderAuthSession(safeUserId, safeSenderId),
    connectivityState: getSenderConnectivityState(safeUserId, safeSenderId),
    reconnectAttempts: Number(session?.reconnectAttempts || 0),
    number,
    connectedAt: Number(additionalSenderConnectedAt.get(key) || 0) || null,
  };
}

function getSenderSnapshots(userId) {
  const safeUserId = normalizeUserId(userId);
  const ids = new Set(listSenderIds(safeUserId));
  if (isConnected(safeUserId) || hasAuthSession(safeUserId)) ids.add(DEFAULT_SENDER_ID);
  for (const session of additionalSenderSessions.values()) {
    if (session.userId === safeUserId) ids.add(session.senderId);
  }
  return [...ids]
    .map((senderId) => getSenderSnapshotById(safeUserId, senderId))
    .filter((sender) => sender.connected || sender.registered)
    .sort((a, b) => {
      if (a.senderId === DEFAULT_SENDER_ID) return -1;
      if (b.senderId === DEFAULT_SENDER_ID) return 1;
      return String(a.senderId).localeCompare(String(b.senderId));
    });
}

async function cancelSenderPairing(userId, senderId = DEFAULT_SENDER_ID) {
  const safeSenderId = normalizeSenderId(senderId || DEFAULT_SENDER_ID);
  if (safeSenderId === DEFAULT_SENDER_ID) {
    return forceResetWA(userId, { source: "pairing_cancel", silent: true });
  }
  return resetAdditionalSender(userId, safeSenderId, {
    source: "pairing_cancel",
    silent: true,
  });
}

// Mengumpulkan semua sender yang diketahui untuk satu user, baik yang sedang
// hidup di RAM maupun yang hanya tersimpan di auth storage. Ini dipakai oleh
// UI penghapusan dan operasi "Putuskan Semua" agar sender yang sedang offline
// tetap bisa dibersihkan tanpa menyentuh sender milik user lain.
function getKnownSenderIds(userId) {
  const safeUserId = normalizeUserId(userId);
  const ids = new Set(listSenderIds(safeUserId));
  if (sessions.has(safeUserId) || hasAuthSession(safeUserId)) {
    ids.add(DEFAULT_SENDER_ID);
  }
  for (const session of additionalSenderSessions.values()) {
    if (session.userId === safeUserId) ids.add(session.senderId);
  }
  return [...ids].sort((a, b) => {
    if (a === DEFAULT_SENDER_ID) return -1;
    if (b === DEFAULT_SENDER_ID) return 1;
    return a.localeCompare(b);
  });
}

// Menghapus tepat satu sender. Sender lain mempunyai runtime, reconnect timer,
// socket, pending auth writes, dan folder auth sendiri sehingga operasi ini
// tidak boleh menghentikan atau menghapus state sender lain.
async function disconnectSender(userId, senderId = DEFAULT_SENDER_ID, options = {}) {
  const safeUserId = normalizeUserId(userId);
  const safeSenderId = normalizeSenderId(senderId || DEFAULT_SENDER_ID);
  const source = String(options.source || "sender_disconnect");
  if (safeSenderId === DEFAULT_SENDER_ID) {
    const result = await forceResetWA(safeUserId, { ...options, source });
    return { ...result, senderId: DEFAULT_SENDER_ID };
  }
  return resetAdditionalSender(safeUserId, safeSenderId, { ...options, source });
}

// Menghapus seluruh sender milik satu user saja. Tiap sender diproses lewat
// lifecycle lock masing-masing agar shutdown/auth write satu sender tidak
// berlomba dengan sender lainnya. Kegagalan satu sender tidak membatalkan
// pembersihan sender lain; caller mendapat ringkasan hasil per sender.
async function disconnectAllSenders(userId, options = {}) {
  const safeUserId = normalizeUserId(userId);
  const senderIds = getKnownSenderIds(safeUserId);
  const source = String(options.source || "sender_disconnect_all");
  const settled = await Promise.allSettled(
    senderIds.map((senderId) =>
      disconnectSender(safeUserId, senderId, { ...options, source }),
    ),
  );
  const results = settled.map((entry, index) => ({
    senderId: senderIds[index],
    ok: entry.status === "fulfilled",
    result: entry.status === "fulfilled" ? entry.value : null,
    error:
      entry.status === "rejected"
        ? entry.reason?.message || String(entry.reason)
        : null,
  }));
  return {
    userId: safeUserId,
    total: senderIds.length,
    deleted: results.filter((entry) => entry.ok).length,
    failed: results.filter((entry) => !entry.ok).length,
    results,
  };
}

async function stopAllAdditionalSenders() {
  const entries = [...additionalSenderSessions.values()].map((session) => ({
    userId: session.userId,
    senderId: session.senderId,
  }));
  await Promise.allSettled(
    entries.map(({ userId, senderId }) => stopAdditionalSender(userId, senderId)),
  );
}

module.exports = {
  stopWA,
  stopAllWA,
  reloadWA,
  forceResetWA,
  setAutoDisconnectNotifier,
  setTerminalDisconnectNotifier,
  setQrNotifier,
  startQrPairingSession,
  subscribeSessionConnectivity,
  subscribeSenderConnectivity,
  subscribeSessionReady,
  getSessionConnectivityState,
  getSenderConnectivityState,
  markSessionReady,
  isSessionReady,
  requestPairingCode,
  isConnected,
  getSenderSnapshot,
  hasAuthSession,
  DEFAULT_SENDER_ID,
  listSenderIds,
  createSenderSlot,
  getSenderSnapshots,
  getSenderSnapshotById,
  requestNewSenderPairingCode,
  startNewQrPairingSession,
  ensureSenderConnectedSession,
  isSenderConnected,
  markSenderReady,
  isSenderReady,
  cancelSenderPairing,
  getKnownSenderIds,
  disconnectSender,
  disconnectAllSenders,
  ensureConnectedSession,
  cekBioEnhanced,
  cekBioEnhancedForSender,
  isRetryableWaCheckError,
};
