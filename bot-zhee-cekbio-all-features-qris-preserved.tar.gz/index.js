const { applyPrivateUmask } = require("./src/services/file-permissions.service");

applyPrivateUmask();

const { startBot } = require("./src/bootstrap/start-bot");

startBot().catch((error) => {
  console.error("[FATAL] Bot gagal dimulai:", error);
  process.exitCode = 1;
});
