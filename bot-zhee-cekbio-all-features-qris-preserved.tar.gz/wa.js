module.exports = require("./src/infrastructure/whatsapp/baileys-session-manager");
