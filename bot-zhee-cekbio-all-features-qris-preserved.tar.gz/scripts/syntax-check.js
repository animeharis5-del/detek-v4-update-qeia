const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");

const PROJECT_ROOT = path.resolve(__dirname, "..");
const SKIP_DIRECTORIES = new Set([
  ".git",
  "node_modules",
  "tmp",
  "wa_auth",
]);

function collectJavaScriptFiles(rootDir) {
  const files = [];
  const pending = [rootDir];
  while (pending.length) {
    const current = pending.pop();
    for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
      if (entry.isDirectory()) {
        if (!SKIP_DIRECTORIES.has(entry.name)) {
          pending.push(path.join(current, entry.name));
        }
        continue;
      }
      if (entry.isFile() && path.extname(entry.name).toLowerCase() === ".js") {
        files.push(path.join(current, entry.name));
      }
    }
  }
  return files.sort((a, b) => a.localeCompare(b));
}

const files = collectJavaScriptFiles(PROJECT_ROOT);
for (const filePath of files) {
  const result = spawnSync(process.execPath, ["--check", filePath], {
    cwd: PROJECT_ROOT,
    encoding: "utf8",
    shell: false,
  });
  if (result.status !== 0) {
    process.stderr.write(result.stdout || "");
    process.stderr.write(result.stderr || "");
    process.exit(result.status || 1);
  }
}

process.stdout.write(`Syntax check lulus: ${files.length} file JavaScript.\n`);
