module.exports = require("./src/repositories/stats.repository");
