const fsp = require("node:fs/promises");
const path = require("path");
const { createTempWorkspace } = require("./src/services/temp-dir.service");
const {
  buildReportHeader,
  buildMajorSectionHeader,
  buildSectionHeader,
  buildReportFooter,
} = require("./src/presentation/report-ui");

// Fungsi normalizeInputNumber: menerima format internasional tanpa memaksa nomor luar jadi Indonesia.
// Contoh: +855975401317 -> 855975401317, 006012345678 -> 6012345678, 0812xxx -> 62812xxx.
// Catatan: nomor yang langsung diawali 8 tidak lagi otomatis jadi 62, karena bisa saja kode negara luar seperti 855.
function normalizeInputNumber(raw) {
  const original = String(raw || "").trim();
  if (!original) return null;

  const hadPlusPrefix = original.startsWith("+");
  let s = original.replace(/\D/g, "");
  if (!s) return null;

  const hadDoubleZeroPrefix = !hadPlusPrefix && s.startsWith("00");
  if (hadDoubleZeroPrefix) s = s.slice(2);

  const wasExplicitInternational = hadPlusPrefix || hadDoubleZeroPrefix;
  if (!wasExplicitInternational && s.startsWith("0")) {
    s = "62" + s.slice(1);
  }

  if (!/^\d{8,15}$/.test(s)) return null;
  return s;
}

// Fungsi parseNumbersFromMessage: menjalankan bagian parse numbers from message pada bot.
function parseNumbersFromMessage(text, limit = Infinity) {
  const lines = String(text || "")
    .split(/\r?\n/)
    .map((x) => x.trim())
    .filter(Boolean);
  const first = (lines[0] || "").replace(/^\/cekbio(@\w+)?\s*/i, "").trim();
  let raw = [];
  if (first) raw.push(first);
  raw = raw.concat(lines.slice(1));
  const seen = new Set();
  const out = [];
  for (const r of raw) {
    for (const p of String(r)
      .split(/[\s,;]+/)
      .map((x) => x.trim())
      .filter(Boolean)) {
      const n = normalizeInputNumber(p);
      if (!n || seen.has(n)) continue;
      seen.add(n);
      out.push(n);
      if (out.length >= limit) return out;
    }
  }
  return out;
}

function filled(value) {
  return value !== undefined && value !== null && String(value).trim()
    ? String(value).trim()
    : "-";
}

function cleanOneLine(value) {
  return filled(value).replace(/\s+/g, " ").trim();
}

const PROFILE_FIELD_MARKERS = Object.freeze({
  empty: "(tidak diisi)",
  private: "(privasi)",
  unavailable: "(tidak tersedia)",
});

function getProfileField(result, key, legacyValue = "") {
  const profileField = result?.profileFields?.[key];
  if (profileField && typeof profileField === "object") {
    const status = String(profileField.status || "unavailable");
    if (status === "available") {
      return {
        status,
        value: cleanOneLine(profileField.value),
      };
    }
    return {
      status,
      value: PROFILE_FIELD_MARKERS[status] || PROFILE_FIELD_MARKERS.unavailable,
    };
  }
  const cleaned = cleanOneLine(legacyValue);
  return cleaned !== "-"
    ? { status: "available", value: cleaned }
    : { status: "empty", value: PROFILE_FIELD_MARKERS.empty };
}

function displayProfileField(result, key, legacyValue = "") {
  return getProfileField(result, key, legacyValue).value;
}

function isBusinessAccount(result) {
  return result?.accountType === "Business" ||
    (result?.klasifikasi && result.klasifikasi !== "WhatsApp Biasa");
}

function resultClassLabel(result) {
  const classification = classifyResult(result);
  const labels = {
    "Verified Meta Business": "VERIFIED META",
    "Standard Meta Business": "STANDARD META",
    "WA Business Biasa": "WA BUSINESS",
    "WhatsApp Biasa": "WA BIASA",
    "Tidak Terdaftar": "NOT REGISTERED",
    "Gagal Dicek": "FAILED",
  };
  return labels[classification] || String(classification || "UNKNOWN").toUpperCase();
}

const MOBILE_REPORT_WIDTH = 32;

function wrapReportText(value, width = 24) {
  const text = cleanOneLine(value);
  if (!text || text === "-") return [];
  const max = Math.max(10, Number(width) || 24);
  if (text.length <= max) return [text];
  const words = text.split(" ");
  const lines = [];
  let current = "";
  for (const word of words) {
    if (!current) {
      if (word.length <= max) current = word;
      else {
        for (let i = 0; i < word.length; i += max) lines.push(word.slice(i, i + max));
      }
      continue;
    }
    if (`${current} ${word}`.length <= max) current = `${current} ${word}`;
    else {
      lines.push(current);
      if (word.length <= max) current = word;
      else {
        for (let i = 0; i < word.length; i += max) lines.push(word.slice(i, i + max));
        current = "";
      }
    }
  }
  if (current) lines.push(current);
  return lines;
}

function formatQuickResultItem(result, index) {
  const number = `+${result?.number || "-"}`;
  const prefix = `#${Math.max(1, Number(index) || 1)}`;
  if (result?.error || result?.exists === null) {
    const lines = [`${prefix}  ${number} · FAILED`];
    if (result?.error) {
      const reason = wrapReportText(result.error, MOBILE_REPORT_WIDTH - 5);
      reason.forEach((line, idx) => lines.push(`${idx === 0 ? "   " : "   "}${line}`));
    }
    return `${lines.join("\n")}\n`;
  }
  if (!result?.exists) return `${prefix}  ${number}\n`;

  const base = `${prefix}  ${number}`;
  const meta = [];
  const joined = shortMemberSince(result.memberSince);
  if (joined) meta.push(joined.toUpperCase());
  const aiType = String(result.automatedType || "").toLowerCase();
  if (aiType && aiType !== "unknown") meta.push("AI");
  if (!meta.length) return `${base}\n`;
  const suffix = meta.join(" · ");
  const combined = `${base} · ${suffix}`;
  return combined.length <= MOBILE_REPORT_WIDTH
    ? `${combined}\n`
    : `${base}\n   ${suffix}\n`;
}

function renderDetailBlock(title, rows) {
  const cleanRows = rows.filter(([, value]) => isFilled(value));
  if (!cleanRows.length) return "";
  const lines = [title];
  cleanRows.forEach(([label, value], idx) => {
    const branch = idx === cleanRows.length - 1 ? "└" : "├";
    const continuation = idx === cleanRows.length - 1 ? " " : "│";
    const labelText = String(label || "-").trim();
    const prefix = `${branch} ${labelText} : `;
    const available = Math.max(12, MOBILE_REPORT_WIDTH - prefix.length);
    const wrapped = wrapReportText(value, available);
    if (!wrapped.length) return;
    lines.push(`${prefix}${wrapped[0]}`);
    const indent = `${continuation} ${" ".repeat(labelText.length + 2)}`;
    for (const chunk of wrapped.slice(1)) lines.push(`${indent}${chunk}`);
  });
  return lines.join("\n");
}

function formatDetailedResultItem(result, index) {
  const number = `+${result?.number || "-"}`;
  const prefix = `#${Math.max(1, Number(index) || 1)} · ${number}`;

  if (result?.error || result?.exists === null) {
    return `${prefix}\n${"─".repeat(MOBILE_REPORT_WIDTH)}\nFAILED\n└ Reason: ${cleanOneLine(result?.error || "unknown error")}\n\n`;
  }
  if (!result?.exists) return `${prefix}  ·  NOT REGISTERED\n`;

  if (!isBusinessAccount(result) && !isFilled(result.bio)) {
    return `${prefix}\n`;
  }

  const isBusiness = isBusinessAccount(result);
  const joined = shortMemberSince(result.memberSince);
  const classLabel = resultClassLabel(result);
  const aiType = String(result.automatedType || "").toLowerCase();
  const name = [result.name, result.verifiedName, result.pushName].find((value) => isFilled(value)) || "";
  const blocks = [];

  if (isBusiness) {
    blocks.push(renderDetailBlock("IDENTITY", [
      ["Type", "WA Business"],
      ["Meta", classLabel],
      ["Name", name],
      ["Joined", joined],
      ["Category", result.category],
      ["Agent AI", aiType && aiType !== "unknown" ? result.automatedType : ""],
    ]));
    blocks.push(renderDetailBlock("PROFILE", [
      ["Bio", result.bio],
      ["Bio Updated", result.setAt],
      ["Profile Photo", result.hasPhoto ? "Available" : ""],
    ]));
    blocks.push(renderDetailBlock("BUSINESS", [
      ["Description", result.description],
      ["Address", result.address],
      ["Business Hours", result.businessHours],
    ]));
    blocks.push(renderDetailBlock("CONTACT", [
      ["Email", result.email],
      ["Website", result.website],
    ]));
  } else {
    blocks.push(renderDetailBlock("PROFILE", [
      ["Type", "WA Biasa"],
      ["Joined", joined],
      ["Bio", result.bio],
      ["Bio Updated", result.setAt],
      ["Profile Photo", result.hasPhoto ? "Available" : ""],
    ]));
  }

  const body = blocks.filter(Boolean).join("\n\n");
  return `${prefix}\n${"─".repeat(MOBILE_REPORT_WIDTH)}\n${body || `TYPE\n└ Account: ${classLabel}`}\n\n`;
}

function shortMemberSince(memberSince) {
  const text = String(memberSince || "");
  if (!text) return "";
  const monthMap = {
    january: "Jan", february: "Feb", march: "Mar", april: "Apr",
    may: "Mei", june: "Jun", july: "Jul", august: "Agu",
    september: "Sep", october: "Okt", november: "Nov", december: "Des",
  };
  const low = text.toLowerCase();
  const monthNames = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];
  if (low.includes("this month")) {
    const now = new Date();
    return `${monthNames[now.getMonth()]} ${now.getFullYear()}`;
  }
  if (low.includes("last month")) {
    const now = new Date();
    let m = now.getMonth() - 1;
    let y = now.getFullYear();
    if (m < 0) { m = 11; y -= 1; }
    return `${monthNames[m]} ${y}`;
  }
  const ym = low.match(/([a-z]+)[,\s]+((?:19|20)\d{2})/);
  if (ym && monthMap[ym[1]]) return `${monthMap[ym[1]]} ${ym[2]}`;
  const yOnly = low.match(/((?:19|20)\d{2})/);
  if (yOnly) return yOnly[1];
  return cleanOneLine(text);
}

function isFilled(value) {
  const v = filled(value);
  return (
    v !== "-" &&
    v !== "Tidak ada" &&
    v !== "Tidak tersedia" &&
    v !== "Tidak tersedia / disembunyikan"
  );
}

// Fungsi classifyResult: menjalankan bagian classify result pada bot.
function classifyResult(result) {
  if (result?.error || result?.exists === null) return "Gagal Dicek";
  if (!result.exists) return "Tidak Terdaftar";
  if (result.klasifikasi === "WhatsApp Biasa") return "WhatsApp Biasa";
  const vlevel = String(result.vlevel || "").toLowerCase();
  if (vlevel === "high") return "Verified Meta Business";
  if (vlevel === "low") return "Standard Meta Business";
  if (vlevel === "unknown") return "WA Business Biasa";
  return "WA Business Biasa";
}

// Fungsi summarizeResults: menjalankan bagian summarize results pada bot.
function summarizeResults(results) {
  const groups = {
    "Verified Meta Business": [],
    "Standard Meta Business": [],
    "WA Business Biasa": [],
    "WhatsApp Biasa": [],
    "Tidak Terdaftar": [],
    "Gagal Dicek": [],
  };
  const counts = { verified: 0, standard: 0, wabiz: 0, wa: 0, not: 0, failed: 0 };
  let registered = 0;
  let bioDetected = 0;
  let photoDetected = 0;
  let businessDetected = 0;
  let emailDetected = 0;
  let websiteDetected = 0;
  let lastSeenDetected = 0;
  let hasBioCount = 0;
  let noBioCount = 0;
  let newAccountCount = 0;
  let flaggedCount = 0;
  let businessMetaCount = 0;
  let agentAiCount = 0;
  const registrationYears = {};
  const businessMetaClasses = [
    "Verified Meta Business",
    "Standard Meta Business",
    "WA Business Biasa",
  ];

  for (const result of results) {
    const cls = classifyResult(result);
    groups[cls].push(result);
    if (result.exists && businessMetaClasses.includes(cls)) {
      businessMetaCount++;
      if (isFilled(result.bio)) hasBioCount++;
      else noBioCount++;
      const ms = String(result.memberSince || "").toLowerCase();
      if (ms.includes("last month") || ms.includes("this month")) newAccountCount++;
      if (result.verifiedRevoked === true) flaggedCount++;
      const at = String(result.automatedType || "").toLowerCase();
      if (at && at !== "unknown") agentAiCount++;
      const ym = String(result.memberSince || "").match(/(20\d{2})/);
      if (ym) registrationYears[ym[1]] = (registrationYears[ym[1]] || 0) + 1;
    }
    if (result.exists === true) registered++;
    if (result.exists && isFilled(result.bio)) bioDetected++;
    if (result.exists && result.hasPhoto) photoDetected++;
    if (result.exists && result.klasifikasi !== "WhatsApp Biasa" && cls !== "WhatsApp Biasa") businessDetected++;
    if (result.exists && isFilled(result.email)) emailDetected++;
    if (result.exists && isFilled(result.website)) websiteDetected++;
    if (result.exists && isFilled(result.lastSeen)) lastSeenDetected++;

    if (cls === "Verified Meta Business") counts.verified++;
    else if (cls === "Standard Meta Business") counts.standard++;
    else if (cls === "WA Business Biasa") counts.wabiz = (counts.wabiz || 0) + 1;
    else if (cls === "WhatsApp Biasa") counts.wa++;
    else if (cls === "Gagal Dicek") counts.failed++;
    else counts.not++;
  }

  return {
    groups,
    counts,
    total: results.length,
    registered,
    bioDetected,
    photoDetected,
    businessDetected,
    emailDetected,
    websiteDetected,
    lastSeenDetected,
    notRegistered: counts.not,
    failedChecks: counts.failed,
    hasBioCount,
    noBioCount,
    newAccountCount,
    flaggedCount,
    businessMetaCount,
    agentAiCount,
    registrationYears,
  };
}

function detailPartition(results) {
  const businessClasses = new Set([
    "Verified Meta Business",
    "Standard Meta Business",
    "WA Business Biasa",
  ]);
  const parts = {
    businessWithBio: [],
    businessNoBio: [],
    normalWithBio: [],
    normalNoBio: [],
    notRegistered: [],
    failed: [],
  };
  for (const result of results) {
    const cls = classifyResult(result);
    if (cls === "Tidak Terdaftar") parts.notRegistered.push(result);
    else if (cls === "Gagal Dicek") parts.failed.push(result);
    else if (businessClasses.has(cls)) {
      (isFilled(result.bio) ? parts.businessWithBio : parts.businessNoBio).push(result);
    } else {
      (isFilled(result.bio) ? parts.normalWithBio : parts.normalNoBio).push(result);
    }
  }
  return parts;
}

// Fungsi buildTxtReport: laporan DETAIL = ringkasan SIMPLE + detail akun di bawahnya.
function buildTxtReport(results, titleName = "MOCI", emoji = {}) {
  const summary = summarizeResults(results);
  const groups = summary.groups;
  let out = buildReportHeader(summary, titleName, "DETAIL");
  out += buildMajorSectionHeader(2, "QUICK RESULT");

  const quickSections = [
    ["VERIFIED", groups["Verified Meta Business"]],
    ["STANDARD", groups["Standard Meta Business"]],
    ["WA BUSINESS", groups["WA Business Biasa"] || []],
    ["WA BIASA", groups["WhatsApp Biasa"]],
    ["NOT REGISTERED", groups["Tidak Terdaftar"]],
    ["FAILED", groups["Gagal Dicek"]],
  ];
  for (const [title, items] of quickSections) {
    out += buildSectionHeader("", title, items.length);
    if (!items.length) out += "(Tidak ada)\n\n";
    else {
      items.forEach((result, index) => { out += formatQuickResultItem(result, index + 1); });
      out += "\n";
    }
  }

  out += buildMajorSectionHeader(3, "ACCOUNT DETAILS");
  const detail = detailPartition(results);
  const detailSections = [
    ["BUSINESS · WITH BIO", detail.businessWithBio, true],
    ["BUSINESS · NO BIO", detail.businessNoBio, true],
    ["WA BIASA · WITH BIO", detail.normalWithBio, true],
    ["WA BIASA · NO BIO", detail.normalNoBio, false],
    ["NOT REGISTERED", detail.notRegistered, false],
    ["FAILED", detail.failed, false],
  ];
  for (const [title, items, verbose] of detailSections) {
    out += buildSectionHeader("", title, items.length);
    if (!items.length) out += "(Tidak ada)\n\n";
    else if (verbose) {
      items.forEach((result, index) => { out += formatDetailedResultItem(result, index + 1); });
      out += "\n";
    } else {
      items.forEach((result, index) => { out += formatQuickResultItem(result, index + 1); });
      out += "\n";
    }
  }

  out += buildReportFooter(reportFooterName(titleName), "DETAIL", summary.total);
  return out.trimEnd() + "\n";
}

// Fungsi chunkArray: menjalankan bagian chunk array pada bot.
function chunkArray(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

// Fungsi createTempResultFile: menjalankan bagian create temp result file pada bot.
async function createTempResultFile(baseName, content) {
  const tempDir = await createTempWorkspace("cekbio-result-");
  const filePath = path.join(tempDir, `${baseName}.txt`);
  try {
    await fsp.writeFile(filePath, content, { encoding: "utf8", mode: 0o600, flag: "wx" });
  } catch (error) {
    await fsp.rm(tempDir, { recursive: true, force: true }).catch(() => {});
    throw error;
  }
  return {
    filePath,
    async cleanup() {
      await fsp.rm(tempDir, { recursive: true, force: true }).catch((cleanupError) => {
        console.warn("Gagal membersihkan temp result file:", cleanupError.message);
      });
    },
  };
}

// Footer laporan: pakai username bot bila tersedia (env BOT_USERNAME),
// jika tidak, jatuh ke "CEKBIO · <titleName>".
function reportFooterName(titleName) {
  const uname = String(process.env.BOT_USERNAME || "").trim();
  if (uname) return uname.startsWith("@") ? uname : `@${uname}`;
  return `CEKBIO · ${titleName}`;
}

module.exports = {
  buildTxtReport,
  chunkArray,
  classifyResult,
  createTempResultFile,
  displayProfileField,
  filled,
  formatDetailedResultItem,
  formatQuickResultItem,
  shortMemberSince,
  reportFooterName,
  getProfileField,
  isFilled,
  normalizeInputNumber,
  parseNumbersFromMessage,
  summarizeResults,
};
