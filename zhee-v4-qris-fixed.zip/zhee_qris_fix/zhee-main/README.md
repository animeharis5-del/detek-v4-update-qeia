# ZHEE Checker — Recode Bundle

## Fitur di bundle ini
- Pemeriksaan nomor tunggal/multi-nomor; Free dibatasi 5 nomor per permintaan.
- Tier FREE/VIP/XVIP/VVIP; VIP 20, XVIP 50, VVIP 100 nomor per permintaan dan premium tanpa cooldown.
- Paket premium dan harga sesuai daftar permintaan; menu topup inline.
- Buat QRIS BuatQris melalui `api_create_qris`, cek status `api_check_status`, `/cekbayar <ID>`, tombol cek bayar, riwayat pembayaran, dan aktivasi tier dengan masa kedaluwarsa setelah status sukses diverifikasi ke provider.
- Laporan hasil deteksi menggunakan pesan Telegram biasa (bukan Rich Message), nomor tetap memakai `<code>` agar mudah diketuk/disalin.
- Tombol Ulangi Gagal sudah didaftarkan dan memvalidasi ID sesi; tidak menjalankan retry jika sesi tidak cocok/kedaluwarsa.
- Mempertahankan menu owner, broadcast, force join, pengelolaan user, log lokal, pengaturan kecepatan, dan backup yang tersedia dari proyek asal.

## Instalasi
1. Gunakan Python 3.10+.
2. Pasang dependensi: `pip install -r requirements.txt`.
3. Atur environment variables `BOT_TOKEN`, `BUATQRIS_ACCOUNT_ID`, dan `BUATQRIS_SECRET_TOKEN` di panel hosting. Jangan masukkan token ke file publik.
4. Atur `OWNER_ID` pada `config.py` sesuai Telegram ID pemilik bot.
5. Jalankan `python run.py`.

## Perintah pengguna
- `/start`, `/help`, `/cek <nomor...>`
- `/topup` untuk memilih paket
- `/cekbayar <ID transaksi>` untuk memeriksa status pembayaran
- `/riwayat` untuk riwayat pembayaran

## Catatan QRIS (BuatQris)
- Endpoint tunggal: `https://api.buatqris.site`, method `POST`, `application/x-www-form-urlencoded`.
- Buat transaksi memakai `action=api_create_qris`; baca `data.transaction_id`, `data.total_amount`, `data.qr_url`, `data.qris_image`, `data.payment_url`, dan `data.expired_at`.
- QR ditampilkan dari `qr_url`; jika gagal, bot mencoba decode `qris_image` yang berupa data URI base64. `qris_url`, `qris_string`, dan `direct_url` memang dapat bernilai `null` menurut dokumen provider.
- Status memakai `action=api_check_status`; status lunas yang didokumentasikan provider adalah `success`, sedangkan status lain yang didukung ialah `pending`, `expired`, dan `failed`.
- Provider membatasi cek status menjadi satu permintaan per transaksi setiap 20 detik. Bot menerapkan jeda ini agar tidak terkena HTTP 429.
- Total yang harus dibayar menggunakan `total_amount` dari respons, bukan hanya nominal paket `amount`.
- Isi `BUATQRIS_ACCOUNT_ID` dan `BUATQRIS_SECRET_TOKEN` di environment hosting. Jangan masukkan token asli ke kode atau arsip.
- Webhook callback belum diwajibkan untuk fungsi cek manual; bila ingin mengaktifkannya, implementasikan endpoint publik dan verifikasi `X-BuatQris-Signature` sesuai dokumentasi provider.

## Data runtime
File `payments.json`, `payment_history.json`, `premium.json`, log, statistik, dan backup dibuat saat runtime. Jangan bagikan file `.env` atau token.
